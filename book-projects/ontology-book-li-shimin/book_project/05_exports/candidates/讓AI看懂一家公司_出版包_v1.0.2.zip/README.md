# 讓 AI 看懂一家公司｜正式書稿出版包 1.0.2

作者：李詩民。書稿查閱基準：2026-09-28。

本包包含十六章完整正文、全書 Markdown／可編輯 Word／閱讀 PDF、六附錄、逐章 Podcast 文字稿、演講與教學材料。Podcast 文字不是 NotebookLM 已生成音訊；本包建立時音訊仍待生成及正式網站驗收。

## 閱讀與匯入

- 全書：01_master/full_book.docx、full_book.pdf 或 full_book.md；包含序言、導讀、結語與附錄。
- 電子書平台匯入：02_chapters/chapter_XX/chapter_XX_main.md，共 16 章；一章對應一個 NotebookLM 來源與一集音訊。
- 逐章 ZIP：chapter_zips/；內容同 02_chapters/，不可當作額外章節重複匯入。
- 正式可編輯母稿另保存在 authoring_sources/，保留版本與 BODY 邊界；讀者版只移除編輯紀錄，不改寫正文。
- sources／research_notes 與各章附註交代查閱位置及限制；來源登錄不代表完整精讀，工程範例不代表真實企業實測。
- 範例檢查：在解壓後執行 `python examples/scripts/case_checks.py`（Python 3.10 以上）。案例為虛構；不是 OWL 推理器、SHACL 引擎或退款服務。
- 研究、自審與 Word 排版檢查已完成；未冒稱作者試讀、獨立專家審稿或實際朗讀已完成。

## 檔案驗證

publication_manifest.json 登記本包每一檔案的相對路徑、bytes 與 SHA-256（清單本身除外），以及正式章稿版本與母稿雜湊。請先驗證再匯入。未包含第三方全文、私人資料、API 金鑰或原始未完成交接包。
