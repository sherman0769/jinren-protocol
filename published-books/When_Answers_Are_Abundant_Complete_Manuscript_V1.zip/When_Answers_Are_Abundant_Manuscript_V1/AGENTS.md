# Project instructions for Codex

This is a completed Traditional Chinese manuscript, not a book-writing prompt.
Read `05_codex_handoff/CODEX_START_HERE.md` first.

Preserve the canonical Markdown. Do not invent author experiences, research facts, or trial results. Do not expand chapters or rewrite the book without explicit author instruction.

Only carry out requested publishing engineering. No external uploads, publishing, paid API calls, or account actions without appropriate new authorization. Never bundle or distribute font files.

Run `python tools/verify_delivery.py` before modifying. Use `python tools/build_book.py` to regenerate derived reading files after approved source changes. Refresh manifests and checksums after changes; never claim unverified artifacts are finished.
