# 參考資料與查證範圍

主文 [S01] 至 [S23] 為來源代碼。所有連結於 2026 年 10 月 8 日查閱；動態頁面日後可能改版。中文說明是本書的辨識用途，不是原文標題的正式授權譯名。詳細閱讀層級及限制另見研究來源台帳。

## S01｜Sharing AI progress in mathematics

OpenAI。2026-10-06。

https://openai.com/index/sharing-ai-progress-in-mathematics/

本書使用：數學研究公開安排與發布者自述。閱讀層級：官方 HTML 正文。

## S02｜openai/math — README

OpenAI。動態 main；2026-10-08 查閱。

https://github.com/openai/math

本書使用：手稿、成果家族、運算描述及驗證狀態的口徑。閱讀層級：README 全文與目錄說明。

## S03｜openai/math — History

OpenAI。2026-10-07 紀錄；2026-10-08 查閱。

https://github.com/openai/math/blob/main/history.md

本書使用：撤回、相依結果與修訂透明度。閱讀層級：history.md 全文。

## S04｜Responsible Release of AI-Generated Mathematics

Advisory Group on Mathematics and Artificial Intelligence。2026-09-29。

https://agmai.org/general-sep29/

本書使用：人類理解、參與條件與責任規範。閱讀層級：公開建議 HTML 正文。

## S05｜Navier-Stokes Announcement

Clay Mathematics Institute。2026-09-11。

https://www.claymath.org/news/navier-stokes-announcement/

本書使用：研究所回應與後續評估的區別。閱讀層級：官方公告 HTML 正文。

## S06｜Measuring the Impact of Early-2025 AI on Experienced Open-Source Developer Productivity

METR。2025-07-10。

https://metr.org/blog/2025-07-10-early-2025-ai-experienced-os-dev-study/

本書使用：特定程式開發情境的生產力比較。閱讀層級：研究說明 HTML 與方法、結果、限制段落。

## S07｜We are Changing our Developer Productivity Experiment Design

METR。2026-02-24。

https://metr.org/blog/2026-02-24-uplift-update/

本書使用：後續實驗的樣本選擇與量測限制。閱讀層級：官方 HTML 說明。

## S08｜Generative AI without guardrails can harm learning: Evidence from high school mathematics

Hamsa Bastani et al.。2025-06-25 線上發布；PNAS 122(26), e2422633122。

https://www.pnas.org/doi/abs/10.1073/pnas.2422633122

本書使用：練習表現與撤除工具後短期測驗的區別。閱讀層級：期刊摘要、Significance 與版本／更正資訊。

## S09｜Generative AI and Jobs: A Refined Global Index of Occupational Exposure

International Labour Organization。2025-05-20。

https://www.ilo.org/publications/generative-ai-and-jobs-refined-global-index-occupational-exposure

本書使用：任務暴露與實際職業結果的區別。閱讀層級：官方 HTML 概要；未分析報告 PDF。

## S10｜Generative AI at Work

Erik Brynjolfsson, Danielle Li, Lindsey Raymond。arXiv v2：2024-11-06；最初版本 2023-04-23。

https://arxiv.org/html/2304.11771v2

本書使用：特定客服輔助系統的工作表現與異質性。閱讀層級：作者 HTML 版摘要及相關方法、結果段落；版本資料。

## S11｜On the Navier–Stokes Millennium Prize Problem

OpenAI。2026-09-08；頁面含 09-10 更新。

https://openai.com/index/navier-stokes-solution/

本書使用：特定問題版本的主張與研究端代理配置。閱讀層級：官方 HTML 說明。

## S12｜Validating a Lean Proof

Lean。動態官方文件；2026-10-08 查閱。

https://lean-lang.org/doc/reference/latest/ValidatingProofs/

本書使用：定理陳述、公理依賴與形式化檢查範圍。閱讀層級：驗證章 HTML 正文。

## S13｜Tutor CoPilot: A Human-AI Approach for Scaling Real-Time Expertise

Rose E. Wang et al.。arXiv v2：2025-01-26；最初版本 2024-10-03。

https://arxiv.org/abs/2410.03017v2

本書使用：教師側 AI 輔助的教學結果及限制。閱讀層級：作者摘要與版本資訊。

## S14｜Test-enhanced learning: taking memory tests improves long-term retention

Henry L. Roediger III, Jeffrey D. Karpicke。2006-03；Psychological Science 17(3), 249–255。

https://pubmed.ncbi.nlm.nih.gov/16507066/

本書使用：提取練習與延遲記憶保留。閱讀層級：PubMed 收錄之作者摘要與書目。

## S15｜Self-determination theory and the facilitation of intrinsic motivation, social development, and well-being

Richard M. Ryan, Edward L. Deci。2000-01；American Psychologist 55(1), 68–78。

https://pubmed.ncbi.nlm.nih.gov/11392867/

本書使用：自主、能力感與關係連結的理論入口。閱讀層級：PubMed 作者摘要及書目；本次稍後重查遇 429 限制。

## S16｜Building effective agents

Anthropic。2024-12-19；頁面現提示工具環境已改變。

https://www.anthropic.com/engineering/building-effective-agents

本書使用：工作流程與代理的架構區別、複雜度取捨。閱讀層級：HTML 架構定義、何時使用與限制段落。

## S17｜Large Language Models Cannot Self-Correct Reasoning Yet

Jie Huang et al.。arXiv v2：2024-03-14；ICLR 2024。

https://arxiv.org/abs/2310.01798v2

本書使用：無外部回饋的自我修正限制。閱讀層級：作者摘要與版本資訊。

## S18｜Judging LLM-as-a-Judge with MT-Bench and Chatbot Arena

Lianmin Zheng et al.。arXiv v4：2023-12-24；NeurIPS 2023 Datasets and Benchmarks。

https://arxiv.org/abs/2306.05685v4

本書使用：模型評審的用途與已知偏差。閱讀層級：作者摘要與版本資訊。

## S19｜AI Risk Management Framework

NIST。框架 1.0：2023-01-26；動態官方入口。

https://www.nist.gov/itl/ai-risk-management-framework

本書使用：風險管理與可信任性的整體視角。閱讀層級：官方 HTML 概要；未分析框架 PDF。

## S20｜Automation and New Tasks: How Technology Displaces and Reinstates Labor

Daron Acemoglu, Pascual Restrepo。2019；Journal of Economic Perspectives 33(2), 3–30。

https://www.aeaweb.org/articles?id=10.1257/jep.33.2.3

本書使用：任務替代與新增任務的分析架構。閱讀層級：期刊作者摘要與書目；未分析全文 PDF。

## S21｜The Productivity J-Curve: How Intangibles Complement General Purpose Technologies

Erik Brynjolfsson, Daniel Rock, Chad Syverson。2021-01；American Economic Journal: Macroeconomics 13(1), 333–372。

https://www.aeaweb.org/articles?id=10.1257/mac.20180386

本書使用：通用技術與互補無形投入的時間差。閱讀層級：期刊作者摘要與書目；未分析全文 PDF。

## S22｜Measuring AI Ability to Complete Long Software Tasks

Thomas Kwa et al.。最初 2025-03-18；arXiv v4：2026-07-10；NeurIPS 2025。

https://arxiv.org/abs/2503.14499v4

本書使用：人類任務工時尺度與模型成功率的定義。閱讀層級：作者摘要、指標定義與修訂資訊。

## S23｜The Instruction Hierarchy: Training LLMs to Prioritize Privileged Instructions

OpenAI。2024-04-19。

https://openai.com/index/the-instruction-hierarchy/

本書使用：外部資料不應自動取得指令權限。閱讀層級：官方 HTML 摘要與問題說明。
