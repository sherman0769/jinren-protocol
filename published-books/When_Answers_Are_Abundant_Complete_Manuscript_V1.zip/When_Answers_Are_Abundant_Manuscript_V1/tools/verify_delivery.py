#!/usr/bin/env python3
"""Verify the completed book offline. Default mode never modifies files.

--write-manifest updates inventory/checksums only after content checks pass.
Integrity hashes detect changes; they are not a proof of authenticity,
mathematical correctness, author approval, or peer review.
"""
from __future__ import annotations
import argparse
import hashlib
from html.parser import HTMLParser
import json
from pathlib import Path
import re
import sys
from collections import Counter
sys.dont_write_bytecode = True
from build_book import assemble_book, chapter_paths, word_counts, CJK


class Page(HTMLParser):
    def __init__(self) -> None:
        super().__init__(convert_charrefs=True)
        self.ids: list[str] = []
        self.hrefs: list[str] = []
        self.assets: list[str] = []
        self.in_article = False
        self.text: list[str] = []
    def handle_starttag(self, tag: str, attrs: list[tuple[str,str|None]]) -> None:
        a=dict(attrs)
        if a.get('id'): self.ids.append(str(a['id']))
        if tag=='a' and a.get('href'): self.hrefs.append(str(a['href']))
        if tag in ('script','img','iframe','link'):
            self.assets.append(str(a.get('src') or a.get('href') or tag))
        if tag=='article': self.in_article=True
    def handle_endtag(self,tag: str) -> None:
        if tag=='article': self.in_article=False
    def handle_data(self,data: str) -> None:
        if self.in_article:self.text.append(data)


def files(root: Path) -> list[Path]:
    paths=sorted(p for p in root.rglob('*') if p.is_file())
    for p in paths:
        if p.is_symlink(): raise ValueError(f'Symlink not allowed: {p}')
        if p.suffix.lower() in {'.ttf','.otf','.woff','.woff2','.pyc'} or '__pycache__' in p.parts:
            raise ValueError(f'Unwanted binary/font/cache file: {p}')
        if p.stat().st_size == 0: raise ValueError(f'Empty file: {p}')
        p.read_text(encoding='utf-8')
    return paths


def content_checks(root: Path) -> dict:
    chapters=chapter_paths(root)
    expected,counts=assemble_book(root)
    actual=(root/'01_master/full_book.md').read_text(encoding='utf-8')
    if expected!=actual: raise ValueError('Merged Markdown differs from canonical sources. Run build_book.py.')
    saved=json.loads((root/'04_quality/word_count_report.json').read_text())
    if counts!=saved: raise ValueError('Word count report is stale.')
    if not counts['meets_minimum']:raise ValueError('Agreed strict body length is below 60000 Chinese characters.')
    sources=json.loads((root/'03_research/sources.json').read_text())
    ids=[x['id'] for x in sources]
    if ids!=[f'S{i:02d}' for i in range(1,24)]:raise ValueError('Source IDs must be S01–S23, unique and ordered.')
    refs=set(re.findall(r'\[(S\d{2})\]',actual))
    if refs-set(ids):raise ValueError(f'Unresolved sources: {refs-set(ids)}')
    if set(ids)-refs:raise ValueError(f'Unreferenced registry sources: {set(ids)-refs}')
    if re.search(r'|turn\d+(?:view|search|file)\d+|【待補作者案例】|\bTODO\b|\bTBD\b',actual):
        raise ValueError('Unresolved internal citation or placeholder in canonical book.')
    if '\ufffd' in actual:raise ValueError('Unicode replacement character found.')
    paragraphs=[]
    quote_count=0
    for p in chapters:
        text=p.read_text()
        if text.count('## 留給自己的練習')!=1 or text.count('## 本章金句')!=1:
            raise ValueError(f'Exercise/quote section mismatch: {p}')
        q=re.findall(r'^- .+',text.split('## 本章金句',1)[1],re.M)
        if len(q)!=5:raise ValueError(f'Expected five chapter quotes: {p}')
        quote_count+=len(q)
        body=text.split('## 留給自己的練習',1)[0]
        for para in re.split(r'\n\s*\n',body):
            if para.startswith('#'):continue
            para=re.sub(r'\s+|\[S\d{2}\]','',para)
            if len(para)>=80:paragraphs.append(para)
    duplicates=[p for p,n in Counter(paragraphs).items() if n>1]
    if duplicates:raise ValueError(f'Duplicate long body paragraphs found: {len(duplicates)}')
    html_text=(root/'01_master/full_book.html').read_text()
    page=Page();page.feed(html_text)
    if len(page.ids)!=len(set(page.ids)):raise ValueError('Duplicate HTML anchor IDs.')
    broken=[h for h in page.hrefs if h.startswith('#') and h[1:] not in page.ids]
    if broken:raise ValueError(f'Broken internal HTML links: {broken}')
    if page.assets:raise ValueError(f'Unexpected browser resources or scripts: {page.assets}')
    if re.search(r'@import|url\(\s*["\']?https?://',html_text,re.I):raise ValueError('External CSS dependency detected.')
    visible=''.join(page.text).replace('展開全書目錄','',1)
    if CJK.findall(actual)!=CJK.findall(visible):raise ValueError('Rendered book Chinese text/order differs from Markdown.')
    return {'status':'PASS','chapter_count':len(chapters),'source_count':len(ids),'chapter_quotes':quote_count,
            'strict_body_cjk':counts['total']['body_cjk_characters'],
            'nonspace_body_characters':counts['total']['body_nonspace_characters'],
            'duplicate_long_body_paragraphs':len(duplicates),'broken_html_links':len(broken),
            'external_browser_dependencies':len(page.assets),'html_cjk_sequence_matches_markdown':True,
            'merged_markdown_matches_sources':True}


def write_inventory(root: Path) -> None:
    names=[p.relative_to(root).as_posix() for p in files(root) if p.name not in {'delivery_manifest.txt','checksums.sha256'}]
    names=sorted(names+['delivery_manifest.txt','checksums.sha256'])
    (root/'delivery_manifest.txt').write_text('# Complete manuscript V1 delivery inventory\n# One relative file path per non-comment line\n'+'\n'.join(names)+'\n')
    lines=[]
    for p in files(root):
        if p.name=='checksums.sha256':continue
        lines.append(hashlib.sha256(p.read_bytes()).hexdigest()+'  '+p.relative_to(root).as_posix())
    (root/'checksums.sha256').write_text('\n'.join(lines)+'\n')


def check_inventory(root: Path) -> dict:
    actual={p.relative_to(root).as_posix() for p in files(root)}
    expected={line for line in (root/'delivery_manifest.txt').read_text().splitlines() if line and not line.startswith('#')}
    if actual!=expected:raise ValueError(f'Inventory mismatch: missing={expected-actual}; extra={actual-expected}')
    expected_hashes={}
    for line in (root/'checksums.sha256').read_text().splitlines():
        digest,name=line.split('  ',1)
        if name in expected_hashes:raise ValueError('Duplicate checksum entry.')
        path=root/name
        if path.resolve().parent!=root.resolve() and root.resolve() not in path.resolve().parents:raise ValueError('Unsafe inventory path.')
        expected_hashes[name]=digest
        if hashlib.sha256(path.read_bytes()).hexdigest()!=digest:raise ValueError(f'Checksum mismatch: {name}')
    if set(expected_hashes)!=actual-{'checksums.sha256'}:raise ValueError('Checksum coverage differs from inventory.')
    return {'file_count':len(actual),'checksums_verified':len(expected_hashes)}


def main() -> None:
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--root',type=Path,default=Path(__file__).resolve().parents[1])
    parser.add_argument('--write-manifest',action='store_true')
    parser.add_argument('--content-only',action='store_true',help='Check manuscript and HTML before inventory creation.')
    args=parser.parse_args();root=args.root.resolve()
    result=content_checks(root)
    if args.write_manifest:write_inventory(root)
    if not args.content_only:result.update(check_inventory(root))
    print(json.dumps(result,ensure_ascii=False,indent=2))

if __name__=='__main__':
    try:main()
    except (ValueError,OSError,KeyError,json.JSONDecodeError) as exc:
        print(f'FAIL: {exc}',file=sys.stderr);raise SystemExit(1)
