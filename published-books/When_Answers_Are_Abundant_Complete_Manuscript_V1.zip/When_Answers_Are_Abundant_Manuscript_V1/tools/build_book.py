#!/usr/bin/env python3
"""Rebuild this manuscript's derived MD/HTML and word counts, entirely offline.

Uses only the Python standard library. The renderer supports the deliberately
small Markdown subset used in this book; it is not a general Markdown engine.
Canonical chapter text is never changed by this script.
"""
from __future__ import annotations
import argparse
import html
import json
import re
from pathlib import Path

DATE = '2026-10-08'
TITLE = '當答案不再稀缺'
SUBTITLE = '當 AI 開始探索未知，我們如何重新學習、工作與選擇'
PARTS = {
    1: ('第一部', '先看清，究竟改變了什麼'),
    4: ('第二部', '重新理解，什麼才是我的能力'),
    7: ('第三部', '把能力放回工作、組織與社會'),
    10: ('第四部', '把理解變成自己的選擇'),
}
CJK = re.compile(r'[\u3400-\u9fff]')
REF = re.compile(r'\[S\d{2}\]')


def read(path: Path) -> str:
    if not path.is_file():
        raise FileNotFoundError(f'Required manuscript source missing: {path}')
    text = path.read_text(encoding='utf-8')
    if not text.strip():
        raise ValueError(f'Empty manuscript source: {path}')
    return text.rstrip() + '\n'


def chapter_paths(root: Path) -> list[Path]:
    paths = sorted(root.glob('02_chapters/chapter_*/*_main.md'))
    ids = [int(p.stem.split('_')[1]) for p in paths]
    if ids != list(range(1, 13)):
        raise ValueError(f'Expected chapters 01–12 exactly once; found {ids}')
    return paths


def body_text(text: str) -> str:
    text = text.split('## 留給自己的練習', 1)[0]
    text = re.sub(r'^#{1,6}\s+.*$', '', text, flags=re.M)
    text = REF.sub('', text)
    text = re.sub(r'\[([^\]]+)\]\([^)]*\)', r'\1', text)
    text = re.sub(r'<!--.*?-->', '', text, flags=re.S)
    text = re.sub(r'https?://\S+', '', text)
    text = re.sub(r'[`*_>]', '', text)
    return text.strip()


def word_counts(root: Path) -> dict:
    paths = [root / '01_master/preface.md', *chapter_paths(root), root / '01_master/conclusion.md']
    items = []
    for path in paths:
        source = read(path)
        body = body_text(source)
        items.append({
            'file': path.relative_to(root).as_posix(),
            'title': source.splitlines()[0].lstrip('# '),
            'body_cjk_characters': len(CJK.findall(body)),
            'body_nonspace_characters': len(re.sub(r'\s', '', body)),
            'latin_words_reference_only': len(re.findall(r"[A-Za-z]+(?:[-'][A-Za-z0-9]+)*", body)),
        })
    total = {key: sum(x[key] for x in items) for key in ('body_cjk_characters', 'body_nonspace_characters', 'latin_words_reference_only')}
    return {
        'edition': '完整書稿 V1', 'reference_date': DATE,
        'method': '正文取序言、12章、結語；排除所有標題小標、章末練習及金句、來源代碼、目錄、附錄、來源表與工程文件。CJK欄只數U+3400–U+9FFF，不含英數及標點；非空白字元欄另含英數及標點。',
        'minimum_body_cjk': 60000, 'meets_minimum': total['body_cjk_characters'] >= 60000,
        'chapters_only_cjk': sum(x['body_cjk_characters'] for x in items[1:-1]),
        'items': items, 'total': total,
    }


def make_toc(root: Path) -> str:
    lines = ['# 全書目錄', '', '- [序言｜我想知道，這與我有什麼關係](#preface)', '']
    for n, path in enumerate(chapter_paths(root), 1):
        if n in PARTS:
            a, b = PARTS[n]
            lines += [f'## {a}｜{b}', '']
        title = read(path).splitlines()[0].lstrip('# ')
        lines += [f'- [{title}](#chapter-{n:02d})']
    lines += ['', '- [結語｜把未來，帶回可以選擇的今天](#conclusion)',
              '- [附錄一｜英文名詞與工作解釋](#appendix-1)',
              '- [附錄二｜七張工作卡](#appendix-2)',
              '- [附錄三｜可修正的自主性說明卡](#appendix-3)',
              '- [附錄四｜作者覆核與聆聽使用](#appendix-4)',
              '- [參考資料與查證範圍](#references)', '']
    return '\n'.join(lines)


def assemble_book(root: Path) -> tuple[str, dict]:
    counts = word_counts(root)
    cjk = counts['total']['body_cjk_characters']
    front = f'''# {TITLE}

**{SUBTITLE}**

李詩民｜AI 協作書稿

完整書稿 V1 · 研究查閱基準 {DATE} · 正文 {cjk:,} 個中文字（不含英數、標點及章末輔助內容）

本版本供閱讀、內化與 Codex 後製。全書內容已寫成；第一人稱立場與公開出版仍待作者本人覆核。假設案例不是實測成果，研究來源與閱讀範圍列於文末及台帳。

'''
    parts = [front, make_toc(root)]
    def add(path: Path) -> None:
        parts.append(f'\n<!-- source: {path.relative_to(root).as_posix()} -->\n\n' + read(path))
    add(root / '01_master/preface.md')
    for n, path in enumerate(chapter_paths(root), 1):
        if n in PARTS:
            a, b = PARTS[n]
            parts.append(f'\n# {a}｜{b}\n')
        add(path)
    for name in ['conclusion.md', 'appendices.md', 'references.md']:
        add(root / '01_master' / name)
    return '\n\n---\n\n'.join(x.strip() for x in parts) + '\n', counts


def inline(text: str) -> str:
    if re.fullmatch(r'https?://[^\s]+', text.strip()):
        url = html.escape(text.strip(), quote=True)
        return f'<a class="source-url" href="{url}" target="_blank" rel="noopener noreferrer">{url}</a>'
    text = html.escape(text, quote=False)
    text = re.sub(r'`([^`]+)`', r'<code>\1</code>', text)
    text = re.sub(r'\*\*(.+?)\*\*', r'<strong>\1</strong>', text)
    text = re.sub(r'\[([^\]]+)\]\((#[A-Za-z0-9_-]+)\)', r'<a href="\2">\1</a>', text)
    text = re.sub(r'\[(S\d{2})\]', lambda m: f'<sup class="citation"><a href="#source-{m[1].lower()}" aria-label="來源 {m[1]}">[{m[1]}]</a></sup>', text)
    return text


def render_body(md: str, root: Path) -> tuple[str, list[tuple[str, str]]]:
    chapter_map = {read(p).splitlines()[0].lstrip('# '): f'chapter-{n:02d}' for n, p in enumerate(chapter_paths(root), 1)}
    heading_no = 0
    paragraph: list[str] = []
    list_open = False
    out: list[str] = []
    nav: list[tuple[str, str]] = []
    toc_open = False
    def flush() -> None:
        if paragraph:
            out.append('<p>' + inline(' '.join(paragraph)) + '</p>')
            paragraph.clear()
    def close_list() -> None:
        nonlocal list_open
        if list_open:
            out.append('</ul>'); list_open = False
    for line in md.splitlines():
        line = line.strip()
        if line.startswith('<!--'):
            continue
        if not line:
            flush(); close_list(); continue
        if line == '---':
            flush(); close_list(); out.append('<hr>'); continue
        match = re.match(r'^(#{1,6})\s+(.+)$', line)
        if match:
            flush(); close_list()
            raw_level, title = len(match[1]), match[2]
            heading_no += 1
            hid = f'section-{heading_no:03d}'
            cls = ''
            if title == TITLE:
                hid='book-title'; cls='book-title'; level=1
            elif title == '全書目錄':
                hid='contents'; cls='contents-title'; level=2
                out.append('<details class="inline-contents"><summary>展開全書目錄</summary>'); toc_open=True
            elif raw_level == 1 and title.startswith('序言｜'):
                if toc_open: out.append('</details>'); toc_open=False
                hid='preface'; level=2; cls='chapter-title'; nav.append((hid,title))
            elif raw_level == 1 and title in chapter_map:
                hid=chapter_map[title]; level=2; cls='chapter-title'; nav.append((hid,title))
            elif raw_level == 1 and re.match(r'^第[一二三四]部｜',title):
                hid='part-'+str(list(PARTS.values()).index(tuple(title.split('｜',1)))+1)
                level=2; cls='part-title'; nav.append((hid,title))
            elif raw_level == 1 and title.startswith('結語｜'):
                hid='conclusion'; level=2; cls='chapter-title'; nav.append((hid,title))
            elif raw_level == 1 and title.startswith('附錄'):
                i='一二三四'.index(title[2])+1; hid=f'appendix-{i}';level=2;cls='chapter-title';nav.append((hid,title))
            elif raw_level == 1 and title == '參考資料與查證範圍':
                hid='references';level=2;cls='chapter-title';nav.append((hid,title))
            elif re.match(r'^S\d{2}｜',title):
                hid='source-'+title[:3].lower();level=3;cls='source-heading'
            else:
                level=min(raw_level+1,6)
            out.append(f'<h{level} id="{hid}" class="{cls}">{inline(title)}</h{level}>')
            continue
        if line.startswith('- '):
            flush()
            if not list_open: out.append('<ul>');list_open=True
            out.append('<li>'+inline(line[2:])+'</li>'); continue
        if line.startswith('> '):
            flush();close_list();out.append('<blockquote>'+inline(line[2:])+'</blockquote>');continue
        close_list();paragraph.append(line)
    flush();close_list()
    if toc_open:out.append('</details>')
    return '\n'.join(out),nav


CSS = r'''
:root{--ink:#24322c;--muted:#667269;--paper:#faf9f4;--green:#245d45;--line:#dbe2d8;--soft:#edf1e9}
*{box-sizing:border-box}html{scroll-behavior:auto;scroll-padding-top:24px}body{margin:0;background:var(--paper);color:var(--ink);font-family:"Noto Serif CJK TC","Source Han Serif TC","PMingLiU",serif;line-height:1.95;font-size:19px}
a{color:var(--green);text-decoration-thickness:1px;text-underline-offset:3px}a:hover{color:#123a29}a:focus-visible{outline:3px solid #88aa81;outline-offset:3px}
.skip{position:absolute;left:-9999px}.skip:focus{left:16px;top:12px;z-index:4;background:white;padding:12px}
.sidebar{position:fixed;inset:0 auto 0 0;width:290px;padding:32px 23px;overflow:auto;border-right:1px solid var(--line);font-family:"Noto Sans CJK TC","Microsoft JhengHei",sans-serif;background:#f1f3eb;font-size:14px;line-height:1.7}
.sidebar .brand{font-size:19px;font-weight:700;margin:0 0 5px}.sidebar .edition{color:var(--muted);font-size:12px;margin-bottom:22px}.sidebar a{display:block;padding:7px 0;text-decoration:none}.sidebar a.part-link{font-weight:700;border-top:1px solid var(--line);margin-top:13px;padding-top:14px;font-size:13px}.sidebar a.chapter-link{padding-left:8px}.sidebar .mobile-nav{display:none}
main{margin-left:290px;padding:68px 52px 96px}article{max-width:780px;margin:0 auto}h1,h2,h3,h4{font-family:"Noto Sans CJK TC","Microsoft JhengHei",sans-serif;line-height:1.5;overflow-wrap:anywhere}h1.book-title{font-size:clamp(38px,4.1vw,64px);letter-spacing:.025em;line-height:1.28;margin:0 0 22px;max-width:750px;color:var(--green)}h1.book-title+p{font-size:24px;line-height:1.7;margin:0 0 32px;color:#4f6258}h1.book-title+p+p{font-size:17px;letter-spacing:.08em}h1.book-title+p+p+p{font:13px/1.8 "Noto Sans CJK TC","Microsoft JhengHei",sans-serif;color:var(--muted)}
h2.chapter-title{font-size:31px;margin:78px 0 30px;padding-top:18px;border-top:3px solid var(--green)}h2.part-title{font-size:19px;letter-spacing:.06em;color:var(--green);background:var(--soft);padding:22px 24px;margin:90px 0 40px;border-left:4px solid var(--green)}h3{font-size:23px;margin:44px 0 20px}h3.source-heading{font-size:18px;margin-top:36px}h4{font-size:20px}p{margin:0 0 1.15em;text-align:justify;overflow-wrap:break-word}li{margin:.4em 0}ul{padding-left:1.3em}hr{border:0;border-top:1px solid var(--line);margin:42px 0}blockquote{margin:28px 0;padding:14px 25px;border-left:3px solid var(--green);background:var(--soft)}code{font:85%/1.6 ui-monospace,Consolas,monospace;background:var(--soft);padding:.12em .3em;overflow-wrap:anywhere}strong{font-weight:700}.citation{font-family:ui-sans-serif,Arial,sans-serif;font-size:11px;margin-left:3px;white-space:nowrap}.citation a{text-decoration:none}.source-url{font:14px/1.7 ui-sans-serif,Arial,sans-serif;overflow-wrap:anywhere;word-break:break-word}
.inline-contents{border:1px solid var(--line);border-radius:6px;padding:16px 21px;margin:24px 0 36px;background:#f4f5ed;font-family:"Noto Sans CJK TC","Microsoft JhengHei",sans-serif;font-size:15px}.inline-contents summary{cursor:pointer;color:var(--green);font-weight:700}.inline-contents h2{font-size:22px}.inline-contents h3{font-size:16px;margin:24px 0 9px}.inline-contents a{text-decoration:none}.inline-contents hr{display:none}
footer{max-width:780px;margin:70px auto 0;padding-top:24px;border-top:1px solid var(--line);font:13px/1.8 "Noto Sans CJK TC","Microsoft JhengHei",sans-serif;color:var(--muted)}
@media(max-width:1050px){.sidebar{width:240px;padding:26px 18px;font-size:13px}main{margin-left:240px;padding:48px 34px 80px}body{font-size:18px}}
@media(max-width:760px){.sidebar{position:relative;width:auto;height:auto;max-height:none;border-right:0;border-bottom:1px solid var(--line);padding:17px 22px}.sidebar .edition{margin-bottom:8px}.sidebar .desktop-nav{display:none}.sidebar .mobile-nav{display:block}.sidebar details>summary{display:list-item;cursor:pointer}.sidebar details nav{padding-top:12px;max-height:65vh;overflow:auto}.sidebar details:not([open]) nav{display:none}main{margin:0;padding:36px 22px 65px}body{font-size:18px;line-height:1.95}h1.book-title{font-size:43px}h1.book-title+p{font-size:20px}h2.chapter-title{font-size:27px;margin-top:58px}h3{font-size:21px}.sidebar .brand{font-size:17px}.sidebar .edition{font-size:11px}.inline-contents{font-size:14px}p{text-align:left}}
@media print{@page{size:A4;margin:21mm 19mm}.sidebar,.skip,.inline-contents,footer{display:none}main{margin:0;padding:0}article{max-width:none}body{background:white;color:black;font-size:11pt;line-height:1.8}h1.book-title{font-size:32pt}h2.chapter-title{break-before:page;font-size:22pt}h2.part-title{break-before:page;margin-top:35mm}h3{break-after:avoid;font-size:15pt}p{orphans:3;widows:3}a{color:inherit;text-decoration:none}hr{display:none}}
'''


def build(root: Path) -> dict:
    md,counts=assemble_book(root)
    (root/'01_master/full_book.md').write_text(md,encoding='utf-8')
    (root/'01_master/table_of_contents.md').write_text(make_toc(root),encoding='utf-8')
    body,nav=render_body(md,root)
    nav_html='\n'.join(f'<a class="{"part-link" if hid.startswith("part-") else "chapter-link"}" href="#{hid}">{html.escape(title)}</a>' for hid,title in nav)
    page=f'''<!doctype html>
<html lang="zh-Hant-TW"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><meta name="color-scheme" content="light"><meta name="description" content="當答案不再稀缺：李詩民的完整 AI 協作書稿 V1"><title>{TITLE}｜李詩民・完整書稿 V1</title><style>{CSS}</style></head><body><a class="skip" href="#book-title">跳到正文</a><aside class="sidebar"><p class="brand">{TITLE}</p><p class="edition">完整書稿 V1 · {DATE}<br>十二章 · 可離線閱讀</p><nav class="desktop-nav" aria-label="章節導覽">{nav_html}</nav><details class="mobile-nav"><summary>章節導覽</summary><nav aria-label="行動版章節導覽">{nav_html}</nav></details></aside><main><article id="book-content">{body}</article><footer>本頁由正式 Markdown 離線產生，未載入外部字型、追蹤程式或第三方資源。參考資料連結僅在點選後前往外部網站。<br>全書內容完成；公開出版與第一人稱立場仍待作者本人覆核。</footer></main></body></html>'''
    (root/'01_master/full_book.html').write_text(page,encoding='utf-8')
    quality=root/'04_quality';quality.mkdir(exist_ok=True)
    (quality/'word_count_report.json').write_text(json.dumps(counts,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    report=['# 正文字數報告\n',f'版次：完整書稿 V1。內容基準：{DATE}。\n',counts['method']+'\n',
            '| 部分 | 正文中文字（嚴格口徑） | 正文非空白字元（含英數、標點） |','|---|---:|---:|']
    for item in counts['items']:
        report.append(f'| {item["title"].replace("|","／")} | {item["body_cjk_characters"]:,} | {item["body_nonspace_characters"]:,} |')
    t=counts['total'];report+= [f'| **全書正文合計** | **{t["body_cjk_characters"]:,}** | **{t["body_nonspace_characters"]:,}** |','',
        f'十二章本體合計：{counts["chapters_only_cjk"]:,} 個中文字；加上序言與結語後為上述全書正文數。',
        f'六萬正文中文字門檻：{"通過" if counts["meets_minimum"] else "未通過"}。',
        '目錄、章名、小標、章末練習、金句、附錄、參考資料、README 與重複合併檔均沒有用來墊高目標。來源章節只計一次。',
        '「非空白字元」為另一種顯示口徑，不宣稱等於中文斷詞後的詞數。正式出版頁數取決於後續版型，本次不估報已完成頁數。','']
    (quality/'word_count_report.md').write_text('\n'.join(report),encoding='utf-8')
    manifest={'title':TITLE,'subtitle':SUBTITLE,'version':'V1','date':DATE,'chapter_count':12,
              'chapters':[{'number':i,'path':p.relative_to(root).as_posix(),'title':read(p).splitlines()[0].lstrip('# ')} for i,p in enumerate(chapter_paths(root),1)],
              'canonical_sources':['01_master/preface.md',*[p.relative_to(root).as_posix() for p in chapter_paths(root)],'01_master/conclusion.md','01_master/appendices.md','01_master/references.md'],
              'derived':['01_master/full_book.md','01_master/full_book.html','01_master/table_of_contents.md']}
    (root/'00_project/book_manifest.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    return counts


def main() -> None:
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--root',type=Path,default=Path(__file__).resolve().parents[1])
    args=parser.parse_args()
    counts=build(args.root.resolve())
    print(json.dumps({'body_cjk':counts['total']['body_cjk_characters'],'minimum_met':counts['meets_minimum'],'chapters':12},ensure_ascii=False))
    if not counts['meets_minimum']:
        raise SystemExit('Manuscript built, but the agreed body-length gate is not met. Do not claim completion.')

if __name__=='__main__':
    main()
