# 研究來源台帳

查閱基準：2026-10-08（Asia/Taipei）。本台帳記錄實際閱讀層級，不把摘要閱讀冒稱全文審查，也不把官方公告冒稱獨立驗證。主文的 [Sxx] 對應下列固定編號。

研究方式是圍繞全書論證的選擇性查證，不是具有完整搜尋與排除流程的系統性文獻綜述。未獨立重算研究資料，未逐篇驗證數學手稿，未執行 Lean 證明編譯。

資料來源主要為官方原始公告、原始論文與研究團隊公開材料。期刊／PubMed／arXiv 入口的閱讀層級各自列明。動態頁面記錄查閱日期，未宣稱具備固定提交雜湊。

## S01｜Sharing AI progress in mathematics

作者／機構：OpenAI。日期／版本：2026-10-06。

來源：https://openai.com/index/sharing-ai-progress-in-mathematics/

類型：官方研究公告。實際閱讀：官方 HTML 正文。

支持章節：1。支持範圍：數學研究公開安排與發布者自述。

限制：公告不是逐篇獨立驗證；本書不宣稱重現研究。

更新觸發：發布安排或模型取得狀態變更時。

## S02｜openai/math — README

作者／機構：OpenAI。日期／版本：動態 main；2026-10-08 查閱。

來源：https://github.com/openai/math

類型：官方研究儲存庫。實際閱讀：README 全文與目錄說明。

支持章節：1。支持範圍：手稿、成果家族、運算描述及驗證狀態的口徑。

限制：main 會更新；本次未下載全部手稿、審查全部證明或執行 Lean。

更新觸發：每次涉及庫內數量與狀態的新版出版前。

## S03｜openai/math — History

作者／機構：OpenAI。日期／版本：2026-10-07 紀錄；2026-10-08 查閱。

來源：https://github.com/openai/math/blob/main/history.md

類型：官方修訂紀錄。實際閱讀：history.md 全文。

支持章節：1。支持範圍：撤回、相依結果與修訂透明度。

限制：紀錄反映發布者修訂；不是外部審查完成的證明。

更新觸發：出現新增修訂或撤回時。

## S04｜Responsible Release of AI-Generated Mathematics

作者／機構：Advisory Group on Mathematics and Artificial Intelligence。日期／版本：2026-09-29。

來源：https://agmai.org/general-sep29/

類型：獨立顧問群公開建議。實際閱讀：公開建議 HTML 正文。

支持章節：1、8。支持範圍：人類理解、參與條件與責任規範。

限制：規範立場不等於所有數學家的共識，也不是因果研究。

更新觸發：顧問群發佈修訂或相關制度改變時。

## S05｜Navier-Stokes Announcement

作者／機構：Clay Mathematics Institute。日期／版本：2026-09-11。

來源：https://www.claymath.org/news/navier-stokes-announcement/

類型：研究機構公告。實際閱讀：官方公告 HTML 正文。

支持章節：1。支持範圍：研究所回應與後續評估的區別。

限制：未據此判定正式授獎；未獨立驗證數學論證。

更新觸發：正式評估或獎項狀態有新公告時。

## S06｜Measuring the Impact of Early-2025 AI on Experienced Open-Source Developer Productivity

作者／機構：METR。日期／版本：2025-07-10。

來源：https://metr.org/blog/2025-07-10-early-2025-ai-experienced-os-dev-study/

類型：研究團隊原始報告。實際閱讀：研究說明 HTML 與方法、結果、限制段落。

支持章節：3。支持範圍：特定程式開發情境的生產力比較。

限制：不可外推所有軟體工作；未重新分析原始資料。

更新觸發：比較新的工具與工作條件時。

## S07｜We are Changing our Developer Productivity Experiment Design

作者／機構：METR。日期／版本：2026-02-24。

來源：https://metr.org/blog/2026-02-24-uplift-update/

類型：研究設計更新。實際閱讀：官方 HTML 說明。

支持章節：3。支持範圍：後續實驗的樣本選擇與量測限制。

限制：不能把後續資料當成可靠的通用效率估計。

更新觸發：有更完整的新設計或結果時。

## S08｜Generative AI without guardrails can harm learning: Evidence from high school mathematics

作者／機構：Hamsa Bastani et al.。日期／版本：2025-06-25 線上發布；PNAS 122(26), e2422633122。

來源：https://www.pnas.org/doi/abs/10.1073/pnas.2422633122

類型：原始教育研究。實際閱讀：期刊摘要、Significance 與版本／更正資訊。

支持章節：5。支持範圍：練習表現與撤除工具後短期測驗的區別。

限制：本次非全文方法及補充資料重審；不能推論普遍長期能力損害。頁面另有作者單位更正。

更新觸發：引用長期效果、其他年齡或新系統時必須另補證據。

## S09｜Generative AI and Jobs: A Refined Global Index of Occupational Exposure

作者／機構：International Labour Organization。日期／版本：2025-05-20。

來源：https://www.ilo.org/publications/generative-ai-and-jobs-refined-global-index-occupational-exposure

類型：國際組織研究報告。實際閱讀：官方 HTML 概要；未分析報告 PDF。

支持章節：3。支持範圍：任務暴露與實際職業結果的區別。

限制：本書不引用地區細項估計，也不將暴露指標換算失業率。

更新觸發：職業暴露指標更新或討論特定地區時。

## S10｜Generative AI at Work

作者／機構：Erik Brynjolfsson, Danielle Li, Lindsey Raymond。日期／版本：arXiv v2：2024-11-06；最初版本 2023-04-23。

來源：https://arxiv.org/html/2304.11771v2

類型：作者原始研究稿。實際閱讀：作者 HTML 版摘要及相關方法、結果段落；版本資料。

支持章節：3、8。支持範圍：特定客服輔助系統的工作表現與異質性。

限制：分階段導入的特定情境，不是所有職業通用實驗；沒有由此推算個人收入。

更新觸發：若改採正式期刊版本或外推其他工作時。

## S11｜On the Navier–Stokes Millennium Prize Problem

作者／機構：OpenAI。日期／版本：2026-09-08；頁面含 09-10 更新。

來源：https://openai.com/index/navier-stokes-solution/

類型：官方研究公告。實際閱讀：官方 HTML 說明。

支持章節：1、7。支持範圍：特定問題版本的主張與研究端代理配置。

限制：研究流程不能當作每篇十月手稿流程；非本次獨立數學驗證。

更新觸發：論證、修訂或正式評估發展時。

## S12｜Validating a Lean Proof

作者／機構：Lean。日期／版本：動態官方文件；2026-10-08 查閱。

來源：https://lean-lang.org/doc/reference/latest/ValidatingProofs/

類型：官方技術文件。實際閱讀：驗證章 HTML 正文。

支持章節：1。支持範圍：定理陳述、公理依賴與形式化檢查範圍。

限制：一般驗證條件不等於本次已檢查各個證明庫；未編譯任何研究證明。

更新觸發：Lean 工具鏈或具體驗證配置變動時。

## S13｜Tutor CoPilot: A Human-AI Approach for Scaling Real-Time Expertise

作者／機構：Rose E. Wang et al.。日期／版本：arXiv v2：2025-01-26；最初版本 2024-10-03。

來源：https://arxiv.org/abs/2410.03017v2

類型：原始教育研究預印本。實際閱讀：作者摘要與版本資訊。

支持章節：5。支持範圍：教師側 AI 輔助的教學結果及限制。

限制：不是學生單獨使用聊天工具；本次未重審完整方法與資料。

更新觸發：外推其他教學設計時。

## S14｜Test-enhanced learning: taking memory tests improves long-term retention

作者／機構：Henry L. Roediger III, Jeffrey D. Karpicke。日期／版本：2006-03；Psychological Science 17(3), 249–255。

來源：https://pubmed.ncbi.nlm.nih.gov/16507066/

類型：原始學習研究。實際閱讀：PubMed 收錄之作者摘要與書目。

支持章節：5。支持範圍：提取練習與延遲記憶保留。

限制：特定實驗不直接驗證本書聽讀流程或所有轉用能力。

更新觸發：若提出 AI 學習的直接因果主張，需補專門研究。

## S15｜Self-determination theory and the facilitation of intrinsic motivation, social development, and well-being

作者／機構：Richard M. Ryan, Edward L. Deci。日期／版本：2000-01；American Psychologist 55(1), 68–78。

來源：https://pubmed.ncbi.nlm.nih.gov/11392867/

類型：理論與研究綜述。實際閱讀：PubMed 作者摘要及書目；本次稍後重查遇 429 限制。

支持章節：9。支持範圍：自主、能力感與關係連結的理論入口。

限制：不是對當前 AI 的直接研究，不用來證明人的尊嚴或提供臨床建議。

更新觸發：若延伸至具體 AI 介入效果，需新增證據。

## S16｜Building effective agents

作者／機構：Anthropic。日期／版本：2024-12-19；頁面現提示工具環境已改變。

來源：https://www.anthropic.com/engineering/building-effective-agents

類型：官方工程經驗文章。實際閱讀：HTML 架構定義、何時使用與限制段落。

支持章節：7。支持範圍：工作流程與代理的架構區別、複雜度取捨。

限制：廠商經驗並非通用實驗；不把 2024 工具清單當成最新產品指南。

更新觸發：討論當前 API、託管產品或部署規格時。

## S17｜Large Language Models Cannot Self-Correct Reasoning Yet

作者／機構：Jie Huang et al.。日期／版本：arXiv v2：2024-03-14；ICLR 2024。

來源：https://arxiv.org/abs/2310.01798v2

類型：原始模型評估研究。實際閱讀：作者摘要與版本資訊。

支持章節：6。支持範圍：無外部回饋的自我修正限制。

限制：只適用研究中的模型與條件；不能推論未來永遠無法修正。

更新觸發：比較新模型或不同回饋機制時。

## S18｜Judging LLM-as-a-Judge with MT-Bench and Chatbot Arena

作者／機構：Lianmin Zheng et al.。日期／版本：arXiv v4：2023-12-24；NeurIPS 2023 Datasets and Benchmarks。

來源：https://arxiv.org/abs/2306.05685v4

類型：原始評估研究。實際閱讀：作者摘要與版本資訊。

支持章節：6。支持範圍：模型評審的用途與已知偏差。

限制：偏好一致度不等於數學、事實或專業正確性；不是當前所有模型能力結論。

更新觸發：當評審模型、任務或尺度改變時。

## S19｜AI Risk Management Framework

作者／機構：NIST。日期／版本：框架 1.0：2023-01-26；動態官方入口。

來源：https://www.nist.gov/itl/ai-risk-management-framework

類型：官方自願性風險框架。實際閱讀：官方 HTML 概要；未分析框架 PDF。

支持章節：6。支持範圍：風險管理與可信任性的整體視角。

限制：不是認證、法律結論，也不代表本書方案已符合框架。

更新觸發：正式採用、新版框架或特定法域用途前。

## S20｜Automation and New Tasks: How Technology Displaces and Reinstates Labor

作者／機構：Daron Acemoglu, Pascual Restrepo。日期／版本：2019；Journal of Economic Perspectives 33(2), 3–30。

來源：https://www.aeaweb.org/articles?id=10.1257/jep.33.2.3

類型：原始經濟學論文。實際閱讀：期刊作者摘要與書目；未分析全文 PDF。

支持章節：4、8。支持範圍：任務替代與新增任務的分析架構。

限制：不是臺灣當前就業預測；不可保證受替代者會取得新職務。

更新觸發：若採用具體地區或產業估計時。

## S21｜The Productivity J-Curve: How Intangibles Complement General Purpose Technologies

作者／機構：Erik Brynjolfsson, Daniel Rock, Chad Syverson。日期／版本：2021-01；American Economic Journal: Macroeconomics 13(1), 333–372。

來源：https://www.aeaweb.org/articles?id=10.1257/mac.20180386

類型：原始經濟學論文。實際閱讀：期刊作者摘要與書目；未分析全文 PDF。

支持章節：3。支持範圍：通用技術與互補無形投入的時間差。

限制：不是每個專案先虧後賺的承諾；不據此估計回收期。

更新觸發：外推特定專案收益時。

## S22｜Measuring AI Ability to Complete Long Software Tasks

作者／機構：Thomas Kwa et al.。日期／版本：最初 2025-03-18；arXiv v4：2026-07-10；NeurIPS 2025。

來源：https://arxiv.org/abs/2503.14499v4

類型：原始能力量測研究。實際閱讀：作者摘要、指標定義與修訂資訊。

支持章節：11。支持範圍：人類任務工時尺度與模型成功率的定義。

限制：v4 備註為作者名單補列；不把摘要舊模型數字當最新能力，也不採用條件外推為預言。

更新觸發：需要最新模型量測或外部效度判斷時。

## S23｜The Instruction Hierarchy: Training LLMs to Prioritize Privileged Instructions

作者／機構：OpenAI。日期／版本：2024-04-19。

來源：https://openai.com/index/the-instruction-hierarchy/

類型：官方原始研究說明。實際閱讀：官方 HTML 摘要與問題說明。

支持章節：6。支持範圍：外部資料不應自動取得指令權限。

限制：研究中的防禦改善不代表完全安全；不聲稱本書已測試特定產品。

更新觸發：具體代理、安全設計或工具權限改版時。
