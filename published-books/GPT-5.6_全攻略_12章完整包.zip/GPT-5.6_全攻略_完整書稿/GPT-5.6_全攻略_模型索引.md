# 《GPT-5.6 全攻略》全書模型索引

## 第 1 章｜GPT-5.6 不是模型更新，而是工作方式更新
- 章節定位：建立全書起點：GPT-5.6 的價值從回答品質轉向成果完成。
- 核心問題：當模型更強，為什麼多數人的工作方式仍停在複製貼上？
- 核心答案：把 AI 從聊天視窗移進有目標、Context、工具、工件與驗收的工作鏈。
- 模型：
  - Copy-Paste Cliff
  - Answer-to-Outcome Shift
  - Outcome Distance
  - Outcome Contract
  - Agent Portfolio

## 第 2 章｜Sol、Terra、Luna：模型不再選最強，而是選最適合
- 章節定位：建立 Sol、Terra、Luna 的能力配置觀，而不是最強模型迷思。
- 核心問題：三個模型應如何依任務價值、成本與規模分工？
- 核心答案：用歧義、影響、流量設計 Model Routing，並以 Evals 動態調整。
- 模型：
  - Model Routing Triangle
  - Capability Placement
  - S/M/L 任務分級
  - Upgrade / Downgrade Policy

## 第 3 章｜Instant、Medium、High、Extra High、Pro 怎麼選？
- 章節定位：把推理層級視為可配置資源，建立可量測的升級階梯。
- 核心問題：Instant、Medium、High、Extra High、Pro 到底怎麼選？
- 核心答案：依任務複雜度、影響、可驗收性與延遲要求逐級升級，而非預設最高。
- 模型：
  - Reasoning Escalation Ladder
  - 四變數選擇法
  - Reasoning Budget
  - Pro Value Test

## 第 4 章｜ChatGPT Work：ChatGPT 開始進入工作現場
- 章節定位：說明 ChatGPT Work 如何把對話提升成跨資料與工具的工作現場。
- 核心問題：ChatGPT 何時不再只是聊天視窗，而是一個工作表面？
- 核心答案：當它能 Gather、Plan、Act、Deliver，並在權限與驗收中完成工件。
- 模型：
  - Gather-Plan-Act-Deliver
  - Work Context Cube
  - Approval Gates
  - Work Memory Pack

## 第 5 章｜從 Prompt Engineering 到 Outcome Engineering
- 章節定位：把 Prompt Engineering 推進到成果、邊界、驗收與重複機制。
- 核心問題：為什麼提示詞愈寫愈長，成果仍然不穩定？
- 核心答案：先定義 Outcome Contract、Autonomy Envelope 與 Acceptance，再讓模型規劃。
- 模型：
  - Outcome Contract
  - Autonomy Envelope
  - Acceptance First
  - 三層 Prompt
  - Outcome Debt

## 第 6 章｜GPT-5.6 的文件、簡報與試算表革命
- 章節定位：將文件、簡報與試算表從文字容器提升為可交付工件。
- 核心問題：內容正確，為什麼一份檔案仍可能不能交付？
- 核心答案：同時維持語意、結構、視覺、運算、操作與治理完整性。
- 模型：
  - Artifact Engineering
  - Artifact Fidelity
  - Artifact Fidelity Loop
  - Deck DNA
  - Spreadsheet Causal Map
  - Artifact Debt

## 第 7 章｜Codex：從寫程式進化成數位工作者
- 章節定位：把 Codex 定位為能理解、修改、執行與驗證的數位工作者。
- 核心問題：Codex 何時從寫程式工具變成工作執行環境？
- 核心答案：當程式碼進入 Inspect、Plan、Edit、Run、Observe、Iterate 的受控循環。
- 模型：
  - Codex Work Loop
  - Repository as World
  - Agent Contract
  - Least Tool Principle
  - Prototype Trap
  - Diff as Deliverable

## 第 8 章｜Sites：AI 做完之後，如何直接變成產品？
- 章節定位：說明 Sites 如何縮短工件與可被他人使用之產品的距離。
- 核心問題：AI 做完一個網站，為什麼還不等於產品完成？
- 核心答案：必須補上存取、身分、資料、可靠性、治理、維護與回饋循環。
- 模型：
  - Publishability Gap
  - Site Outcome Brief
  - State-first Product Design
  - Reversible Delivery
  - Product Feedback Loop

## 第 9 章｜Ultra 與 Multi-Agent：一個 AI 不再負責所有事情
- 章節定位：建立多 Agent 的拆解、Context、並行、整合與評估方法。
- 核心問題：多開幾個 Agent，為什麼不會自動變成團隊？
- 核心答案：工作要能平行、自治、審查、聚合，並由 Root Agent 承擔整合。
- 模型：
  - PARA 判斷法
  - Agent Work Package
  - Context Partitioning
  - Concurrency Budget
  - Loop Ledger
  - Multi-Agent Evals

## 第 10 章｜GPT-5.6 API：給 AI 架構師與開發者的實戰指南
- 章節定位：將模型、工具、狀態、治理、觀察與評估整理成完整 API 架構。
- 核心問題：除了選模型，生產級 GPT-5.6 應用還需要設計什麼？
- 核心答案：用 AI Runtime Stack 管理 Context、工具、狀態、路由、工件、護欄、Trace 與 Evals。
- 模型：
  - AI Runtime Stack
  - Context Sufficiency
  - Model Router
  - Cost per Accepted Outcome
  - Cache Debt
  - Tool Result Envelope

## 第 11 章｜安全、隱私與 GPT-5.6 的使用邊界
- 章節定位：把安全從模型拒絕提升為資料、權限、工具、核准與事件治理。
- 核心問題：能力越接近工作，組織如何避免越權、外洩與不可逆錯誤？
- 核心答案：建立資料與動作分級、多層 Guardrails、最小權限、Approval Gate 與事件回復。
- 模型：
  - Capability Is Not Authorization
  - Data Context Ladder
  - Action Risk Ladder
  - Guardrail Stack
  - Change Envelope
  - AI Incident Playbook

## 第 12 章｜GPT-5.6 時代的 Human on Loop
- 章節定位：收束全書，定義人從逐步操作轉向循環設計與監督的新位置。
- 核心問題：當 AI 能承接更多工作，人應該站在哪裡？
- 核心答案：站在循環之上，守住 Outcome、Policy、Context、Portfolio、Telemetry 與 Learning。
- 模型：
  - Chatbot-Agent-Work-Runtime-Loop
  - HOL Control Plane
  - Loop Engineering
  - Decision Rights Matrix
  - Loop Literacy
  - Loop Debt
  - Loop Moat
