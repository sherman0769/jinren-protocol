# 第 12 章｜GPT-5.6 時代的 Human on Loop｜投影片大綱

## 設計原則
- 16:9；每頁只表達一個主要訊息。
- 標題寫結論，不只寫主題。
- 每三至四頁安排一個對照、模型、案例或互動。
- 官方資料頁標示「截至 2026-07-09」。

## 建議 15 頁
### 1. 封面
人不必卡在每一步，但必須站在整個循環之上

### 2. 現場矛盾
當 AI 能承接更多工作，人應該站在哪裡？

### 3. 舊方法的天花板
每一次 AI 能力提升，都會帶來同一個焦慮：人還要做什麼？

### 4. 本章核心答案
站在循環之上，守住 Outcome、Policy、Context、Portfolio、Telemetry 與 Learning。

### 5. Chatbot-Agent-Work-Runtime-Loop
以圖像、層級、流程或對照方式解釋「Chatbot-Agent-Work-Runtime-Loop」，並加入一個工作現場例子。

### 6. HOL Control Plane
以圖像、層級、流程或對照方式解釋「HOL Control Plane」，並加入一個工作現場例子。

### 7. Loop Engineering
以圖像、層級、流程或對照方式解釋「Loop Engineering」，並加入一個工作現場例子。

### 8. Decision Rights Matrix
以圖像、層級、流程或對照方式解釋「Decision Rights Matrix」，並加入一個工作現場例子。

### 9. Loop Literacy
以圖像、層級、流程或對照方式解釋「Loop Literacy」，並加入一個工作現場例子。

### 10. 一、從 Chatbot 到 Loop：五個階段的工作演化
人提出問題，AI 回答。

### 11. 二、Human-in、Human-on、Human-out：三種人機位置
人出現在流程裡，負責核准、分類、判斷或補資料。

### 12. 三、Human on Loop 的六個控制面
我把人的上層責任整理成 HOL Control Plane。

### 13. 常見誤區
列出兩至三個「看似更進步、實際增加負債」的做法。

### 14. 明天可以做什麼
給聽眾一個 10～30 分鐘可完成的行動練習。

### 15. 章末金句
GPT-5.6 的終點不是功能全會，而是工作系統開始會學習。

## 講者備註
把技術規格放在備用頁；主線保持「現象 → 問題 → 新模型 → 案例 → 行動」。
