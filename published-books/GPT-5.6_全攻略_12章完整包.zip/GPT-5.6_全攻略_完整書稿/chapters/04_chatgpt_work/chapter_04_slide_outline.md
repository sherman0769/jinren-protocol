# 第 4 章｜ChatGPT Work：ChatGPT 開始進入工作現場｜投影片大綱

## 設計原則
- 16:9；每頁只表達一個主要訊息。
- 標題寫結論，不只寫主題。
- 每三至四頁安排一個對照、模型、案例或互動。
- 官方資料頁標示「截至 2026-07-09」。

## 建議 15 頁
### 1. 封面
ChatGPT 開始進入資料與工具所在的工作現場

### 2. 現場矛盾
ChatGPT 何時不再只是聊天視窗，而是一個工作表面？

### 3. 舊方法的天花板
一個人一天的工作，不會只存在於一個對話視窗。

### 4. 本章核心答案
當它能 Gather、Plan、Act、Deliver，並在權限與驗收中完成工件。

### 5. Gather-Plan-Act-Deliver
以圖像、層級、流程或對照方式解釋「Gather-Plan-Act-Deliver」，並加入一個工作現場例子。

### 6. Work Context Cube
以圖像、層級、流程或對照方式解釋「Work Context Cube」，並加入一個工作現場例子。

### 7. Approval Gates
以圖像、層級、流程或對照方式解釋「Approval Gates」，並加入一個工作現場例子。

### 8. Work Memory Pack
以圖像、層級、流程或對照方式解釋「Work Memory Pack」，並加入一個工作現場例子。

### 9. 一、Chat、Work、Codex：三種不同的工作姿勢
在 ChatGPT 生態裡，可以把三種介面理解成三種工作姿勢。

### 10. 二、Work 的四個核心動作
官方頁面用很簡潔的方式描述 Work：gather context、plan the approach、take action、create polished outputs。

### 11. 三、Work Context Cube：AI 工作現場的六個面
我把 ChatGPT Work 所需的 Context 整理成 Work Context Cube，工作脈絡立方體。

### 12. 實際情境
帶入講師、企業內訓、內容出版、Agent 或 Runtime 的真實工作。

### 13. 常見誤區
列出兩至三個「看似更進步、實際增加負債」的做法。

### 14. 明天可以做什麼
給聽眾一個 10～30 分鐘可完成的行動練習。

### 15. 章末金句
Work 的成熟度，不看它能做多少，而看它能在清楚邊界內穩定交付多少。

## 講者備註
把技術規格放在備用頁；主線保持「現象 → 問題 → 新模型 → 案例 → 行動」。
