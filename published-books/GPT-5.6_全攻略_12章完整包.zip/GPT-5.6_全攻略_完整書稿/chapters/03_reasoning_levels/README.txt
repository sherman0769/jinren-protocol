第 3 章｜Instant、Medium、High、Extra High、Pro 怎麼選？

章節定位：把推理層級視為可配置資源，建立可量測的升級階梯。
核心問題：Instant、Medium、High、Extra High、Pro 到底怎麼選？
核心答案：依任務複雜度、影響、可驗收性與延遲要求逐級升級，而非預設最高。

檔案內容：
- chapter_03_main.docx：可編輯章節正文
- chapter_03_main.md：Markdown 章節正文
- chapter_03_speech_notes.md：演講轉化筆記
- chapter_03_slide_outline.md：15 頁投影片大綱
- chapter_03_quotes.md：章末金句庫
- chapter_03_loop_canvas.md：本章 Loop Canvas
- README.txt：章節說明與統計

字數統計：
- 非空白字元：5,952
- CJK 字元：約 3,490
- 標題數：36
- 金句數：10

研究版本：截至 2026-07-09；最新產品、價格、方案與 Beta 狀態請再次查閱官方資料。
用途：書稿、演講、企業內訓、課程、簡報、社群內容與方法論內化。
