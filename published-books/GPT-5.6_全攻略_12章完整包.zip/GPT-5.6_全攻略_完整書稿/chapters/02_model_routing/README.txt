第 2 章｜Sol、Terra、Luna：模型不再選最強，而是選最適合

章節定位：建立 Sol、Terra、Luna 的能力配置觀，而不是最強模型迷思。
核心問題：三個模型應如何依任務價值、成本與規模分工？
核心答案：用歧義、影響、流量設計 Model Routing，並以 Evals 動態調整。

檔案內容：
- chapter_02_main.docx：可編輯章節正文
- chapter_02_main.md：Markdown 章節正文
- chapter_02_speech_notes.md：演講轉化筆記
- chapter_02_slide_outline.md：15 頁投影片大綱
- chapter_02_quotes.md：章末金句庫
- chapter_02_loop_canvas.md：本章 Loop Canvas
- README.txt：章節說明與統計

字數統計：
- 非空白字元：5,639
- CJK 字元：約 3,731
- 標題數：30
- 金句數：10

研究版本：截至 2026-07-09；最新產品、價格、方案與 Beta 狀態請再次查閱官方資料。
用途：書稿、演講、企業內訓、課程、簡報、社群內容與方法論內化。
