# 第 11 章｜安全、隱私與 GPT-5.6 的使用邊界｜Loop Canvas

## 一、Outcome
- 本章要改變的工作結果：建立資料與動作分級、多層 Guardrails、最小權限、Approval Gate 與事件回復。
- 主要使用者：一般工作者、講師、內容創作者、企業導入者或 AI 架構師。
- 通過標準：讀者能用本章模型重新設計一個真實工作，而不是只記住名詞。

## 二、核心問題
能力越接近工作，組織如何避免越權、外洩與不可逆錯誤？

## 三、核心模型
- Capability Is Not Authorization
- Data Context Ladder
- Action Risk Ladder
- Guardrail Stack
- Change Envelope
- AI Incident Playbook

## 四、Context
- 必要資料：任務目標、受眾、現有流程、資料來源、限制、失敗案例。
- 版本資訊：涉及 GPT-5.6 產品與 API 時，以 2026-07-09 官方資料為基準。
- 不應混入：未查證的價格、方案、功能與把作者框架說成官方術語。

## 五、Action
- 選一個每週重複工作，依本章模型重新拆解。
- 建立一份最小契約、路由、工件、工具或治理規則。
- 先在可逆、低風險範圍跑十次。

## 六、Artifact
- 一頁 Canvas。
- 一份工作前後對照。
- 一個可檢查的工件或設定。
- 一份失敗與待人工決定清單。

## 七、Sensor
- 任務完成率、人工修改時間、錯誤、重試、成本、使用者回饋。
- 是否出現越權、來源衝突、版本錯誤或不可回復行動。

## 八、Evaluator
- 內容是否回答核心問題？
- 工件是否可使用、可追溯、可回復？
- 是否在更低模型、成本或人工介入下仍能達標？

## 九、Memory
- 將有效做法寫回 Outcome Contract、Context Pack、Skill、Tool Schema 或 Eval Set。
- 將重複失敗加入下一版測試，而不是只口頭提醒。

## 十、Human on Loop
- 人負責目標、政策、核准、例外、最終責任與改善節奏。
- AI 負責在清楚邊界內執行、回報證據與產生可驗收成果。
