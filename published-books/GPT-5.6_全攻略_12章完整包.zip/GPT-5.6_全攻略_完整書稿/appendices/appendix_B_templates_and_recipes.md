# 附錄 B｜Outcome、Agent 與工件實戰範本

## B-1｜Outcome Contract 完整版

```text
專案名稱：
Owner：
版本／日期：

一、Purpose
- 這項工作服務哪個人、決策或行動？
- 不做會造成什麼問題？

二、Deliverables
- 工件名稱：
- 格式：
- 使用者：
- 必要內容：
- 不需要內容：

三、Context
- 權威來源：
- 參考來源：
- 適用日期與版本：
- 受眾背景：
- 品牌與風格：
- 已知決策：
- 未知與待確認：

四、Constraints
- 法律／政策：
- 隱私／機密：
- 時間／成本：
- 技術／格式：
- 不得杜撰：

五、Authority
- 可讀取：
- 可建立：
- 可修改：
- 可執行：
- 可發布：
- 必須核准：
- 禁止：

六、Acceptance
- 內容：
- 結構：
- 視覺：
- 運算：
- 操作：
- 治理：

七、Stop & Escalate
- 缺少哪些資料時停止？
- 哪些衝突不能自行決定？
- 何種成本或延遲超標？
- 哪些動作需要人？
- 連續幾次驗收失敗後升級？
```

## B-2｜Agent Contract 範本

```text
Agent 名稱：
工作包 ID：

Objective：要完成的單一結果。
Scope：允許處理的資料、目錄、系統與時間範圍。
Invariants：不得破壞的介面、資料、格式、政策與既有行為。
Inputs：必要資料與版本。
Tools：允許工具；讀寫工具分開。
Output Schema：固定欄位、工件與證據。
Acceptance：測試、Rubric 與最低門檻。
Authority：可自行、事後回報、事前核准、禁止。
Budget：模型、effort、Token、工具呼叫、時間與金額上限。
Escalation：來源衝突、祕密缺失、範圍擴大、不可逆動作、驗收失敗。
Handoff：下一個 Agent 或人需要知道的狀態。
```

## B-3｜研究任務範本

```text
目的：回答〔核心問題〕，供〔受眾〕做〔決策〕。

來源優先序：
1. 官方文件與第一手資料。
2. 原始研究論文。
3. 可靠技術文件或權威報導。

時間基準：截至 YYYY-MM-DD。

輸出：
- 三句結論。
- 事實表：主張、來源、日期、適用範圍。
- 不確定與來源衝突。
- 對決策的影響。
- 後續需要驗證的問題。

規則：
- 事實、推論、建議分開。
- 找不到資料時明說。
- 不以搜尋摘要取代原始來源。
- 所有可能變動的數字標日期。
```

## B-4｜書稿章節範本

```text
章名：
章節定位：
核心問題：
核心答案：
預估字數：

正文節奏：
1. 章首開場：用一個現場矛盾切入。
2. 現象觀察：描述真實使用狀況。
3. 問題指出：說明舊方法天花板。
4. 新觀念：提出可命名的核心概念。
5. 模型整理：框架、層級、流程或對照。
6. 實際情境：講師、企業、內容、Agent、Runtime。
7. 限制與反例：什麼情況不適用？
8. 內化筆記：回到人的工作與責任。
9. 演講提煉：可上台表達的節奏。
10. 章末金句：5 至 10 句。

驗收：
- 不是功能堆砌。
- 有原創觀點與白話模型。
- 最新技術事實有來源與日期。
- 不重複前章，只承接思想線。
```

## B-5｜簡報 Outcome Contract

```text
使用情境：〔場合、日期、時間〕
受眾：〔職位、程度、關心問題〕
目的：聽完後要理解、相信或採取什麼？
時長：
頁數上限：

敘事：
- 開場張力：
- 三個核心段落：
- 示範或案例：
- 結尾行動：

視覺：
- 參考 Deck：
- Deck DNA：字體、色彩、網格、版型、圖片、圖表、密度。
- 每頁一個 Message。
- 最小投影字級：

交付：
- 可編輯 PPTX。
- 講者備註。
- PDF 預覽。
- 圖表資料與來源。

驗收：
- 逐頁渲染無溢位。
- 在指定時間內可講完。
- 結論標題與圖表一致。
- 來源、日期與品牌正確。
```

## B-6｜試算表 Outcome Contract

```text
決策：這個模型要協助哪個決定？
輸入：使用者可調整哪些假設？單位與範圍？
邏輯：關鍵公式、相依性與情境？
輸出：決策者要看哪些 KPI？
檢查：平衡、錯誤值、空值、極端值、日期與比例？

工作表：
- README：使用說明、版本與限制。
- Inputs：集中輸入與資料驗證。
- Logic：公式與中間結果。
- Outputs：摘要、圖表與情境比較。
- Checks：控制與錯誤旗標。
- Sources：資料來源與更新日期。

驗收：
- 無未說明硬編碼。
- 公式可追溯。
- 變更假設後能重算。
- 極端與空值不崩潰。
- 圖表連到正確資料。
```

## B-7｜Sites Outcome Brief

```text
Audience：誰會使用？
Job：他要完成什麼？
Entry：從哪個入口與裝置進入？
Path：最短成功路徑？
States：有哪些使用狀態與轉換？
Data：讀取、寫入、保存哪些資料？
Trust：身分、來源、隱私、聯絡與錯誤如何表達？
Success：完成率、時間、錯誤、轉換或人工節省？
Boundary：不得公開、不得自動、不得收集什麼？
Owner：誰更新、回復、關閉與支援？
```

## B-8｜多 Agent Work Package

```json
{
  "work_package_id": "research-api-pricing",
  "question": "整理指定日期的 GPT-5.6 API 官方價格與適用條件",
  "inputs": ["OpenAI Models", "OpenAI Pricing"],
  "allowed_tools": ["web_read_official"],
  "boundaries": ["不得引用非官方價格", "不得推估未公告費率"],
  "output_schema": {
    "claim": "string",
    "value": "string",
    "effective_date": "date",
    "scope": "string",
    "source": "string",
    "uncertainty": "string"
  },
  "budget": {"max_calls": 8, "max_minutes": 10},
  "escalate_when": ["官方文件衝突", "找不到生效日期"]
}
```

## B-9｜工具契約範本

```json
{
  "name": "create_draft_report",
  "description": "在指定專案資料夾建立新的報告草稿；不覆蓋既有檔案。",
  "input": {
    "project_id": "string",
    "title": "string",
    "content_markdown": "string",
    "idempotency_key": "string"
  },
  "permissions": {
    "read": ["project_metadata"],
    "write": ["draft_folder"],
    "forbidden": ["publish", "delete", "email"]
  },
  "returns": {
    "ok": "boolean",
    "file_id": "string|null",
    "warnings": "string[]",
    "retryable": "boolean"
  },
  "approval": "not_required_for_new_draft",
  "audit": ["actor", "timestamp", "project_id", "file_id"]
}
```

## B-10｜Artifact QA 清單

### 文件

- [ ] 標題、摘要、主文、結論、來源與待確認事項完整。
- [ ] 樣式而非手動格式建立層級。
- [ ] 表格不超出頁面，標題不孤立在頁尾。
- [ ] 字型、頁碼、頁首頁尾與中文顯示正常。
- [ ] 所有重要數字有來源或假設。
- [ ] 實際渲染逐頁檢查。

### 簡報

- [ ] 每頁一個主要訊息。
- [ ] 標題表達結論，而非只寫主題。
- [ ] 版型、色彩、字體與母片一致。
- [ ] 圖表、標題、講者備註與資料一致。
- [ ] 投影時最小字級可讀。
- [ ] 每頁渲染無溢位、重疊與破圖。

### 試算表

- [ ] Inputs、Logic、Outputs、Checks 分離。
- [ ] 公式可追溯，沒有不明硬編碼。
- [ ] 空值、零、負值與極端值測試。
- [ ] 日期、百分比、幣別、單位一致。
- [ ] 圖表來源正確。
- [ ] 重算後沒有錯誤值。

### 網站／App

- [ ] 首要使用者工作可在最短路徑完成。
- [ ] 手機、桌面、重新整理、返回與錯誤狀態測試。
- [ ] 祕密不在前端或原始碼。
- [ ] 身分、權限與資料狀態清楚。
- [ ] 有版本、預覽、回復與 Owner。
- [ ] 發布前通過內容、隱私、功能與責任 Gate。

## B-11｜模型路由設定範例

```yaml
tasks:
  classify_feedback:
    model: gpt-5.6-luna
    effort: low
    mode: standard
    max_output_tokens: 1200
    upgrade_when:
      - confidence_below: 0.75
      - conflicting_labels: true

  write_training_module:
    model: gpt-5.6-terra
    effort: medium
    mode: standard
    upgrade_when:
      - source_conflict: true
      - high_impact_claims: true

  final_risk_review:
    model: gpt-5.6-sol
    effort: high
    mode: pro
    approval_required: false
```

這只是概念範例；實際參數與 Schema 應依官方 SDK 版本、評估結果與組織政策調整。

## B-12｜成本估算工作表欄位

| 欄位 | 說明 |
|---|---|
| task_type | 任務類型 |
| model / effort / mode | 執行設定 |
| requests | 請求數 |
| input_tokens | 未快取輸入 |
| cached_tokens | 快取讀取 |
| cache_write_tokens | 快取寫入 |
| output_tokens | 輸出與計費推理 Token |
| tool_calls | 工具次數與費用 |
| retries | 重試次數 |
| accepted | 通過驗收數 |
| human_minutes | 人工修正時間 |
| total_cost | 模型＋工具＋人工估算 |
| cost_per_accepted_outcome | 總成本 ÷ 通過成果 |

不要只比較單次 API 金額。把人工修改、重試、失敗與外部工具放進同一張表。

## B-13｜30 分鐘工作流盤點練習

選一件每週重複工作，填寫：

1. 觸發：什麼事件讓工作開始？
2. 輸入：有哪些資料、格式與來源？
3. 現有步驟：人在哪裡複製、等待、判斷與重做？
4. 成果：誰使用？如何判斷完成？
5. 例外：最常見五種問題？
6. 風險：資料與動作分級？
7. 可自動：哪些低風險、可逆、可驗收？
8. 需人工：哪些涉及價值、責任與不可逆後果？
9. Sensor：能收集哪些品質與使用資料？
10. Memory：改善要寫回哪個 Context、Skill、工具或 Eval？

盤點完成後，不要立刻自動化全部。先選一段最小可觀察循環，跑十次再擴大。
