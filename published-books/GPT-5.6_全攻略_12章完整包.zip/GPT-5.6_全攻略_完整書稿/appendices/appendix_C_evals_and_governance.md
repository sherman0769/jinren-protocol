# 附錄 C｜Evals、Tracing 與治理落地手冊

## C-1｜先定義「通過」，再收集測試案例

一個 Eval 不是問「這個答案好不好」，而是問「這個工作是否達到可接受標準」。評估應直接對應 Outcome Contract。

### 通用評估維度

1. **Task Success**：指定成果是否完成？
2. **Factuality**：事實、日期、數字與來源是否正確？
3. **Completeness**：必要欄位、工件與限制是否保留？
4. **Grounding**：結論是否能回到來源與工具結果？
5. **Instruction Compliance**：是否遵守範圍、格式與政策？
6. **Action Safety**：是否只在授權內行動？
7. **Usability**：成果能否被真實使用者理解、編輯與操作？
8. **Efficiency**：Token、延遲、工具次數、人工與總成本？
9. **Recoverability**：失敗時是否可重試、回復或轉人工？
10. **Learning Value**：失敗能否被分類並改進下一版？

## C-2｜建立代表性 Eval Set

不要只使用最漂亮的示範案例。至少包含：

- 典型成功案例。
- 資料缺少與格式錯誤。
- 多來源矛盾。
- 需要最新查證。
- 使用者指令模糊。
- 超出權限要求。
- 外部工具逾時或回傳錯誤。
- Prompt Injection。
- 超長或噪音 Context。
- 不同語言、口語與錯別字。
- 高風險但表面正常的請求。
- 過去真實生產失敗。

每個案例要保存：輸入、必要 Context、預期行為、不可接受行為、Rubric、權重與版本。

## C-3｜三層評分：規則、模型、人

### Rule-based Grader

適合檔案存在、JSON Schema、字數、欄位、公式、測試、連結、權限與禁止字串等可確定條件。

優點：快速、穩定、便宜。缺點：無法充分判斷語意與價值。

### Model-based Grader

適合結構、證據品質、風險辨認、文體與語意完整性。應提供清楚 Rubric、反例與證據要求，並定期與人類評分校準。

優點：可擴展語意評估。缺點：也可能偏誤、不穩或被長度影響。

### Human Review

適合高影響、價值判斷、專業責任與新的失敗類型。人類不必評所有案例，可對高風險、低信心與抽樣資料覆核。

最佳做法通常是三者組合：規則守底線、模型擴大語意覆蓋、人類承擔高價值判斷。

## C-4｜Rubric 範例：研究報告

| 維度 | 0 分 | 1 分 | 2 分 | 3 分 |
|---|---|---|---|---|
| 結論 | 無結論或答非所問 | 有方向但模糊 | 回答核心問題 | 清楚、可行且有優先序 |
| 來源 | 無來源 | 多為二手或不明 | 重要主張有可靠來源 | 官方／第一手為主，版本清楚 |
| 事實與推論 | 混為一談 | 部分區分 | 大致清楚 | 明確標示事實、推論、建議與未知 |
| 反例／限制 | 沒有 | 泛泛而談 | 有重要限制 | 能說明適用邊界與替代解釋 |
| 決策價值 | 無法行動 | 只提供背景 | 有具體下一步 | 將證據、風險與行動完整連結 |

設定門檻時，不要只看總分。某些「致命條件」必須單獨通過，例如杜撰來源、洩露個資、未經核准外部寫入，不能由其他高分抵銷。

## C-5｜Rubric 範例：Agent 工具工作流

- 工具選擇正確率。
- 參數有效率。
- 不必要工具呼叫數。
- 越權呼叫數。
- 重複外部寫入數。
- 工具錯誤後恢復率。
- 最終狀態與工件一致。
- 核准前是否停止。
- Trace 是否保留必要證據。
- 每個通過成果成本。

## C-6｜Tracing 最小事件模型

每次工作流可以記錄以下事件：

```text
request.received
policy.resolved
context.retrieved
model.selected
model.response.started
model.response.completed
tool.call.requested
tool.call.approval_required
tool.call.completed
subagent.started
subagent.completed
artifact.created
evaluation.completed
human.reviewed
workflow.completed
workflow.failed
workflow.rolled_back
```

每個事件至少帶：Trace ID、時間、工作包、模型／工具、狀態、耗時、Token／成本摘要、錯誤類型與資料分級。敏感原文是否保存，應另依政策決定。

## C-7｜Failure Taxonomy：失敗分類表

| 類型 | 說明 | 優先修正位置 |
|---|---|---|
| Goal Error | 誤解目的或交付物 | Outcome Contract |
| Context Error | 缺資料、舊資料、錯檢索 | Context Layer |
| Reasoning Error | 推論或整合錯誤 | 模型／effort／Prompt |
| Tool Selection Error | 選錯工具 | 工具描述、路由、Eval |
| Tool Execution Error | 外部服務、參數、權限失敗 | Tool Layer |
| Action Overreach | 超出授權 | Policy、Permission、Approval |
| Artifact Error | 檔案、版面、公式、可編輯性 | Artifact Tests |
| Synthesis Error | 多 Agent 衝突、遺漏與去重失敗 | Root Agent／Schema |
| Safety Error | 敏感、越權、Injection、外洩 | Guardrail Stack |
| Recovery Error | 無法重試、回復或接手 | Orchestration／Incident Plan |

不要把所有失敗都歸類為「Prompt 不夠好」。分類錯誤，修正就會放錯位置。

## C-8｜模型升級檢查表

- [ ] 鎖定現有 Champion 設定與 Eval 結果。
- [ ] 使用相同代表性案例測試新模型。
- [ ] 同時比較原 effort 與低一級。
- [ ] 檢查成功率、完整性、證據、工具行為與安全。
- [ ] 比較輸入、輸出、快取、延遲、重試與總成本。
- [ ] 檢查 Prompt 是否因新模型更主動而造成 Overreach。
- [ ] 測試長 Context、缺資料與工具失敗。
- [ ] 先影子或小流量測試。
- [ ] 準備回復設定。
- [ ] 更新模型卡、日期與 Owner。

## C-9｜每週 Human on Loop 審查會

建議 30 至 45 分鐘，只看需要決策的資訊。

1. 上週 Outcome 指標是否改善？
2. 哪三種失敗最常出現？
3. 有沒有安全、資料或越權事件？
4. 人工介入在哪些節點集中？
5. 哪個模型或工具成本異常？
6. 哪個例外值得納入下一版？
7. 哪個步驟可以降低人工？
8. 哪個步驟應收緊權限？
9. 本週新增哪個 Eval？
10. 誰負責更新 Context、Skill、工具或政策？

會議結束必須產生變更：一個新 Eval、一項修正、一個 Owner 與驗證日期。只看儀表板、不改循環，會形成治理儀式化。

## C-10｜AI Incident 快速卡

```text
事件時間：
Trace／工作流：
發現者：
影響範圍：使用者、資料、外部動作、金額、法規。

立即控制：
- 停用工具／工作流／憑證？
- 回復或下架？
- 保留哪些證據？

通知：
- Runtime Owner
- Data／Risk Owner
- Outcome Owner
- 法務、資安、客戶或主管（視需要）

根因分類：Goal／Context／Model／Tool／Permission／Artifact／Safety／Recovery。

永久修正：
- 新增或修改哪個 Eval？
- 更新哪個 Policy、Skill、Tool 或 Context？
- 如何驗證？
- Owner 與期限？
```

## C-11｜治理成熟度五級

### Level 0：Ad hoc

個人自由使用，沒有共通資料規則、記錄與驗收。

### Level 1：Guided

有基本使用規範、核准與培訓，但流程仍靠人記憶。

### Level 2：Measured

有代表性 Evals、Trace、成本與失敗分類，能比較版本。

### Level 3：Controlled

資料與動作分級、工具最小權限、Approval Gate、事件與回復制度化。

### Level 4：Learning Loop

真實回饋持續更新 Context、Skills、Evals、路由與政策；人站在循環上管理成果，而不是逐步操作。

成熟度不是追求最高級，而是依風險與價值建立適當控制。低風險個人草稿不需要銀行級流程；正式營運系統不能只靠個人 Prompt。
