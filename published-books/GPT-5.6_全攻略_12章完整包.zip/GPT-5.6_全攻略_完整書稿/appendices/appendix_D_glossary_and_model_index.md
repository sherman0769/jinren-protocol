# 附錄 D｜核心術語、原創模型與演講索引

## D-1｜GPT-5.6 核心術語

### Agent

能依目標使用工具、維持狀態並採取行動的 AI 工作單元。不是只回答，而是完成界定任務。

### Artifact

工作產出的可檢查工件，例如文件、簡報、試算表、程式、網站、資料表與報告。

### ChatGPT Work

以 GPT-5.6 為核心的工作表面，可蒐集 Context、規劃、跨工具行動並建立專業工件。[OAI-03]

### Codex

OpenAI 的數位工作與程式執行環境，涵蓋 app、CLI、IDE 與雲端，可檢查、修改、執行、測試與管理多 Agent 任務。[OAI-11][OAI-17]

### Computer Use

讓模型透過受控介面操作電腦環境。因能改變外部狀態，需要權限、確認與觀察。

### Context

模型當下所處的資訊世界，包括目標、政策、資料、歷史、工具結果、狀態與限制。

### Context Window

單次工作能容納的 Token 範圍。大 Context 提供容量，不保證所有資訊都同等被使用。

### Evals

用代表性案例與 Rubric 量測模型或工作流是否達到 Outcome、品質、安全與成本標準。

### Function Calling

模型依工具 Schema 產生結構化呼叫，由應用程式執行，再把結果送回模型。

### Guardrails

限制資料、工具、行動與輸出的多層控制，包含權限、政策、驗收、監控與人類核准。

### Human-in-the-Loop

人在特定流程節點做判斷、核准或補足。

### Human-on-the-Loop

系統在界定範圍內運行，人從上層觀察成果、風險與趨勢，並在必要時介入與改進。

### MCP

Model Context Protocol，用標準化方式讓模型或 Agent 連接外部工具與資源。接得上不等於應該全部開放。

### Multi-Agent

根 Agent 協調多個子 Agent 分工、平行處理與整合。適合獨立、可審查、可聚合的工作包。

### Programmatic Tool Calling

GPT-5.6 可在受管 Runtime 中用程式協調允許工具並處理中間資料，適合過濾、Join、排序、去重、聚合與驗證。[OAI-05]

### Prompt Caching

快取重複 Prompt 前綴，以降低重複讀取的成本與延遲。GPT-5.6 同時支援隱式與明確快取策略。[OAI-05]

### Reasoning Effort

控制模型在任務上投入的推理程度。GPT-5.6 API 支援 none、low、medium、high、xhigh、max。[OAI-05]

### Pro Mode

Responses API 的品質優先執行模式，透過更多模型工作提升困難任務可靠性；與 reasoning effort 獨立。[OAI-05][OAI-08]

### Responses API

OpenAI 建議用於 GPT-5.6 推理、工具、多輪與 Agent 工作流的 API 表面。[OAI-05]

### Runtime

模型實際工作的運行環境，由 Context、工具、狀態、權限、工件、觀察與評估共同構成。

### Sites

Codex 的成果交付表面，可建立、託管、修正與分享網站、Web App、遊戲等互動成果；本書版本日為公開測試。[OAI-10]

### Skill

可重用的工作能力包，包含使用時機、指令、資源、工具、輸出與驗收。成熟 Skill 應有評估。

### Structured Outputs

使用 Schema 約束模型輸出，使下游程式或 Agent 能可靠讀取，而不必從散文猜欄位。

### Trace

一次工作流從請求、Context、模型、工具、Agent、工件、評估到核准的可追蹤事件鏈。

### Ultra

GPT-5.6 的多 Agent 品質模式。官方說明預設協調四個 Agent 平行工作後整合。[OAI-01]

## D-2｜本書原創模型索引

### Answer-to-Outcome Shift

從追求一次回答，轉向完成可驗收成果。

### Copy-Paste Cliff

AI 使用停留在人工搬運資料與答案，無法形成持續工作能力的天花板。

### Outcome Distance

從文字回答到真實結果的距離，可依回答、草稿、工件、行動、持續成果分層。

### Outcome Contract

以 Purpose、Deliverables、Context、Constraints、Authority、Acceptance、Stop & Escalate 定義工作。

### Outcome Engineering

設計成果、邊界、驗收與重複機制，而不只設計一次提示詞。

### Outcome Debt

成果定義與驗收長期模糊，造成重做、版本分裂與人工修正的債。

### Autonomy Envelope

Agent 可以自主執行、需核准與禁止行動的邊界。

### Model Routing Triangle

用 Ambiguity、Impact、Volume 判斷模型配置。

### Reasoning Escalation Ladder

從低成本低推理，依任務品質與風險逐層升級模型、effort 或 pro，而非預設最高。

### Work Context Cube

以 Goal、Sources、Rules、Tools、Permissions、Acceptance 描述 AI 工作現場。

### Artifact Engineering

把內容轉成可讀、可改、可驗證、可交付工件的設計與品質實務。

### Artifact Fidelity

語意、結構、視覺、運算與操作五種工件保真度。

### Artifact Fidelity Loop

Ingest、Model、Build、Render、Inspect 的工件生成與驗收循環。

### Deck DNA Extraction

從參考簡報萃取字體、色彩、網格、版型、圖表與資訊密度等設計規則。

### Slide Contract

為每頁簡報定義 Message、Evidence、Visual Form、Speaker Move、Exit Line。

### Spreadsheet Causal Map

以 Inputs、Logic、Outputs、Checks 表達試算表的可重算因果關係。

### Artifact Debt

不可編輯、不可追溯、版本分裂與難以維護的工件負債。

### Repository as World

專案庫中的程式、文件、測試、設定與歷史共同形成 Agent 工作世界。

### Agent Contract

界定 Objective、Scope、Invariants、Tooling、Acceptance、Authority、Escalation 的委派契約。

### Least Tool Principle

只向 Agent 暴露完成當前任務所需的最小工具集合。

### Prototype Trap

把可展示原型誤認為可安全、可靠、長期營運的系統。

### Diff as Deliverable

以變更差異、理由、測試、風險與回復方式作為數位工作的交付核心。

### Publishability Gap

工件與可讓他人進入、使用、信任、維護的產品之間的落差。

### Site Outcome Brief

以 Audience、Job、Entry、Path、Data、Trust、Success、Boundary 定義網站結果。

### State-first Product Design

先設計使用者與系統狀態及轉換，再設計頁面。

### Reversible Delivery

每次發布都保留版本、驗收、監看與回復能力。

### PARA Multi-Agent Test

以 Parallelizable、Autonomous、Reviewable、Aggregatable 判斷任務是否適合多 Agent。

### Agent Work Package

提供子 Agent 問題、輸入、工具、邊界、Schema、證據、信心、預算與升級條件。

### Context Partitioning

把 Context 分成共享、局部、受限與衍生區域，降低成本、噪音與風險。

### Concurrency Budget

管理並行 Agent 數量、模型、深度、成本、停止與整合資源。

### Loop Ledger

保存任務、狀態、決策、版本、風險與交接的共享循環帳本。

### AI Runtime Stack

Model、Context、Tool、State、Orchestration、Artifact、Guardrail、Observability、Evaluation 九層架構。

### Context Sufficiency

追求完成任務所需的充分 Context，而不是使用最大 Context。

### Cost per Accepted Outcome

用總模型、工具、重試與人工成本除以通過驗收成果，衡量真實效率。

### Cache Debt

快取前綴頻繁變動、寫入多、重用少，反而增加成本的負債。

### Data Context Ladder

將資料分成 Public、Internal、Confidential、Restricted、Workflow Prohibited。

### Action Risk Ladder

將動作分成 Explain、Draft、Local Change、External Write、High-impact／Irreversible。

### Guardrail Stack

Identity、Input／Context、Model Policy、Tool Boundary、Output／Action Validation、Monitoring 六層護欄。

### Change Envelope

允許變更、禁止不變條件、核准動作與最終差異的系統邊界。

### HOL Control Plane

Human on Loop 的 Outcome、Policy、Context、Portfolio、Telemetry、Intervention & Learning 六個控制面。

### Loop Literacy

Outcome、Context、Model、Tool、Evaluation、Risk、Orchestration、Learning 八種循環素養。

### Exception Budget

決定哪些例外由系統處理、哪些轉人工，以及何時值得投入自動化。

### Loop Debt

回饋未被轉成 Context、Skill、Eval、工具與政策改進，導致重複犯錯的債。

### Loop Moat

由獨特 Context、工具、Evals、Skills、工件標準與回饋節奏形成的競爭護城河。

## D-3｜十二章演講一句話

1. **工作方式更新**：GPT-5.6 的關鍵不是答案更漂亮，而是開始承接成果。
2. **模型路由**：不要永遠選最強，應把能力放在最值得的任務。
3. **推理層級**：把推理當成資源，而不是身份象徵。
4. **ChatGPT Work**：ChatGPT 開始進入資料與工具所在的工作現場。
5. **Outcome Engineering**：少一點形容詞，多一點可驗收條件。
6. **工件革命**：看起來完成與真的可以交付，中間隔著渲染與檢查。
7. **Codex**：程式碼是數位工作者的語言，不是它的工作邊界。
8. **Sites**：成果能被別人進入、操作與更新，才開始成為產品。
9. **Multi-Agent**：多 Agent 的成熟，不是更多 AI 說話，而是工作有介面與整合責任。
10. **API 架構**：架構師設計的，是不確定性如何被看見、限制與改善。
11. **安全治理**：會做不等於被授權做；速度留給可逆工作，慎重留給高影響決策。
12. **Human on Loop**：人不必卡在每一步，但必須守住循環的方向與責任。

## D-4｜90 分鐘演講結構

### 0–10 分鐘：為什麼 GPT-5.6 不是一次模型更新

從 Copy-Paste Cliff 與 Answer-to-Outcome Shift 建立張力。

### 10–25 分鐘：Sol、Terra、Luna 與推理資源

用 Model Routing Triangle 與 Reasoning Escalation Ladder，教聽眾做選擇。

### 25–40 分鐘：Work、Codex、Sites

展示 Chat → Work → Codex → Sites 的成果鏈。

### 40–55 分鐘：Outcome、Context 與工件

用 Outcome Contract、Work Context Cube、Artifact Fidelity Loop 示範一個真實專案。

### 55–68 分鐘：Multi-Agent 與 Runtime Stack

說明工作包、Context 分區、根 Agent、Trace 與 Evals。

### 68–80 分鐘：安全與 Human on Loop

用 Data／Action Ladder、Guardrail Stack、HOL Control Plane 說明人的新位置。

### 80–90 分鐘：行動

請聽眾選一個每週重複工作，寫出 Outcome、最小 Context、可逆步驟與第一個 Eval。

## D-5｜一句結尾

> ChatGPT 的第一個時代教我們如何跟 AI 說話；GPT-5.6 之後，我們要學會替 AI 建立一個能工作、能被看見、也能持續變好的世界。
