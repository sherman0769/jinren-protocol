# 第 8 章金句庫｜Antigravity 與 Codex：兩種 Agentic AI 的產品哲學

1. 工具選型其實是工作流選型。
2. 不要問哪個 AI 最強，要問哪個工作流最對。
3. Antigravity 像本地調度台，Codex 像雲端工作者。
4. 富媒體 Artifacts 建立理解，乾淨 Diff 追求交付效率。
5. AI 架構師不推銷品牌，而是配置工作節奏。
