chapter_08 README

章名：Antigravity 與 Codex：兩種 Agentic AI 的產品哲學
資料來源觸發點：來源觸發點：PDF 第 5-7 頁的 Google Antigravity 2.0 與 OpenAI Codex 技術對比表、Artifacts 信任建立與本地實時交互/雲端沙盒 PR 自動化差異。

檔案內容：
- chapter_08_main.docx：章節正文 DOCX
- chapter_08_main.md：章節正文 Markdown
- chapter_08_speech_notes.md：演講轉化筆記
- chapter_08_slide_outline.md：投影片大綱
- chapter_08_quotes.md：金句庫
- chapter_08_loop_canvas.md：Loop Canvas

估算字數：1851 個非空白字元
用途：個人內化、演講備稿、課程拆解、企業內訓素材、後續正式出版改稿。
