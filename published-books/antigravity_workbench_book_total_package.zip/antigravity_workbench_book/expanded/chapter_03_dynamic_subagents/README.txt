chapter_03 README

章名：Dynamic Subagents：不要讓一個 AI 背完整個世界
資料來源觸發點：來源觸發點：PDF 第 2 頁描述動態子智慧體、背景 Git Worktrees 與避免上下文視窗退化。

檔案內容：
- chapter_03_main.docx：章節正文 DOCX
- chapter_03_main.md：章節正文 Markdown
- chapter_03_speech_notes.md：演講轉化筆記
- chapter_03_slide_outline.md：投影片大綱
- chapter_03_quotes.md：金句庫
- chapter_03_loop_canvas.md：Loop Canvas

估算字數：1763 個非空白字元
用途：個人內化、演講備稿、課程拆解、企業內訓素材、後續正式出版改稿。
