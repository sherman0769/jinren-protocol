chapter_05 README

章名：Skills 與 Plugins：把一次成功變成可重複能力
資料來源觸發點：來源觸發點：PDF 第 3-5 頁描述 Agent Skills、Progressive Disclosure、SKILL.md、全局與專案作用域，以及大規模技能安裝警告。

檔案內容：
- chapter_05_main.docx：章節正文 DOCX
- chapter_05_main.md：章節正文 Markdown
- chapter_05_speech_notes.md：演講轉化筆記
- chapter_05_slide_outline.md：投影片大綱
- chapter_05_quotes.md：金句庫
- chapter_05_loop_canvas.md：Loop Canvas

估算字數：1916 個非空白字元
用途：個人內化、演講備稿、課程拆解、企業內訓素材、後續正式出版改稿。
