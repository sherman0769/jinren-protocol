chapter_04 README

章名：Artifacts 與 Browser Subagent：信任不是相信，而是看得見
資料來源觸發點：來源觸發點：PDF 第 2-3 頁描述 Browser Subagent、截圖與錄影；第 6 頁描述 Artifacts 用於建立信任。

檔案內容：
- chapter_04_main.docx：章節正文 DOCX
- chapter_04_main.md：章節正文 Markdown
- chapter_04_speech_notes.md：演講轉化筆記
- chapter_04_slide_outline.md：投影片大綱
- chapter_04_quotes.md：金句庫
- chapter_04_loop_canvas.md：Loop Canvas

估算字數：1834 個非空白字元
用途：個人內化、演講備稿、課程拆解、企業內訓素材、後續正式出版改稿。
