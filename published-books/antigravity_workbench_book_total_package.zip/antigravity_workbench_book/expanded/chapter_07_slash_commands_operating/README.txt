chapter_07 README

章名：Slash Commands：從一句 Prompt 到一套操作語言
資料來源觸發點：來源觸發點：PDF 第 7-8 頁整理 /goal、/grill-me、/schedule、/browser 四種斜線指令與使用時機。

檔案內容：
- chapter_07_main.docx：章節正文 DOCX
- chapter_07_main.md：章節正文 Markdown
- chapter_07_speech_notes.md：演講轉化筆記
- chapter_07_slide_outline.md：投影片大綱
- chapter_07_quotes.md：金句庫
- chapter_07_loop_canvas.md：Loop Canvas

估算字數：1917 個非空白字元
用途：個人內化、演講備稿、課程拆解、企業內訓素材、後續正式出版改稿。
