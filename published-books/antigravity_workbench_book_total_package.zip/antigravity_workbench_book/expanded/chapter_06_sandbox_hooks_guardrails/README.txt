chapter_06 README

章名：Sandbox、Hooks 與權限：讓 AI 安心工作，先要懂得設邊界
資料來源觸發點：來源觸發點：PDF 第 3 頁描述本地 hooks.json、JSON Hooks、Default/Full Machine/Unrestricted 權限，以及第 3-4 頁的能力邊界。

檔案內容：
- chapter_06_main.docx：章節正文 DOCX
- chapter_06_main.md：章節正文 Markdown
- chapter_06_speech_notes.md：演講轉化筆記
- chapter_06_slide_outline.md：投影片大綱
- chapter_06_quotes.md：金句庫
- chapter_06_loop_canvas.md：Loop Canvas

估算字數：1900 個非空白字元
用途：個人內化、演講備稿、課程拆解、企業內訓素材、後續正式出版改稿。
