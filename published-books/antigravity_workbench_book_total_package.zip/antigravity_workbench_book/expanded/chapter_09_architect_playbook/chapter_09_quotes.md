# 第 9 章金句庫｜AI 架構師的 Antigravity 工作法：把工具看成 Runtime Stack

1. 當 AI 只是聊天，Prompt 就夠了；當 AI 開始工作，Runtime Stack 才是重點。
2. 工具是入口，Runtime 才是工作現場。
3. Agentic AI 的導入，不是裝外掛，而是設計作業系統。
4. AI 架構師不是接模型的人，是設計 AI 工作現場的人。
5. 成功流程若不能沉澱成 Skill，就只是一次漂亮展示。
