# 第 9 章投影片大綱｜AI 架構師的 Antigravity 工作法：把工具看成 Runtime Stack

## Slide 1｜章名與核心問題
- 章名：AI 架構師的 Antigravity 工作法：把工具看成 Runtime Stack
- 核心問題：這個工具變化背後，真正改變的是什麼工作方式？

## Slide 2｜舊方法的天花板
- 很多企業導入 AI 仍把問題簡化成「買哪個帳號」或「訓練員工下 Prompt」。但 Agentic AI 進入工作後，帳號與 Prompt 只是入口。真正的問題包括：代理在哪裡執行？資料從哪裡來？可調用哪些工具？誰批准高風險動作？怎麼留下證據？哪些能力要封裝成 Skill？怎麼把成功流程推給整個團隊？若這些沒設計，導入只會停在示範。...

## Slide 3｜新觀念
- 本章提出「AI Runtime Stack」。AI 架構師要把每個工具拆成層：任務層、代理層、工具層、技能層、證據層、治理層、學習層。當你用 Stack 看工具，就不會被單點功能吸走，而能判斷它在整個工作系統中扮演什麼角色。...

## Slide 4｜模型：AI Runtime Stack 七層
- Task Layer：任務如何被定義、拆解、排程與驗收。
- Agent Layer：哪些代理負責規劃、執行、測試、瀏覽、整理與合併。
- Tool Layer：代理能使用哪些 IDE、CLI、瀏覽器、MCP、API 與本地腳本。
- Skill Layer：哪些流程被封裝成可重複技能。
- Evidence Layer：代理交出哪些 Artifacts、Diff、截圖、測試與報告。
- Governance Layer：權限、Hooks、沙箱、批准、稽核與回滾。
- Learning Layer：成功案例如何沉澱成知識庫、技能與團隊標準。

## Slide 5｜實際情境
- 你可以把這章直接改成企業顧問簡報。先畫出客戶現有流程，再把 AI Runtime Stack 疊上去：任務從哪裡進來，代理在哪裡工作，工具怎麼接，成果怎麼證明，風險怎麼擋，經驗怎麼沉澱。這會讓客戶明白：導入 Agentic AI 不是裝外掛，而是設計一套新型工作作業系統。...

## Slide 6｜金句收束
- 當 AI 只是聊天，Prompt 就夠了；當 AI 開始工作，Runtime Stack 才是重點。
- 工具是入口，Runtime 才是工作現場。
- Agentic AI 的導入，不是裝外掛，而是設計作業系統。
