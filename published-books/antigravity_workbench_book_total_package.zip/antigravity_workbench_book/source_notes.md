# Source Notes｜資料來源與校準說明

## 主要資料來源
使用者上傳 PDF：《Google Antigravity 2.0 深度技術解析與多智慧體協作實戰指南》（10 頁）。

## 本書如何使用資料
本書沒有逐字翻譯原資料，而是將其轉化成一本給 AI 架構師與講師閱讀的內化書稿。資料中的產品資訊主要被轉化成以下方法論：

1. 從 Agentic IDE 到多智慧體工作台：由單一編輯介面轉向任務編排介面。
2. Dynamic Subagents：任務分工、隔離工作區與上下文管理。
3. Browser Subagent 與 Artifacts：以可視化證據建立信任。
4. Agent Skills 與 Plugins：把一次成功封裝成可重複能力。
5. Sandbox、Hooks 與權限：讓 AI 能被放心委派。
6. Slash Commands：把 Prompt 轉成操作模式。
7. Antigravity 與 Codex 對比：從工具選型轉成工作流選型。

## 重要限制
資料中涉及版本、價格、訂閱額度、模型名稱、性能跑分與平台限制等項目，均屬於高度變動資訊。本書將其視為「理解工作流變化的案例」，不把任何數字寫成永久事實。正式公開出版前，建議再次以官方文件校準。

## 官方校準紀錄
本次產出前已查閱 Google Developers Blog 與 Google Antigravity 官方相關公開頁面，以確認 Antigravity 作為 agentic development platform、Editor View / Manager Surface、Artifacts、Antigravity CLI、Subagents、Hooks、Agent Skills、SDK 等主軸與公開描述相容。正式出版時仍建議補上完整參考文獻格式。

## 可轉化為課程的主題
- 多智慧體工作台思維
- Agentic Runtime Stack
- Skill 設計與 Context Diet
- Artifacts 證據鏈
- AI 權限階梯與 Guardrails
- Antigravity / Codex 工具哲學對位
