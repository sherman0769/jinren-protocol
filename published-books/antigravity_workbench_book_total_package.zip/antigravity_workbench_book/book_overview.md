# 站在多智慧體工作台之上

## 副標
從 Google Antigravity 2.0 看 AI 架構師的下一代工作法

## 定位
這是一本給李詩民作為 AI 架構師、講師與出書專案總編輯閱讀的個人內化書稿。它以使用者提供的《Google Antigravity 2.0 深度技術解析與多智慧體協作實戰指南》為主資料來源，並把其中關於 Antigravity 2.0、Dynamic Subagents、Browser Subagent、Artifacts、Agent Skills、Plugins、Hooks、Slash Commands 與 Antigravity / Codex 對比的技術內容，轉化成「多智慧體工作台」的方法論。

## 這本書不寫成什麼
- 不寫成單純工具教學。
- 不寫成 Google 產品宣傳。
- 不把價格、跑分、上限等易變資訊當成永久結論。
- 不只寫給工程師，而是寫給能設計 AI 工作流的人。

## 全書核心答案
下一階段的 AI 能力，不只是會使用工具，而是能設計一個讓多個 AI 工作者安全、可審查、可重複、可累積的工作現場。人類的角色不是消失，而是站在工作台之上，負責意圖、邊界、證據、審查與整合。

## 章節清單
| 章 | 章名 | 字元估算 | ZIP |
|---|---|---:|---|
| 1 | 從 IDE 到 Agentic Workbench：開發工具正在換一種形狀 | 2185 | 01_agentic_platform_shift.zip |
| 2 | Manager Surface：真正的主角不是程式碼，而是任務 | 1815 | 02_manager_surface.zip |
| 3 | Dynamic Subagents：不要讓一個 AI 背完整個世界 | 1763 | 03_dynamic_subagents.zip |
| 4 | Artifacts 與 Browser Subagent：信任不是相信，而是看得見 | 1834 | 04_artifacts_browser_verification.zip |
| 5 | Skills 與 Plugins：把一次成功變成可重複能力 | 1916 | 05_skills_plugins_context.zip |
| 6 | Sandbox、Hooks 與權限：讓 AI 安心工作，先要懂得設邊界 | 1900 | 06_sandbox_hooks_guardrails.zip |
| 7 | Slash Commands：從一句 Prompt 到一套操作語言 | 1917 | 07_slash_commands_operating.zip |
| 8 | Antigravity 與 Codex：兩種 Agentic AI 的產品哲學 | 1851 | 08_tool_strategy_antigravity_codex.zip |
| 9 | AI 架構師的 Antigravity 工作法：把工具看成 Runtime Stack | 2031 | 09_architect_playbook.zip |
| 10 | 站在多智慧體工作台之上：從帶工具到帶工作流 | 1945 | 10_human_on_agent_workbench.zip |

## 使用方式
先讀 full_book.docx 或 full_book.md 形成整體理解；再依需求打開單章 ZIP，使用 main、speech_notes、slide_outline、quotes 與 loop_canvas 拆成演講、課程、社群長文或企業內訓教材。
