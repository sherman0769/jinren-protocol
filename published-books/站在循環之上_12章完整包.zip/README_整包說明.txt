《站在循環之上》12章完整 ZIP 包

本壓縮檔包含：
- 00_delivery_manifest.txt：交付清單與字數統計
- 01～12 章各自獨立 ZIP 檔

每章 ZIP 內含：
- chapter_XX_main.docx
- chapter_XX_main.md
- chapter_XX_speech_notes.md
- chapter_XX_slide_outline.md
- chapter_XX_quotes.md
- chapter_XX_loop_canvas.md
- README.txt
