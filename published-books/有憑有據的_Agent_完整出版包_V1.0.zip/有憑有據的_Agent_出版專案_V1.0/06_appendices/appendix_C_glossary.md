# 附錄 C｜核心名詞與中英文對照

本附錄整理全書重要名詞。部分詞彙源自論文與既有標準，部分則是本書提出的工作概念；兩者的性質不同，不應混為一談。

## Agent／AI Agent

能夠根據目標規劃步驟、使用工具、讀寫狀態並採取行動的 AI 系統。本書不以「是否完全自主」作為唯一判準，而關注它是否能改變外部狀態。

## Agent Runtime

承載 Agent 規劃、狀態、工具呼叫、權限、路由、記錄與執行控制的運作層。Runtime 不等於單一產品，也不只是一段模型 API 呼叫。

## Payload

資料主要內容，例如價格、數量、姓名、政策文字或模型輸出。Payload 格式正確，不代表資料仍然有效。

## Metadata

描述資料來源、時間、版本、狀態、單位、權限、lineage 與適用範圍的資訊。Metadata 也可能缺失或錯誤，不能被假設為天然可靠。

## Metadata-borne Defect

主要辨識訊號位於 Metadata 或 companion evidence 的資料缺陷。若判斷機制未取得這些訊號，Payload 可能看起來完全合理。

## Runtime Data-Quality Gating

在 Agent 即將採取行動時，依資料品質條件決定准入、阻擋、降權、升級或替代的機制。此概念是 SARC-DQ 論文的核心。

## Predicate

可被執行與測試的條件，例如 freshness、schema conformity、lineage present 或 cross-source consistency。Predicate 的價值取決於訊號、門檻、執行位置與失敗路由。

## Freshness

資料相對於任務是否仍在允許時效內。它需要可靠時間戳與任務級 max_age，不能只看「最近修改日期」。

## Lineage／Data Lineage

資料從來源到目前狀態所經歷的轉換與關聯。對 Agent 治理而言，lineage 還要能連接到實際行動與主張。

## Provenance

描述資料、活動與責任主體如何形成關係的來源資訊。W3C PROV 提供通用表示模型；本書不要求所有系統必須採用 PROV-O 才能建立追溯。

## Golden Record

被指定為某個實體或決策領域的權威紀錄。Golden Record 的唯一性與現行性必須可被檢查，否則「權威」只是一個標籤。

## Downstream-Only Remediation

不直接覆寫上游原始資料，而在下游建立隔離、替代與具版本的受治理紀錄，同時保存 Agent 實際使用的 evidence set。此設計有助於重建事件，但不能取代上游修正。

## Evidence Packet

針對一項主張整理的證據集合，包含來源、版本、片段、適用範圍、支持材料、反駁材料與擷取資訊。

## Evidence Ledger

記錄 claim、evidence packet、支持關係、信心、理由、作者路由與審核結果的可追蹤帳本。它適合做風險分流，不是自動真理裁判。

## Claim

可被判斷、支持、反駁或修正的具體主張。較好的 claim 通常只包含一個主要命題，並保留文件位置與版本。

## Supports

目前 evidence packet 在必要範圍內支持主張。

## Contradicts

目前 evidence packet 與主張直接衝突。

## Missing Evidence

目前證據不足以支持或判斷主張，不等同於已證明主張為假。

## Mixed Evidence

支持與反駁證據並存，或結果會因群體、時間、方法與條件而異。Evidence-Ledger 論文的測試中，這也是較難判定的類別。

## Route／Author Route

關係判定後的下一步，例如保留、改寫、補找、降強度、呈現爭議、刪除或升級人工處理。

## Trace

系統事件與關聯紀錄。在本書中，完整 Trace 要同時連接技術行為與證據關係，例如來源、工具呼叫、行動、主張、審核與發布版本。

## Observability

對系統執行狀態的可觀測能力，例如 latency、token、tool call、error 與 run history。Observability 很重要，但若沒有來源版本與主張對證據的關係，仍不等於完整證據鏈。

## Human in the Loop

人類位於任務流程內，通常逐筆參與、批准或修正。適合高風險與複雜例外，但大量使用可能造成延遲與橡皮圖章式審核。

## Human on the Loop

人類主要設計條件、監測系統、處理例外並批准高影響行動，而不必逐筆重做 Agent 工作。本書將它視為責任配置方式，不是完全移除人類。

## Incompetence Shield

SARC-DQ 用來描述的反直覺現象：能力較差的 Agent 因未能忠實利用資料，可能偶然沒有把錯誤資料轉成行動缺陷。這不是安全策略，也不能推論弱模型更可信。

## Dual-Gate Evidence Loop／雙閘門證據迴路

本書根據兩篇核心論文整合提出的工作概念：第一閘門控制資料能否支持行動，第二閘門控制證據能否支持主張，再由人類處理例外與高風險釋出。它不是既有國際標準或兩篇論文共同命名的正式模型。

## Minimum Evidence Condition for Action／行動前最低證據條件

本書工作概念。指 Agent 採取特定行動前，在當時風險與任務下必須通過的最低資料與證據條件。

## Claim Release Condition／主張釋出條件

本書工作概念。指重要主張離開草稿區前，在支持關係、來源品質、語氣強度與人工批准上必須符合的條件。

## Evidence Infrastructure／證據基礎設施

讓多個 Agent 與工作流共用來源登錄、資料契約、predicate、ledger、Trace、審核路由與評測能力的組織級基礎設施。它是一組責任與能力，不必等於單一集中式平台。
