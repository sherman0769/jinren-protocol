# 附錄 B｜Evidence Ledger 可直接套用模板

Evidence Ledger 的目標，是讓一項重要主張在離開系統前，可以被追問、被修正、被退回，也能回到當時使用的證據。它不是替文件增加一欄「參考資料」，更不是把網址堆成一份看似嚴謹的清單。

以下模板可用於文章、政策公告、研究摘要、企業報告、教材、客服知識與 Agent 決策理由。欄位可以依情境縮減，但不要刪掉版本、來源與路由，使帳本失去追溯能力。

## 一、最小資料模型

```yaml
ledger_entry_id: EL-20260731-0001
agent_run_id: RUN-20260731-0142
document_id: DOC-20260731-003
claim:
  claim_id: CLM-0007
  text: "導入新補貨方案後，預估本月採購成本可降低 12%。"
  type: quantitative
  importance: high
  location: "決策摘要第 2 段"
  version: 3
  created_by: agent
  created_at: "2026-07-31T09:18:00+08:00"
context:
  preceding_text: "根據目前需求預測與新版供應商報價，"
  following_text: "但仍需觀察需求波動。"
evidence_packet:
  packet_id: EVP-0007
  sources:
    - source_id: SRC-PRICE-20260731
      source_version: "v5"
      source_type: governed_table
      title: "供應商有效報價"
      locator: "rows 18-26"
      retrieved_at: "2026-07-31T09:12:00+08:00"
      valid_from: "2026-07-30"
      valid_until: "2026-08-06"
      excerpt: "..."
      provenance_status: complete
    - source_id: SRC-BASELINE-202606
      source_version: "final"
      source_type: report
      title: "六月採購基準"
      locator: "table 4"
      excerpt: "..."
      provenance_status: complete
  counter_evidence: []
  packet_created_at: "2026-07-31T09:19:00+08:00"
adjudication:
  relation: Supports
  confidence: 0.86
  rationale: "新版報價與六月基準可重算出 11.7%，四捨五入為 12%；需在正文標明比較基準。"
  adjudicator: evidence_agent_v1.3
  adjudicated_at: "2026-07-31T09:20:00+08:00"
quality:
  source_quality: high
  evidence_completeness: sufficient
  scope_match: partial
  freshness: pass
  conflict_status: none
route:
  route_type: Revise
  recommended_action: "補上『相較六月基準』並將 12% 改為約 12%。"
  risk_level: medium
  human_review_required: true
review:
  reviewer_id: PURCHASING-MANAGER-07
  decision: approved_after_revision
  comment: "已補比較基準。"
  reviewed_at: "2026-07-31T10:04:00+08:00"
release:
  release_version: "DOC-20260731-003-v4"
  released_claim_text: "相較六月基準，本月採購成本預估可降低約 12%。"
  released_at: "2026-07-31T10:10:00+08:00"
```

## 二、欄位設計說明

### 1. Claim

`claim.text` 保存要被判斷的命題。主張粒度過大時，relation 會失去意義。例如：

> 本方案成本更低、風險更小，也能改善顧客滿意度。

這句至少包含三項主張，可能各自需要不同證據。較好的拆法是：

1. 本方案的預估成本低於目前方案。
2. 本方案可降低某一類已定義風險。
3. 本方案預期改善某項可量測的顧客指標。

`claim.type` 可採下列分類：

- `quantitative`：包含數字、比例、排名、金額或數量。
- `temporal`：日期、版本、先後順序與時效。
- `causal`：宣稱 A 導致 B。
- `comparative`：優於、快於、便宜於、更多或更少。
- `policy`：規則、資格、權利、義務與程序。
- `predictive`：未來結果、風險與機率。
- `attribution`：某人、某組織或某研究提出什麼。
- `interpretive`：作者對資料的解讀。
- `recommendation`：建議採取某項行動。

分類不等同真假，但能幫助系統選擇檢查方式。例如 causal claim 不能只靠同時發生的兩組數字，policy claim 則必須確認版本與適用對象。

### 2. Evidence Packet

Evidence packet 是裁決當下真正呈現給系統或人類的證據集合。它應保存：

- 來源身分。
- 來源版本。
- 具體定位與片段。
- 擷取時間。
- 有效期間。
- provenance 狀態。
- 支持與反駁材料。

不要只存搜尋結果標題，也不要只存整份文件的 URL。若未保存使用片段與版本，來源後來更新時，就無法重建當時判斷。

### 3. Adjudication

`relation` 建議至少保留四種狀態：

#### Supports

證據在必要範圍內支持主張。這不代表主張永遠正確，只代表目前 evidence packet 足以支持目前文字。

#### Contradicts

證據與主張直接衝突。例如主張說政策適用至十二月，現行公告明確寫到九月截止。

#### Missing Evidence

目前封包不足以判斷或支持主張。它可能表示尚未找到來源、來源沒有涵蓋該細節，或主張強度高於證據。

#### Mixed Evidence

支持與反駁材料並存，或不同來源、群體、時間與方法得到不同結果。這類主張通常需要呈現條件與爭議，不能被迫選一邊。

### 4. Confidence

信心應代表「在目前 evidence packet 下，對 relation 判定的把握」，不能被誤解為主張為真的機率。

即使 `Supports + 0.95`，仍可能因來源版本錯誤而不得發布；即使 `Mixed + 0.60`，也可能因高風險而必須優先人工處理。信心只是路由訊號之一。

### 5. Route

常用路由可定義為：

- `Keep`：保留原文。
- `Revise`：修改範圍、數字、基準或語氣。
- `Search`：補找證據。
- `Qualify`：增加條件、限制與不確定性。
- `Present_Disagreement`：呈現不同證據與爭議。
- `Delete`：刪除沒有必要又無法支持的主張。
- `Escalate`：送交領域、法遵或決策角色。
- `Block_Release`：禁止進入正式版本。

## 三、關係裁決問題清單

對每一項主張，依序詢問：

1. 證據是否直接談到同一個對象？
2. 時間範圍是否一致？
3. 地理、族群、產品版本與適用條件是否一致？
4. 主張的數字是否能從證據重算？
5. 比較基準是否清楚？
6. 來源只描述相關性，主張是否寫成因果？
7. 來源說「可能」，主張是否寫成「一定」？
8. 來源只支持部分情況，主張是否擴張到全部？
9. 是否存在具同等或更高可信度的反駁來源？
10. 來源本身是否仍為有效版本？

前八題主要處理語意支持，後兩題把 Evidence Ledger 接回第一道資料品質閘門。

## 四、主張強度校正表

| 證據狀態 | 不適當寫法 | 較合適處理 |
|---|---|---|
| 證據充分且範圍一致 | 過度保守到失去資訊 | 清楚陳述並標明基準 |
| 支持部分情況 | 宣稱適用全部 | 加上對象、時間與條件 |
| 只有相關性 | 宣稱造成結果 | 改寫為相關、伴隨或觀察到 |
| 預測模型輸出 | 寫成已發生事實 | 標示預估、區間與假設 |
| 來源互相衝突 | 任選一邊當定論 | 呈現分歧與可能原因 |
| 找不到足夠來源 | 用流暢文字掩蓋 | 補證據、降強度或刪除 |
| 來源已被取代 | 繼續引用舊版 | 更新來源並重新裁決 |

## 五、人工審核卡模板

```markdown
### 待審主張

**主張：**

**文件位置：**

**重要性／風險：**

**目前關係：** Supports / Contradicts / Missing Evidence / Mixed Evidence

**系統信心：**

**需要注意的原因：**

**支持證據：**
- 來源、版本、片段

**反駁或限制證據：**
- 來源、版本、片段

**建議動作：**
- 保留／改寫／補證據／降低強度／呈現爭議／刪除／升級

**允許的覆寫範圍：**

**審核決定：**

**審核理由：**

**審核者與時間：**
```

## 六、假設案例一：公部門補助公告

### 原始主張

> 年滿六十五歲的市民都可以申請本項交通補助。

### Evidence Packet

- 現行計畫公告：補助對象為設籍本市、年滿六十五歲，並符合特定所得條件者。
- FAQ 舊版：僅寫「本市六十五歲以上市民」。
- 新版公告的發布日期晚於 FAQ，且明示取代舊版說明。

### 裁決

- Relation：`Contradicts`
- 理由：原始主張漏掉設籍與所得條件；舊 FAQ 已被取代。
- Route：`Revise + Block_Release`

### 修正版

> 設籍本市、年滿六十五歲，且符合現行計畫所得條件者，可依規定申請交通補助。

這個案例說明，句子可能被某份舊文件表面支持，仍會因第一道閘門的版本檢查而失去資格。

## 七、假設案例二：AI 研究摘要

### 原始主張

> 使用 AI 助教能顯著提升所有學生的學習成績。

### Evidence Packet

- 研究 A：在特定大學課程、八週實驗中，平均測驗成績提高。
- 研究 B：另一群體的結果不顯著。
- 研究 A 未涵蓋中小學，也沒有證明所有學生均受益。

### 裁決

- Relation：`Mixed Evidence`
- 理由：不同研究結果不一致，且原句把特定課程平均結果擴大到所有學生。
- Route：`Qualify + Present_Disagreement`

### 修正版

> 部分課程研究觀察到 AI 助教與平均測驗成績提升相關，但效果會因學習情境與學生群體而異，目前不足以推論所有學生都能獲得同等改善。

## 八、版本與生命週期

Evidence Ledger 不能在內容發布後就被封存。以下事件應觸發重新裁決：

- 來源被撤回、修訂或取代。
- 政策、價格、資格或產品版本更新。
- 新的反駁證據出現。
- 主張被重新使用到不同對象或情境。
- Agent 或裁決模型版本重大更新。
- 人工審核發現系統性誤路由。

重新裁決時，不要覆寫舊結果。應建立新 ledger entry 或新 adjudication version，保留當時證據與決定。只有這樣，組織才能同時回答「現在應該怎麼說」與「當時為什麼那樣說」。

## 九、最小可行導入

若團隊還無法建立完整平台，可以從一張表開始，欄位至少保留：

```text
claim_id
claim_text
claim_type
importance
source_id
source_version
evidence_excerpt
relation
confidence
rationale
route
reviewer
decision
released_text
release_version
```

先把最重要的數字、日期、政策、因果與公開承諾放進表裡。等流程穩定後，再接入自動抽取、來源追溯、版本事件與風險化路由。

工具可以簡單，責任關係不能模糊。Evidence Ledger 真正有價值的地方，不在於表格多漂亮，而在於每項重要主張都必須回答：我憑什麼這樣說，證據到哪裡為止，誰決定它可以離開系統。
