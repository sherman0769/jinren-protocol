# 名詞登錄表

| 中文 | 英文 | 本書定義與使用規則 |
|---|---|---|
| AI Agent | AI Agent / agentic system | 能讀取環境、使用工具、形成計畫並採取行動的 AI 系統。不是所有聊天機器人都屬於本書所說的 Agent。 |
| 執行期 | Runtime | 系統實際接收資料、推理、呼叫工具與採取行動的運作階段。 |
| 資料品質閘門 | Runtime Data-Quality Gate | 在行動點附近，以可執行條件檢查資料品質，並決定阻擋、降權、送審或替代。 |
| Payload | Payload | 直接提供給消費者或模型的欄位值與內容。保留英文以避免和一般「內容」混淆。 |
| 中繼資料 | Metadata | 關於資料的新鮮度、版本、來源、血緣、建立時間、適用範圍等描述。 |
| 資料血緣 | Lineage | 資料從何而來、經過哪些轉換、形成哪個版本以及被哪次行動使用的可追蹤鏈。 |
| 來源追溯 | Provenance | 用來描述某項資料或產物的來源、生成活動、責任主體與演變脈絡。 |
| 黃金紀錄 | Golden Record | 組織對某一實體指定的權威主紀錄；若同時存在多個互相衝突的黃金紀錄，代表治理失效。 |
| Predicate | Predicate | 可被程式判定真假的條件，例如 freshness(max_age) 或 schema_conformant。正文多譯為「檢查條件」。 |
| 行動缺陷率 | Action-Defect Rate, ADR | SARC-DQ 用來量測資料缺陷被轉成重大行動偏差的比例。不得直接當作企業事故率。 |
| 無能保護罩 | Incompetence Shield | 能力較差的 Agent 因沒有忠實使用錯誤訊號，偶然避開錯誤行動的現象；不是值得追求的安全策略。 |
| 主張 | Claim | 可被支持、反駁或要求證據的陳述單位。 |
| 證據包 | Evidence Packet | 與特定主張配對、供裁決者判定支持關係的一組證據材料。 |
| 支持關係 | Support Relation | Supports、Contradicts、Missing Evidence、Mixed Evidence 四種標準化關係。 |
| 證據帳本 | Evidence Ledger | 記錄主張、證據包、支持關係、路由、信心與理由的可稽核中間產物。 |
| 審核路由 | Review Route | 根據風險與支持關係，把項目送往保留、修改、補證據、人工確認或停止發布的流程。 |
| Human in the Loop | Human in the Loop | 人類直接參與單次任務的某個決策或操作。 |
| Human on the Loop | Human on the Loop | 人類監督整個迴路，設定條件、處理例外、審核高風險項目並持續校準。 |
| 雙閘門證據迴路 | Dual-Gate Evidence Loop | 本書整合提出的框架：資料進入推理前設准入閘門，主張離開系統前設釋出閘門。 |
| 行動前最低證據條件 | Minimum Evidence Condition for Action | 某項行動被允許前，資料需通過的最低條件組合。 |
| 主張釋出條件 | Claim Release Condition | 重要主張得以發布或用於決策前，需具備的證據與批准條件。 |
