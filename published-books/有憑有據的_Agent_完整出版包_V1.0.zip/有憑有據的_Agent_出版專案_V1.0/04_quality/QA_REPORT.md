# QA REPORT｜《有憑有據的 Agent》V1.0

檢查日期：2026-07-31  
專案狀態：PACKAGING → DELIVERED  
檢查範圍：正式 Markdown、全書 DOCX、研究登錄、章節衍生內容、附錄與交付包

## 一、總體判定

**通過。**

本版本已形成一本可完整閱讀、可朗讀、可授課並可轉化為企業方法論的技術書。全書核心主張明確，章節責任形成認知推進，研究事實與作者整合框架已分開標示，未虛構作者親身案例。

核心主張：

> 模型負責推理，證據系統負責決定哪些資料可以進入推理、哪些主張可以離開系統。

主要原創工作概念：

- 雙閘門證據迴路（Dual-Gate Evidence Loop）
- 行動前最低證據條件（Minimum Evidence Condition for Action）
- 主張釋出條件（Claim Release Condition）

以上均已明示為本書提出的工作概念，不冒充既有國際標準或兩篇論文共同提出的正式模型。

## 二、結構與章節任務

| 單元 | 唯一任務 | 判定 |
|---|---|---|
| 序章 | 建立 Agent 行動使錯誤性質改變的全書前提 | 通過 |
| 第一章 | 區分模型能力與證據完整性 | 通過 |
| 第二章 | 說明看似合理資料中的 Payload、Metadata 與可見性問題 | 通過 |
| 第三章 | 把資料治理轉成行動前可執行的 Runtime Gate | 通過 |
| 第四章 | 重新定義 AI 寫作後的驗證瓶頸 | 通過 |
| 第五章 | 拆解 Evidence Ledger 的資料單位、關係與路由 | 通過 |
| 第六章 | 將兩道閘門接成完整責任迴路 | 通過 |
| 第七章 | 重設 Human on the Loop 的監督責任 | 通過 |
| 第八章 | 將單一 Agent 推進為企業證據基礎設施 | 通過 |
| 結語 | 回收停止權、追溯與組織責任 | 通過 |

章與章之間依序完成「風險改變 → 能力迷思 → 資料可見性 → 第一閘門 → 驗證瓶頸 → 第二閘門 → 整合迴路 → 人類責任 → 企業基礎設施 → 責任結論」，未以關鍵字平均分配取代思想推進。

## 三、研究與事實查核

### 核心來源

- SARC-DQ：arXiv:2607.26313v1
- Evidence-Ledger Adjudication：arXiv:2607.26512v1
- NIST AI RMF 1.0
- NIST Generative AI Profile
- W3C PROV-O／PROV-DM

### 已核對事項

- 兩篇核心研究的題名、作者、版本、提交日期與預印本狀態。
- SARC-DQ 的補貨基準、四個模型層級、約十五倍推理價格、Metadata-borne defect 行動結果、六類 predicate、四種回應與 coverage gap。
- Evidence Ledger 的四種關係、2,335 筆盲測資料、relation accuracy 0.676、macro-F1 0.601、review-needed recall 0.885、1,270／1,435 路由結果、295／900 額外複查，以及 Mixed Evidence F1 0.289。
- NIST 與 W3C 僅作治理與 provenance 背景校準，未被描述成雙閘門架構的直接來源。

### 已保留限制

- 不把 arXiv 預印本寫成已通過正式同儕審查的普遍定論。
- 不把補貨基準數字外推到所有企業 Agent。
- 不把 Payload／Metadata 寫成永遠固定的二分法；可見性取決於表示、companion evidence 與檢查機制。
- 不把 Runtime Gate 寫成上游資料治理、資安、隱私或法遵的替代品。
- 不把 Evidence Ledger 寫成自動真理裁判。
- 明確指出未覆蓋 predicate、Metadata 退化、Mixed Evidence 與人工負擔等限制。

完整來源、用途與限制已登錄於 `03_research/research_registry.md` 與 `03_research/fact_check_notes.md`。

## 四、作者經驗與案例真實性

- 正文未虛構作者的企業導入、學員對話、演講現場、成果或數據。
- 採購、公部門、教育、研究、客服與供應鏈內容均以「假設情境」或一般情境呈現。
- Book Bible 保留三項 `【待補作者案例】`，只作未來擴充記錄，未進入正式正文。
- 作者觀點、論文發現、研究限制與原創框架已清楚區分。

判定：通過。

## 五、字數與內容完整性

- 正文（序章＋八章＋結語）：40,992 個去除 Markdown 後文字內容。
- 附錄：13,301 個去除 Markdown 後文字內容。
- 正文加附錄：54,293 個去除 Markdown 後文字內容。
- `full_book.md` 含出版說明、目錄與研究來源：55,875 個去除 Markdown 後文字內容。
- DOCX：A4，共 88 頁。

正文達到 Book Bible 設定的 40,000 至 60,000 規劃區間。詳細口徑與逐章統計見 `04_quality/word_count_report.md`。

## 六、去重、句型與語氣

- 長度至少 60 字的完全重複跨章段落：0 組。
- 4-gram cosine similarity ≥ 0.68 的跨章近似重複段落：0 組。
- 禁用空泛開場「在這個快速變化的時代」：0 次。
- 「未來已來」：0 次。
- `TODO`／`TBD`：0 次。
- 初稿中過多的「不是……而是……」已逐章改寫；正式正文僅保留 1 次，另有 8 次「不只是……而是……」，均經人工檢視。
- 核心概念只在定位、正式定義、實作與結論回收時重返，未以同義改寫湊字數。

詳細檢查見 `04_quality/duplication_check.md`。

## 七、名詞一致性

下列核心名詞已統一：

- Agent／AI Agent
- Agent Runtime
- Payload
- Metadata
- Metadata-borne Defect
- Runtime Data-Quality Gating
- Predicate
- Lineage／Provenance
- Evidence Packet
- Evidence Ledger
- Supports／Contradicts／Missing Evidence／Mixed Evidence
- Human in the Loop／Human on the Loop
- Dual-Gate Evidence Loop／雙閘門證據迴路

原文術語首次出現時搭配中文說明；本書工作概念的性質已註明。名詞表見 `00_project/terminology_registry.md` 與附錄 C。

判定：通過。

## 八、章節衍生內容

每一單元均包含：

- 正式章稿 `chapter_XX_main.md`
- 演講筆記 `chapter_XX_speech_notes.md`
- 簡報大綱 `chapter_XX_slide_outline.md`
- 金句 `chapter_XX_quotes.md`
- 模型畫布 `chapter_XX_model_canvas.md`
- 章節 README

序章、八章與結語共 10 個單元、60 份章節檔案，均存在且非空白。

判定：通過。

## 九、DOCX 技術與視覺驗證

### 結構驗證

- `python-docx` 可重新開啟。
- 1,640 個段落、3 個表格、2 個 section。
- DOCX 壓縮結構經 `unzip -t` 測試，無錯誤。
- 文件 metadata：題名與作者正確。
- 內部工具 citation token、`sandbox:`、`turn...`、TODO 與假文字未進入正式 DOCX。

### 視覺驗證

使用專案指定的 `render_docx.py` 完成 DOCX → PDF → PNG 渲染，共 88 頁；全部頁面均已逐頁檢視。

檢查結果：

- 中文與英文無缺字或異常代換。
- 章節均正確換頁，無多餘空白頁。
- 頁首頁尾與頁碼位置一致。
- 表格沒有超出頁面、截斷或重疊。
- 程式碼、YAML、ASCII 流程圖與長網址均能換行顯示。
- 引文框、清單與 checkbox 可辨識。
- 無文字裁切、物件重疊、孤立頁首或不可閱讀的灰階內容。

### 可及性稽核

- 高風險：0
- 中風險：0
- 低風險：8

八項低風險均為研究來源中以完整 URL 作為可見連結文字。此設計有利於紙本與離線辨識，保留於參考資料區；不影響內容或版面。

判定：通過。

## 十、待未來商業出版確認

以下不是本次交付缺件，而是進入出版社流程後的選項：

- 正式 ISBN、版權頁、出版社格式與法務校稿。
- 封面、推薦序、作者真實案例與商業版照片／圖像。
- 出版社指定引用格式與紙張、開本、出血設定。
- 核心預印本若有新版或正式出版，需要進行版本更新。

## 十一、交付完成條件

- [x] 正式 Markdown 來源完整。
- [x] 序章、八章、結語與四份附錄完整。
- [x] 研究與限制已登錄。
- [x] 字數達規劃區間。
- [x] 全書去重與名詞一致性完成。
- [x] DOCX 可開啟、可渲染並完成 88 頁視覺檢查。
- [x] 所有專案檔案非空白。
- [x] `delivery_manifest.txt` 與實際內容一致。
- [x] 最終 ZIP 可列出並通過解壓測試。

## 十二、最終判定

**V1.0 完成驗證，可正式交付。**
