# 《有憑有據的 Agent》完整出版專案包

副標：從資料品質閘門、證據帳本到可信 AI 工作流  
作者：李詩民  
版本：V1.0  
日期：2026-07-31

## 專案內容

- `00_project/`：Book Bible、風格、名詞、進度與變更紀錄
- `01_master/`：全書正式 Markdown 與 DOCX
- `02_chapters/`：序章、八章、結語及各章演講／簡報／金句／模型畫布
- `03_research/`：研究登錄與事實查核
- `04_quality/`：字數、去重與 QA 報告
- `05_delivery/`：交付清單
- `06_appendices/`：導入檢核表、Ledger 模板、名詞表與研究更新說明

## 單一正式內容來源

正式內容以 `01_master/full_book.md` 與各章 `chapter_XX_main.md` 為基準。DOCX 從完成編輯的 Markdown 產生。

## 研究狀態提醒

核心兩篇論文為 2026 年 7 月公開的 arXiv 預印本。書中已區分論文發現、研究限制與本書提出的工作概念；後續再版應重新核對版本。
