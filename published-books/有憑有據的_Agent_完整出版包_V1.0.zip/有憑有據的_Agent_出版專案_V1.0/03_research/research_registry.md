# Research Registry

查閱日期：2026-07-31

## R01｜SARC-DQ

- **題名：** SARC-DQ: Runtime Data-Quality Gating for Agentic AI: Silent Evidence Defects, the Incompetence Shield, and Downstream-Only Remediation
- **作者：** Gaston Besanson
- **版本：** arXiv:2607.26313v1
- **提交日期：** 2026-07-28
- **狀態：** arXiv 預印本／working paper，非本書可確認的正式同儕審查版本
- **摘要頁：** https://arxiv.org/abs/2607.26313
- **PDF：** https://arxiv.org/pdf/2607.26313
- **支持章節：** 序章、第一至第三章、第六至第八章
- **關鍵支持：**
  - Agent 的資料錯誤會被轉成行動與貨幣成本。
  - Metadata-borne defect 在 Payload 中可能完全合理。
  - 四個模型層級、約 15 倍推理價格差距下，該基準的 Metadata-borne ADR 由 60% 至 62%，懷疑指標未改善。
  - 六類參數化檢查條件：freshness、lineage、golden-record uniqueness、cross-source consistency、schema、completeness。
  - 回應方式：block、degrade autonomy、escalate、quarantine-and-substitute。
  - gate 的效果取決於訊號位置與 predicate coverage。
- **限制：**
  - 實驗以 priced replenishment benchmark 為主。
  - 未覆蓋的 silent unit change、plausible outlier 等問題仍無法處理。
  - gate 的 Metadata 本身若退化，偵測也會下降。
  - 不能取代上游資料品質治理。
  - payload/metadata 的可見性邊界取決於機制實際獲得的表示與檢查，而非永遠固定的分類。

## R02｜Evidence-Ledger Adjudication

- **題名：** Evidence-Ledger Adjudication for Claim-Evidence Traceability
- **作者：** Gengyu Chen, Yongjie Yu, Weiling Wang
- **版本：** arXiv:2607.26512v1
- **提交日期：** 2026-07-29
- **狀態：** arXiv 預印本，非本書可確認的正式同儕審查版本
- **摘要頁：** https://arxiv.org/abs/2607.26512
- **PDF：** https://arxiv.org/pdf/2607.26512
- **支持章節：** 第四至第八章、結語
- **關鍵支持：**
  - 工作流單位：claim、evidence packet、support relation、author route、confidence、short rationale。
  - 四種關係：Supports、Contradicts、Missing Evidence、Mixed Evidence。
  - 2,335 筆盲測資料，來源為 AVeriTeC、CLIMATE-FEVER、SciFact。
  - Agent ledger：relation accuracy 0.676、macro-F1 0.601、review-needed recall 0.885。
  - 1,435 筆需要注意的主張中路由 1,270 筆；900 筆受支持主張中仍路由 295 筆。
- **限制：**
  - 整體關係判斷並非完全正確。
  - Mixed evidence F1 僅 0.289，是明顯薄弱類別。
  - 不同來源表現差異大，CLIMATE-FEVER accuracy 0.587，低於另外兩個來源。
  - 適合形成作者審核佇列，不適合被描述為最終真理裁判。
  - 公開資料集的盲測控制的是預測時標籤與封包資訊，不能完全排除模型預訓練接觸。

## R03｜NIST AI RMF 1.0

- **名稱：** Artificial Intelligence Risk Management Framework (AI RMF 1.0)
- **機構：** NIST
- **發布：** 2023
- **頁面：** https://www.nist.gov/publications/artificial-intelligence-risk-management-framework-ai-rmf-10
- **PDF：** https://nvlpubs.nist.gov/nistpubs/ai/nist.ai.100-1.pdf
- **用途：** 校準本書對可信 AI 的描述；GOVERN、MAP、MEASURE、MANAGE 四功能說明治理需要跨生命週期持續進行。
- **限制：** 自願性框架，不是單一技術實作規格；NIST 於 2026 查閱時已標示 AI RMF 1.0 正在修訂。

## R04｜NIST Generative AI Profile

- **名稱：** Artificial Intelligence Risk Management Framework: Generative Artificial Intelligence Profile
- **機構：** NIST
- **文件：** NIST AI 600-1
- **頁面：** https://www.nist.gov/publications/artificial-intelligence-risk-management-framework-generative-artificial-intelligence
- **用途：** 支持資料品質、資訊完整性、生成內容來源與人工回饋應被納入風險管理。

## R05｜W3C PROV

- **名稱：** PROV-O: The PROV Ontology / PROV-DM
- **機構：** W3C
- **發布：** 2013-04-30
- **網址：** https://www.w3.org/TR/prov-o/ 、https://www.w3.org/TR/prov-dm/
- **用途：** 說明 provenance 可被表示、交換與整合；本書的資料血緣與行動追溯觀念並非要求所有系統採用 PROV-O，而是以其證明 provenance 已有成熟標準化思路。
- **限制：** W3C PROV 是通用資料模型，不是本書雙閘門工作流的現成實作。
