# 事實查核筆記

## 已確認

1. SARC-DQ arXiv v1 提交於 2026-07-28；PDF 標示 working paper，日期 2026-07-30。
2. SARC-DQ 的摘要與結果區明確指出，在該 priced replenishment benchmark 中，Metadata-borne action-defect rate 在四個模型層級由 60% 到 62%，推理價格跨度約 15 倍。
3. SARC-DQ 明確指出 explicit data-quality flag 為 0%，behavioral marker AUC 不高於 0.50。
4. SARC-DQ 的六類 predicate 為 freshness、lineage_present、golden_record_unique、cross_source_consistent、schema_conformant、complete。
5. SARC-DQ 明確保留 coverage gap，尤其 silent_unit_change 與 plausible_outlier。
6. Evidence Ledger arXiv v1 提交於 2026-07-29；PDF 標示 2026-06-26。
7. Evidence Ledger 的盲測共 2,335 筆：900 supports、622 contradicts、621 missing、192 mixed。
8. Evidence Ledger 的 Agent 條件達 0.676 accuracy、0.601 macro-F1、0.885 review-needed recall。
9. Evidence Ledger 對 mixed evidence 的 F1 為 0.289，不能省略此限制。
10. 兩篇論文均為 arXiv 預印本，本書不得宣稱已完成正式同儕審查。

## 寫作校正

- 「Metadata-borne defects 永遠無法被模型偵測」應改成：「當辨識訊號沒有進入該機制可見的表示或 companion evidence 時，單靠 Payload 閱讀無法偵測。」
- 「gate 完全恢復損失」應限定為「對其 predicate 覆蓋且可成功替代的缺陷，研究中可完整恢復；整體 portfolio 未達完全恢復」。
- 「Evidence Ledger 判斷主張真假」應改為「判斷目前證據包與主張的支持關係，並形成審核路由」。
- 「Human on the Loop 是論文直接提出」不得寫入；本書將其作為架構延伸與作者觀點。

## 待未來更新

- 兩篇論文是否有 v2、正式會議或期刊版本。
- NIST AI RMF 修訂版是否正式發布。
- 相關 Agent governance、evidence traceability 與 runtime guardrails 是否出現新的標準或大型實證。
