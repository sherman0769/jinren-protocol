# 第五章模型畫布｜Evidence Ledger

## Ledger 欄位

- Claim：主張與類型
- Evidence Packet：來源、版本、相關段落、反證
- Relation：支持／反駁／不足／混合
- Confidence：經校準的判斷信心
- Rationale：簡短理由
- Route：保留、改寫、補證據、送審、刪除
- Review：審核者、狀態、時間
- Released Text：最後釋出版本

## 釋出原則

語氣強度不得超過證據強度；高風險內容即使 Supports 仍可要求人工批准。
