# 第五章演講筆記

## 核心結構

主張＋證據包＋關係＋路由＋信心＋理由。

## 四種關係

Supports、Contradicts、Missing Evidence、Mixed Evidence。

## 必講觀點

- 這不是真假機器。
- Relation 與 Route 必須分開。
- Mixed Evidence 是最需要人工判斷的類別。
- 實驗中的 mixed F1 僅 0.289。

## 實作

用成果報告的一句話拆成三項主張示範。
