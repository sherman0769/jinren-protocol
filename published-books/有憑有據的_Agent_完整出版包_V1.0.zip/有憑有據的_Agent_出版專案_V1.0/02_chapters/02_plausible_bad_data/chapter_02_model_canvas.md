# 第二章模型畫布｜訊號—機制矩陣

| 風險 | 必要訊號 | 可見元件 | 檢查方式 | 未通過處理 |
|---|---|---|---|---|
| 過期 | 更新時間、允許時效 | Metadata gate | freshness | 阻擋或替代 |
| 被取代 | 版本、companion record | 版本服務／gate | golden record unique | 使用現行版本或送審 |
| 單位改變 | 明確單位 | Schema／unit checker | unit consistency | 停止計算 |
| 跨來源衝突 | 兩邊資料與實體鍵 | 對齊服務／gate | cross-source consistency | 降權或送審 |
| 合理離群值 | 歷史分布、lineage | 統計監測 | outlier / lineage rule | 人工確認 |
