# 第六章模型畫布｜雙閘門證據迴路

## 第一閘門｜Evidence Admission

- 對象：來源紀錄與 Metadata
- 條件：時效、lineage、版本、schema、完整性、一致性
- 輸出：允許、降權、阻擋、替代、送審

## Agent Runtime

- 規劃、推理、工具呼叫、狀態改變
- 必須遵守 gate，不得用文字覆寫硬性控制

## 第二閘門｜Claim Release

- 對象：主張與 evidence packet
- 關係：支持、反駁、不足、混合
- 輸出：保留、改寫、補證據、人工確認、停止

## Human on the Loop

- 設定條件
- 批准高風險例外
- 監測漏檢與誤攔
- 更新 coverage

## Shared Trace

來源版本 → Agent run → 工具呼叫 → 行動 → 主張 → 審核 → 釋出版本
