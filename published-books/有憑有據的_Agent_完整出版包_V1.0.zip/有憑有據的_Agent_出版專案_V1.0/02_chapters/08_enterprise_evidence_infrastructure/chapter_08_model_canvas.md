# 第八章模型畫布｜企業證據基礎設施

1. **Source Registry**：來源、Owner、權威、敏感、失效
2. **Metadata／Data Contract**：版本、時間、單位、lineage、schema
3. **Policy Engine**：predicate、風險、權限、版本
4. **Governed Buffer**：受治理替代紀錄
5. **Trace Store**：run、tool、action、事件關聯
6. **Evidence Ledger**：claim、packet、relation、route、release
7. **Review Queue**：角色分流、批准、override
8. **Evals／Monitoring**：漏檢、誤攔、負擔、事件、coverage
