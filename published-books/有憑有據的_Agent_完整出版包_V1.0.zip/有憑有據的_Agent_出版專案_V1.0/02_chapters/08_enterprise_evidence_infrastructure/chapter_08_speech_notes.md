# 第八章演講筆記

## 開場

「十個 Agent 各自有十種版本與十種審核規則，這叫規模化，還是風險複製？」

## 八個基礎元件

來源登錄、資料契約、Policy Engine、治理緩衝區、Trace、Ledger、Review Queue、Evals。

## 重要觀點

- Prompt 是資產，但不是完整證據資產。
- 多 Agent 交接傳 artifact，不只傳 message。
- 權限隨證據狀態暫時產生。
- Trace 保存要兼顧隱私與最小化。

## 落地

九十天起步＋十項 Definition of Done。
