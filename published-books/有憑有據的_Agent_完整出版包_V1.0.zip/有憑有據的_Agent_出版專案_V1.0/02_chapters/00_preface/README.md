# 序章資料夾

- `chapter_00_main.md`：正式內容來源
- `chapter_00_speech_notes.md`：演講轉化
- `chapter_00_slide_outline.md`：簡報大綱
- `chapter_00_quotes.md`：章末金句
- `chapter_00_model_canvas.md`：核心模型畫布
