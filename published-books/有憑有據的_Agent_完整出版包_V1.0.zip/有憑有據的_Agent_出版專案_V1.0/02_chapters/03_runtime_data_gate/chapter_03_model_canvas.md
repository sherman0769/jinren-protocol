# 第三章模型畫布｜行動前最低證據條件

## 任務

要執行的工具呼叫或狀態變更。

## 風險判斷

- 影響程度
- 可逆性
- 時間敏感度
- 證據可替代性

## Predicate 組合

Freshness、Lineage、版本唯一、跨來源一致、Schema、完整性，以及任務專屬條件。

## 決策

- Pass：允許執行
- Degrade：只產生建議／草稿
- Escalate：送人工或責任角色
- Block：停止
- Quarantine and substitute：隔離問題值，採用受治理替代值

## Trace

記錄 evidence set、版本、predicate 結果、路由與批准者。
