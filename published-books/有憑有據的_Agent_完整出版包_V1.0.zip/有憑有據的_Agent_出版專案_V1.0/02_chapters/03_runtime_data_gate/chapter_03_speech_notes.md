# 第三章演講筆記

## 一句話

把資料治理從「應該」改寫成「未通過就不能呼叫工具」。

## 六類 Predicate

Freshness、Lineage、Golden Record、Cross-source Consistency、Schema、Completeness。

## 四種回應

阻擋、降權、升級、隔離並替代。

## 必講限制

Gate 的價值取決於 placement 與 coverage；沒有 predicate 的問題不會自動消失。
