# 資料來源與轉化說明

## 主要資料來源

Drew Johnston, David Holtz, Alex Martin Richmond, Christopher Ong, Prasanna Tambe, Aaron Chatterji. 《The Shift to Agentic AI: Evidence from Codex》.

## 本書如何使用這篇論文

本書不是論文翻譯，也不是 Codex 操作手冊，而是以該論文的實證觀察作為趨勢證據，再轉化為一般中文讀者可理解的工作方法論。

## 重要轉化點

1. 論文指出 agentic AI 與 conversational AI 的差異在於能代表使用者採取行動、使用工具、檢查檔案、執行命令、建立或修改成果物。本書轉化為「AI 從回答者變成工作者」。
2. 論文指出 Codex 使用在 2026 年上半年快速成長，且在 OpenAI 內部和組織用戶中出現從 ChatGPT 到 Codex 的明顯轉移。本書轉化為「工作介面正在換代」。
3. 論文指出使用者越來越常委派具體工作，而不只是詢問建議。本書轉化為「Delegation Unit」。
4. 論文使用 concurrency、runtime、skills、task complexity 等指標觀察 agentic AI 使用深度。本書轉化為「多 Agent 並行、工作配方、AI 作業系統」。
5. 論文提醒 OpenAI 內部使用場景不代表所有組織，因為其模型熟悉度、使用成本、組織支持與知識分享條件特殊。本書保留這個限制，避免把前沿使用直接當成所有企業現況。

## 寫作立場

本書採用白話、有觀點、有深度、可演講、可教學的寫法，讓研究證據服務於工作方法，而不是讓書稿變成資料堆疊。
