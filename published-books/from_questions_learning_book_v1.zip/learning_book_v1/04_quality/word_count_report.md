# 正文字數報告

書名：《從問題開始學》；版本：V1.0 完整審閱稿；統計日期：2026-09-17。

## 結果

正文共 **31,529 個非空白內容字元**，其中 **28,265 個中文漢字**。另以英文字母連續詞組計 **108 組**。三者不是可直接相加的同一種單位。

本輪工作規劃為 30,000–36,000 個非空白內容字元，已達工作目標；使用者沒有另訂最低字數。本報告不把這個數字說成 31,529 個純中文字，也不把英文的每個字母當成一個英文單字。

## 納入與排除

納入十二章論述正文、序言、導讀與結語。排除所有標題、Markdown 標記、空白、來源代碼、章末摘句、本章參考資料、目錄、封面、全部附錄、README、交付清單與衍生內容。非空白字元保留正文中的標點、英文個別字母和數字，因此另報漢字數以避免混淆。

不另把全書合併稿再加一次；各章稿是統計基礎，全書合併稿僅做內容同步驗證。

| 項目 | 非空白內容字元 | 中文漢字 | 英文字母詞組 |
|---|---:|---:|---:|
| 第 01 章：從你真正想做的事開始 | 2,461 | 2,201 | 5 |
| 第 02 章：AI 降低了什麼，沒有降低什麼 | 2,370 | 2,116 | 14 |
| 第 03 章：先分清楚：你要交付，還是要學會 | 2,436 | 2,170 | 11 |
| 第 04 章：把大願望縮成可以驗證的小任務 | 2,591 | 2,338 | 5 |
| 第 05 章：讓困惑說得出來 | 2,379 | 2,109 | 11 |
| 第 06 章：向下扎根，也要知道何時回來 | 2,386 | 2,153 | 3 |
| 第 07 章：把答案講回來，再讓現實反駁你 | 2,369 | 2,112 | 11 |
| 第 08 章：撤掉部分支援，檢查能力是否留下 | 2,262 | 2,045 | 8 |
| 第 09 章：換一個問題，看看理解能走多遠 | 2,258 | 2,036 | 5 |
| 第 10 章：把一次學會，變成可以累積的系統 | 2,430 | 2,192 | 6 |
| 第 11 章：老師的工作：設計不能跳過的思考 | 2,424 | 2,196 | 7 |
| 第 12 章：學習的主導權，最後落在誰身上 | 2,506 | 2,229 | 11 |
| 序言 | 1,296 | 1,147 | 8 |
| 導讀 | 580 | 518 | 1 |
| 結語 | 781 | 703 | 2 |
| **總計** | **31,529** | **28,265** | **108** |


## 可重現的統計方式

在解壓縮後的 learning_book_v1 資料夾中執行以下 Python 3 程式。此規則針對本版的 Markdown 結構，新增其他 Markdown 語法時應同步調整。

```python
from pathlib import Path
import re

root = Path('.')
files = sorted((root / '02_chapters').glob('*/chapter_*_main.md'))
files += [root / '01_master' / name for name in
          ('preface.md', 'reading_guide.md', 'conclusion.md')]

def clean(text):
    text = text.split('\n## 本章參考資料')[0].split('\n## 章末摘句')[0]
    text = '\n'.join(line for line in text.splitlines()
                     if not re.match(r'^\s*#', line))
    text = re.sub(r'\[(R\d+)\]', '', text)
    text = re.sub(r'\[([^\]]+)\]\(https?://[^)]+\)', r'\1', text)
    text = text.replace('**', '').replace('`', '')
    return re.sub(r'^>\s?', '', text, flags=re.M)

totals = [0, 0, 0]
for path in files:
    text = clean(path.read_text(encoding='utf-8'))
    values = [len(re.sub(r'\s', '', text)),
              len(re.findall(r'[\u3400-\u4dbf\u4e00-\u9fff]', text)),
              len(re.findall(r"[A-Za-z]+(?:[-’'][A-Za-z]+)*", text))]
    totals = [a + b for a, b in zip(totals, values)]
    print(path.name, *values)
print('TOTAL', *totals)
assert totals == [31529, 28265, 108]
```
