# 研究登錄表

查閱日期：2026-09-17。這是為本書關鍵論點進行的定向研究，不宣稱為系統性文獻回顧。來源原文不隨包重製。

## R01｜Generative AI without guardrails can harm learning: Evidence from high school mathematics

作者／機構：Hamsa Bastani、Osbert Bastani、Alp Sungu、Haosen Ge、Özge Kabakcı、Rei Mariman
發布日期：2025-06-25
研究類型：同儕審查；高中數學課堂隨機試驗
來源：https://www.pnas.org/doi/10.1073/pnas.2422633122
DOI：10.1073/pnas.2422633122
查閱日期：2026-09-17
支持章節：2、3、8、11
支持觀點：練習時的工具輔助表現，與撤除工具後的能力表現須分開觀察；導師設計會影響結果。
限制：土耳其一所高中、約千名學生、特定數學內容與 GPT-4 教學介入；不能推論所有 AI、所有年齡或長期智力。GPT Tutor 的無輔助成績未顯著優於對照組。
版本／狀態：正式出版線上修正版；2025-08-20 更正作者所屬機構，不涉及研究結果。
本次可讀範圍：全文 HTML；已另讀更正公告。
更新要求：出版前重新檢查更正與後續研究。


## R02｜AI tutoring outperforms in-class active learning: an RCT introducing a novel research-based design in an authentic educational setting

作者／機構：Greg Kestin、Kelly Miller、Anna Klales、Timothy Milbourne、Gregorio Ponti
發布日期：2025-06-03
研究類型：同儕審查；大學物理交叉設計隨機試驗
來源：https://www.nature.com/articles/s41598-025-97652-6
DOI：10.1038/s41598-025-97652-6
查閱日期：2026-09-17
支持章節：2、11
支持觀點：特定情境下，有專家解答、教學影片與結構化互動的 AI 導師取得較佳的即時後測結果。
限制：194 位符合納入條件的大學物理學生；兩堂課、兩個主題；不等於通用聊天工具勝過所有教師，也未證明多年保留或遠遷移。
版本／狀態：Scientific Reports 15, 17458；使用正式出版全文。
本次可讀範圍：全文 HTML；透過 cookies_not_supported 參數取得。
更新要求：出版前查閱後續複現；不引用網頁即時引用次數。


## R03｜How AI Impacts Skill Formation

作者／機構：Judy Hanwen Shen、Alex Tamkin
發布日期：2026-01-28；v2 於 2026-02-01
研究類型：預印本；程式設計技能形成隨機試驗
來源：https://arxiv.org/abs/2601.20245v2
DOI：10.48550/arXiv.2601.20245
查閱日期：2026-09-17
支持章節：2、3、8
支持觀點：在陌生程式庫任務中，作品完成與概念、讀碼、除錯能力可能分離；使用行為值得觀察。
限制：主試驗 52 人；參與者有 Python 經驗且不熟悉 Trio，不能當作全體初學者。互動模式分組屬事後質性分析，不能當作因果驗證。平均任務速度差異不顯著。
版本／狀態：arXiv v2；本次未驗證另有同儕審查期刊版本。HTML 頁內日期與 arXiv 版本時間不同，以摘要頁提交紀錄辨識版本。
本次可讀範圍：摘要與 HTML 全文；並交叉閱讀研究團隊 2026-01-29 官方解說。
更新要求：印前須查最新版本及刊登狀態。
補充官方解說：https://www.anthropic.com/research/AI-assistance-coding-skills

## R04｜When Problem Solving Followed by Instruction Works: Evidence for Productive Failure

作者／機構：Tanmay Sinha、Manu Kapur
發布日期：2021-06-18 線上出版；2021 年第 91 卷第 5 期
研究類型：同儕審查；統合分析
來源：https://journals.sagepub.com/doi/10.3102/00346543211019105
DOI：10.3102/00346543211019105
查閱日期：2026-09-17
支持章節：1、4、6、11
支持觀點：先嘗試問題、再接受教學可以有學習優勢，但效果受設計、年級與任務影響。
限制：53 項研究、166 組比較；不是 AI 研究，不證明本書整套方法。較低年級與某些一般技能學習出現相反趨勢。
版本／狀態：Review of Educational Research 91(5) 正式出版。
本次可讀範圍：全文 HTML。
更新要求：基本文獻保留；新版加入後續研究。


## R05｜Eliciting Self-Explanations Improves Understanding

作者／機構：Michelene T. H. Chi、Nicholas De Leeuw、Mei-Hung Chiu、Christian Lavancher
發布日期：1994-07
研究類型：同儕審查；自我解釋實驗
來源：https://onlinelibrary.wiley.com/doi/10.1207/s15516709cog1803_3
DOI：10.1207/s15516709cog1803_3
查閱日期：2026-09-17
支持章節：5、7
支持觀點：讓學習者產生自己的解釋，能協助把新資訊連結到既有理解。
限制：研究為小樣本八年級學生閱讀循環系統文字；不是把答案照念，也不是 AI 回饋準確性的驗證。
版本／狀態：Cognitive Science 18(3), 439–477。
本次可讀範圍：出版者摘要及書目；不聲稱已取得完整實驗附件。
更新要求：保留經典研究；不把它當作跨領域萬能保證。


## R06｜Measuring actual learning versus feeling of learning in response to being actively engaged in the classroom

作者／機構：Louis Deslauriers、Logan S. McCarty、Kelly Miller、Kristina Callaghan、Greg Kestin
發布日期：2019-09-04 線上出版；2019-09-24 期刊日期
研究類型：同儕審查；大學物理教學研究
來源：https://pubmed.ncbi.nlm.nih.gov/31484770/
DOI：10.1073/pnas.1821936116
查閱日期：2026-09-17
支持章節：5、7
支持觀點：主觀學會感和實際表現可能不同；不能單憑「解釋很流暢」驗收。
限制：主動／被動教學的特定比較；不表示所有困難都促進學習，亦非 AI 實驗。
版本／狀態：PNAS 116(39), 19251–19257。
本次可讀範圍：PubMed 原始摘要與書目。
更新要求：低變動；教學遷用仍需自行檢查。


## R07｜Improving Students’ Learning With Effective Learning Techniques: Promising Directions From Cognitive and Educational Psychology

作者／機構：John Dunlosky、Katherine A. Rawson、Elizabeth J. Marsh、Mitchell J. Nathan、Daniel T. Willingham
發布日期：2013-01-08
研究類型：同儕審查；學習策略研究綜述
來源：https://journals.sagepub.com/doi/abs/10.1177/1529100612453266
DOI：10.1177/1529100612453266
查閱日期：2026-09-17
支持章節：8、9、10
支持觀點：提取練習與分散練習有廣泛支持，學習不能只靠重讀或累積資料。
限制：非 AI 實驗；沒有提供適合所有人的固定日程。本書七日、三十日安排是實務設計，不是研究標準。
版本／狀態：Psychological Science in the Public Interest 14(1), 4–58。
本次可讀範圍：出版者 HTML 正文及推薦總結。
更新要求：保留經典綜述，印前可補更新。


## R08｜Scaffolding and Achievement in Problem-Based and Inquiry Learning: A Response to Kirschner, Sweller, and Clark (2006)

作者／機構：Cindy E. Hmelo-Silver、Ravit Golan Duncan、Clark A. Chinn
發布日期：2007
研究類型：同儕審查；理論與證據回應文章
來源：https://www.sfu.ca/~jcnesbit/EDUC220/ThinkPaper/HmeloSilverDuncan2007.pdf
DOI：10.1080/00461520701263368
查閱日期：2026-09-17
支持章節：1、6、8、11
支持觀點：問題導向與探究學習可含大量引導、支援與適時直接教學，不應一律等同無引導探索。
限制：教育理論與研究論證，不是對本書 AI 流程的直接試驗。與 R09 有理論爭點，不把其中一方寫成唯一結論。
版本／狀態：Educational Psychologist 42(2), 99–107；大學網站保存的論文全文。
本次可讀範圍：PDF 文字全文及首頁截圖；另查 Rutgers 機構典藏書目。
更新要求：基本文獻保留。


## R09｜Why Minimal Guidance During Instruction Does Not Work: An Analysis of the Failure of Constructivist, Discovery, Problem-Based, Experiential, and Inquiry-Based Teaching

作者／機構：Paul A. Kirschner、John Sweller、Richard E. Clark
發布日期：2006
研究類型：同儕審查；教學理論與證據分析
來源：https://www.sfu.ca/~jcnesbit/EDUC220/ThinkPaper/KirschnerSweller2006.pdf
DOI：10.1207/s15326985ep4102_1
查閱日期：2026-09-17
支持章節：1、4、6、11
支持觀點：初學者需要適當引導；複雜無引導搜尋可能耗費資源而不形成足夠理解。
限制：作者對問題導向學習的歸類受到 R08 回應與批評；不可直接當作所有專案學習無效的證明。
版本／狀態：Educational Psychologist 41(2), 75–86；大學網站保存的論文全文。
本次可讀範圍：PDF 文字全文及首頁截圖。
更新要求：與 R08 並列閱讀。


## R10｜Introducing study mode

作者／機構：OpenAI
發布日期：2025-07-29
研究類型：官方產品設計說明；非獨立成效試驗
來源：https://openai.com/index/chatgpt-study-mode/
DOI：不適用
查閱日期：2026-09-17
支持章節：2、7、11
支持觀點：官方曾以引導提問、分段支援、理解檢查等方向設計學習模式，同時承認可能出錯與行為不一致。
限制：引用的是 2025 年發布說明，不表示 2026 年介面、價格或功能完全相同；官方產品主張不等於獨立實證。
版本／狀態：歷史發布文章；查閱日 2026-09-17。
本次可讀範圍：全文 HTML。
更新要求：只有新增具體操作或價格時才重新查最新產品文件。


## 更正公告

R01 的作者所屬機構更正，2025-08-20：https://www.pnas.org/doi/10.1073/pnas.2518204122 。本次已讀公告，未見公告更改研究結果。

## 未採為正文證據的素材

Gabriel Petersson 職涯故事：找到 2025-11-28 Business Insider 報導，報導指向 Extraordinary 訪談與個人履歷。但本次未完整取得原始訪談／逐字稿，無法核實原文的每日提問次數、十二歲解釋用語、擴散模型實作細節及完整時間線。故不將故事寫成精確傳記，不以職涯結果證明任何方法的因果效果。
線索：https://www.businessinsider.com/high-school-dropout-openai-chatgpt-learn-ai-gabriel-petersson-2025-11 。
原始訪談頁嘗試：https://extraordinary.com/podcast/gabriel-petersson ，本次存取失敗。媒體轉述不是否定當事人經驗，但不足支持詳細重建。

沒有採用：未取得正文的學習論文、搜尋結果標題或無法核實的即時訂閱費。若往後引用具體價格或工具版本，需重新查官方頁面。
