# 名詞登錄

| 中文 | 英文 | 本書用法與邊界 |
|---|---|---|
| 任務扎根學習法 | Task-Rooted Learning | 本書提出的整合型工作框架，並非標準化或已整套驗證的教學理論。 |
| 雙軌驗收 | Dual-Track Assessment | 本書工作工具：成果可用性與個人能力證據分開記錄。不是心理計量量表。 |
| 問題導向學習 | Problem-Based Learning | 學習圍繞問題展開；可以含教師引導、合作與適時直接教學。 |
| 專案導向學習 | Project-Based Learning | 以較完整的作品或專案組織學習，不等同每次都需大型開發。 |
| 鷹架／學習支援 | Scaffolding | 依程度提供暫時性支持；撤除的對象是相關提示，不是所有合理工具。 |
| 後設認知 | Metacognition | 觀察與調整自己的理解、策略、信心和證據；不是只會說「我不知道」。 |
| 自我解釋／回講 | Self-explanation / Teach-back | 以自己的關係理解和條件說明，而非逐字復誦 AI。 |
| 提取練習 | Retrieval practice | 不先看完整答案而取出相關知識或推理，再獲得回饋。 |
| 分散練習 | Distributed practice | 將練習分散於不同時間；固定幾天只作設計範例。 |
| 遷移 | Transfer | 在不同任務與條件中使用理解，必須說明相同及不同之處。 |
| 遞迴深挖 | Recursive drill-down | 沿依賴概念追問的學習比喻，不是把程式解析器的 recursive descent 當作教育理論。 |
| 撤架 | Fading support | 逐步減少會代替核心能力的支援，仍保留無障礙、查詢或非目標技能工具。 |
