# 參考資料

以下來源用於校準本書關鍵論點，並未驗證整套任務扎根學習法。研究登錄表另列查閱範圍、版本、限制與更新要求。

[R01] Hamsa Bastani、Osbert Bastani、Alp Sungu、Haosen Ge、Özge Kabakcı、Rei Mariman。Generative AI without guardrails can harm learning: Evidence from high school mathematics。發布：2025-06-25。正式出版線上修正版；2025-08-20 更正作者所屬機構，不涉及研究結果。

[來源原文](https://www.pnas.org/doi/10.1073/pnas.2422633122)；DOI：10.1073/pnas.2422633122。查閱：2026-09-17。

引用限制：土耳其一所高中、約千名學生、特定數學內容與 GPT-4 教學介入；不能推論所有 AI、所有年齡或長期智力。GPT Tutor 的無輔助成績未顯著優於對照組。

[R02] Greg Kestin、Kelly Miller、Anna Klales、Timothy Milbourne、Gregorio Ponti。AI tutoring outperforms in-class active learning: an RCT introducing a novel research-based design in an authentic educational setting。發布：2025-06-03。Scientific Reports 15, 17458；使用正式出版全文。

[來源原文](https://www.nature.com/articles/s41598-025-97652-6)；DOI：10.1038/s41598-025-97652-6。查閱：2026-09-17。

引用限制：194 位符合納入條件的大學物理學生；兩堂課、兩個主題；不等於通用聊天工具勝過所有教師，也未證明多年保留或遠遷移。

[R03] Judy Hanwen Shen、Alex Tamkin。How AI Impacts Skill Formation。發布：2026-01-28；v2 於 2026-02-01。arXiv v2；本次未驗證另有同儕審查期刊版本。HTML 頁內日期與 arXiv 版本時間不同，以摘要頁提交紀錄辨識版本。

[來源原文](https://arxiv.org/abs/2601.20245v2)；DOI：10.48550/arXiv.2601.20245。查閱：2026-09-17。

引用限制：主試驗 52 人；參與者有 Python 經驗且不熟悉 Trio，不能當作全體初學者。互動模式分組屬事後質性分析，不能當作因果驗證。平均任務速度差異不顯著。

[R04] Tanmay Sinha、Manu Kapur。When Problem Solving Followed by Instruction Works: Evidence for Productive Failure。發布：2021-06-18 線上出版；2021 年第 91 卷第 5 期。Review of Educational Research 91(5) 正式出版。

[來源原文](https://journals.sagepub.com/doi/10.3102/00346543211019105)；DOI：10.3102/00346543211019105。查閱：2026-09-17。

引用限制：53 項研究、166 組比較；不是 AI 研究，不證明本書整套方法。較低年級與某些一般技能學習出現相反趨勢。

[R05] Michelene T. H. Chi、Nicholas De Leeuw、Mei-Hung Chiu、Christian Lavancher。Eliciting Self-Explanations Improves Understanding。發布：1994-07。Cognitive Science 18(3), 439–477。

[來源原文](https://onlinelibrary.wiley.com/doi/10.1207/s15516709cog1803_3)；DOI：10.1207/s15516709cog1803_3。查閱：2026-09-17。

引用限制：研究為小樣本八年級學生閱讀循環系統文字；不是把答案照念，也不是 AI 回饋準確性的驗證。

[R06] Louis Deslauriers、Logan S. McCarty、Kelly Miller、Kristina Callaghan、Greg Kestin。Measuring actual learning versus feeling of learning in response to being actively engaged in the classroom。發布：2019-09-04 線上出版；2019-09-24 期刊日期。PNAS 116(39), 19251–19257。

[來源原文](https://pubmed.ncbi.nlm.nih.gov/31484770/)；DOI：10.1073/pnas.1821936116。查閱：2026-09-17。

引用限制：主動／被動教學的特定比較；不表示所有困難都促進學習，亦非 AI 實驗。

[R07] John Dunlosky、Katherine A. Rawson、Elizabeth J. Marsh、Mitchell J. Nathan、Daniel T. Willingham。Improving Students’ Learning With Effective Learning Techniques: Promising Directions From Cognitive and Educational Psychology。發布：2013-01-08。Psychological Science in the Public Interest 14(1), 4–58。

[來源原文](https://journals.sagepub.com/doi/abs/10.1177/1529100612453266)；DOI：10.1177/1529100612453266。查閱：2026-09-17。

引用限制：非 AI 實驗；沒有提供適合所有人的固定日程。本書七日、三十日安排是實務設計，不是研究標準。

[R08] Cindy E. Hmelo-Silver、Ravit Golan Duncan、Clark A. Chinn。Scaffolding and Achievement in Problem-Based and Inquiry Learning: A Response to Kirschner, Sweller, and Clark (2006)。發布：2007。Educational Psychologist 42(2), 99–107；大學網站保存的論文全文。

[來源原文](https://www.sfu.ca/~jcnesbit/EDUC220/ThinkPaper/HmeloSilverDuncan2007.pdf)；DOI：10.1080/00461520701263368。查閱：2026-09-17。

引用限制：教育理論與研究論證，不是對本書 AI 流程的直接試驗。與 R09 有理論爭點，不把其中一方寫成唯一結論。

[R09] Paul A. Kirschner、John Sweller、Richard E. Clark。Why Minimal Guidance During Instruction Does Not Work: An Analysis of the Failure of Constructivist, Discovery, Problem-Based, Experiential, and Inquiry-Based Teaching。發布：2006。Educational Psychologist 41(2), 75–86；大學網站保存的論文全文。

[來源原文](https://www.sfu.ca/~jcnesbit/EDUC220/ThinkPaper/KirschnerSweller2006.pdf)；DOI：10.1207/s15326985ep4102_1。查閱：2026-09-17。

引用限制：作者對問題導向學習的歸類受到 R08 回應與批評；不可直接當作所有專案學習無效的證明。

[R10] OpenAI。Introducing study mode。發布：2025-07-29。歷史發布文章；查閱日 2026-09-17。

[來源原文](https://openai.com/index/chatgpt-study-mode/)。查閱：2026-09-17。

引用限制：引用的是 2025 年發布說明，不表示 2026 年介面、價格或功能完全相同；官方產品主張不等於獨立實證。
