# Research Registry｜研究來源登錄

查閱日期：2026-07-12

> R01–R10 是全書正文使用的短代碼。除 R07 的官方會議／期刊頁與 R10 的 OpenAI 官方分析外，多數來源是 2026 年 7 月的 arXiv 預印本；本書將它們視為近期研究方向，不視為已完成的產業標準。

## R01｜Workflow as Knowledge

- **標題：** Workflow as Knowledge: Semantic Persistence for LLM-Mediated Workflows
- **作者：** Emanuele Quinto, Carlo Andrea Rozzi, Francesco Zanitti
- **日期／版本：** 2026-07-09，arXiv:2607.08740 v1
- **來源：** https://arxiv.org/abs/2607.08740
- **全文：** https://arxiv.org/html/2607.08740v1
- **支持章節：** 第一章、終章
- **支持觀點：** 工作流定義、執行實例、推論紀錄、上下文快照與依賴可作為知識物件；區分 derive 與 infer。
- **限制：** 概念模型；正式轉移語意、完整實作與實證評估仍屬未來工作；不能寫成已驗證的通用標準。

## R02｜Remember When It Matters

- **標題：** Remember When It Matters: Proactive Memory Agent for Long-Horizon Agents
- **作者：** Yifan Wu, Lizhu Zhang, Yuhang Zhou, Mingyi Wang, Bo Peng, Serena Li, Xiangjun Fan, Zhuokai Zhao
- **日期／版本：** 2026-07-09，arXiv:2607.08716 v1
- **來源：** https://arxiv.org/abs/2607.08716
- **支持章節：** 第二章、終章
- **支持觀點：** Behavioral State Decay；獨立記憶 Agent 維護結構化記憶並選擇性注入提醒；Terminal-Bench 2.0 約 +8.3 個百分點、τ²-Bench 約 +6.8 個百分點（特定模型與設定）。
- **限制：** 額外模型呼叫增加成本；提醒可能冗餘、錯誤或推測性；更強主 Agent 的增益較小，數據不能外推到所有任務。

## R03｜From Prompts to Contracts

- **標題：** From Prompts to Contracts: Harness Engineering for Auditable Enterprise LLM Agents
- **作者：** Joongho Ahn, Moonsoo Kim
- **日期／版本：** 2026-07-09，arXiv:2607.08028 v1
- **來源：** https://arxiv.org/abs/2607.08028
- **全文：** https://arxiv.org/html/2607.08028v1
- **支持章節：** 第三章、終章
- **支持觀點：** 用 code、manifest、schema、validator、trace 與 output contract 包住可替換模型；三模型共 270 次執行中，程式所有的可檢查契約維持 270/270。
- **限制：** 整體最終 Harness Pass 並非 270/270；模型組成內容仍有失敗且被攔截。研究只處理可程式檢查契約，不保證主張內容、投資建議或所有語意品質正確。

## R04｜Progressive Crystallization

- **標題：** Progressive Crystallization: Turning Agent Exploration into Deterministic, Lower-Cost Workflows in Production
- **作者：** Arun Malik
- **日期／版本：** 2026-07-08，arXiv:2607.07052 v1
- **來源：** https://arxiv.org/abs/2607.07052
- **全文：** https://arxiv.org/html/2607.07052v1
- **支持章節：** 第四章、終章
- **支持觀點：** Agent、混合與確定性三型流程；根據軌跡與驗收證據升級、環境偏移時降級。單一 AIOps 生產案例八個月約 45% 執行轉為確定性流程，每事件 Agent 成本降低超過 70%。
- **限制：** 單一組織、單一領域、觀察性生產案例；不能視為所有產業的成本保證。抽取品質依賴軌跡與驗收測試。

## R05｜Good Bug Reports for AI Agents

- **標題：** What Makes a Good Bug Report for an AI Agent?
- **作者：** Lara Khatib, Noble Saji Mathews, Meiyappan Nagappan, Pengyu Nie, Thomas Zimmermann
- **日期／版本：** 2026-07-08，arXiv:2607.07593 v1
- **來源：** https://arxiv.org/abs/2607.07593
- **支持章節：** 第五章、終章
- **支持觀點：** 433 個 SWE-bench Verified issues、87 個 repair agents、27 種特徵；修復建議、原始碼、可執行重現腳本、定位與預期行為有幫助；過長與去除結構可能降低解題率。
- **限制：** 一部分結果是觀察性關聯；控制實驗使用人工變形與有限模型，不能直接外推到所有 Repository 與 Agent。

## R06｜OpenCoF

- **標題：** OpenCoF: Learning to Reason Through Video Generation
- **作者：** Xinyan Chen, Ziyu Guo, Renrui Zhang, Dongzhi Jiang, Hongsheng Li
- **日期／版本：** 2026-07-09，arXiv:2607.08763 v1
- **來源：** https://arxiv.org/abs/2607.08763
- **全文：** https://arxiv.org/html/2607.08763
- **支持章節：** 第六章、終章
- **支持觀點：** Chain-of-Frame；OpenCoF-17K 實際含 17,312 段影片與 11 類任務；以連續影格承載時間、空間與因果的中間狀態；探索視覺與文字 reasoning tokens。
- **限制：** 基準改善不等於模型具有完整人類理解；高畫質不保證推理一致；視覺與文字 reasoning token 的完整結合仍是後續方向。

## R07｜ARDY

- **標題：** ARDY: Autoregressive Diffusion with Hybrid Representation for Interactive Human Motion Generation
- **作者：** Kaifeng Zhao, Mathis Petrovich, Haotian Zhang, Tingwu Wang, Siyu Tang, Davis Rempe
- **日期／版本：** 2026-07-09，arXiv:2607.08741 v1；官方頁標示 ACM TOG／SIGGRAPH 2026
- **來源：** https://arxiv.org/abs/2607.08741
- **官方專案：** https://research.nvidia.com/labs/sil/projects/ardy/
- **GitHub：** https://github.com/nv-tlabs/ardy
- **支持章節：** 第七章、終章
- **支持觀點：** 串流、互動、可控制 3D 人體動作生成；支援線上文字、根路點／路徑、全身關鍵影格與稀疏關節限制；四步擴散在 RTX 4090 上平均約 33 ms。
- **限制：** 延遲取決於硬體與設定；純運動學模型缺少物理動力學，可能有腳滑、抖動與長軌跡成本；不能直接視為安全健身處方。

## R08｜AI-based Learning Assistants in Higher Education

- **標題：** Using AI-based Learning Assistants in Higher Education: A Large-Scale Descriptive Analysis
- **作者：** Kristina Schaaff, Quintus Stierstorfer, Valerie Hekkel
- **日期／版本：** 2026-07-09，arXiv:2607.08748 v1
- **來源：** https://arxiv.org/abs/2607.08748
- **支持章節：** 第八章、終章
- **支持觀點：** 77,543 名遠距高等教育學生的客觀 Log；分析人口與結構條件、全職／兼職時間模式。
- **限制：** 描述性分析、單一觀察月、無因果推論、未直接測量互動品質與學習成果；作者受雇於研究場域機構，需知悉情境。

## R09｜OmniFood-Bench

- **標題：** OmniFood-Bench: Evaluating VLMs for Nutrient Reasoning and Personalized Health Advice
- **作者：** Qian Jiang, Zhecheng Shi, Jingpu Yang, Zirui Song, Miao Fang
- **日期／版本：** 2026-07-09，arXiv:2607.08423 v1
- **來源：** https://arxiv.org/abs/2607.08423
- **支持章節：** 第九章、終章
- **支持觀點：** 基本感知、定量推理、安全關鍵建議三層；Semantic-Physical Gap；菜名辨識不能外推到重量估算與高風險健康建議。
- **限制：** 預印本與新基準，不是臨床驗證；無法涵蓋所有在地料理、族群與醫療情境，產品仍需專業與法規驗證。

## R10｜The Shift to Agentic AI

- **標題：** The Shift to Agentic AI: Evidence from Codex
- **作者：** Drew Johnston, David Holtz, Alex Martin Richmond, Christopher Ong, Prasanna Tambe, Aaron Chatterji
- **日期／版本：** 2026-06-25，arXiv:2606.26959
- **來源：** https://arxiv.org/abs/2606.26959
- **OpenAI 官方：** https://openai.com/index/how-agents-are-transforming-work/
- **支持章節：** 序章、第十章、終章
- **支持觀點：** Agent 從工程師擴散到知識工作者，工作單位從短問答走向較長委派；2026 年 5 月抽樣個人使用者中，80.6% 曾送出估計超過 30 分鐘、70.2% 超過一小時、25.6% 超過八小時的人工作業請求。
- **限制：** 人工作業時間是模型／分類器估計，不是實際精準工時或已節省時間；抽樣範圍、opt-in 與平台使用者不代表整體勞動市場；採用資料不等於因果生產力證明。
