# 終章｜Loop Engineering：人不是在迴路裡救火，而是在迴路上方設計系統

## 檔案

- `chapter_11_main.md`：本章正式內容來源
- `chapter_11_speech_notes.md`：演講筆記
- `chapter_11_slide_outline.md`：簡報大綱
- `chapter_11_quotes.md`：章末金句
- `chapter_11_model_canvas.md`：本章模型畫布

## 唯一任務

當 Agent 能做更多，人應該站在每一步裡，還是站在整個迴路上方？

## 核心答案

依風險設計九層迴路，讓低風險工作自動前進、高風險工作被契約與人攔截，成熟路徑逐步固化。
