# 第六章｜影片也能推理：從 Chain-of-Thought 到 Chain-of-Frame

## 檔案

- `chapter_06_main.md`：本章正式內容來源
- `chapter_06_speech_notes.md`：演講筆記
- `chapter_06_slide_outline.md`：簡報大綱
- `chapter_06_quotes.md`：章末金句
- `chapter_06_model_canvas.md`：本章模型畫布

## 唯一任務

影片生成如何從漂亮畫面走向可表達時間、因果與中間狀態？

## 核心答案

Chain-of-Frame 以連續影格承載狀態轉換；影片提示需要描述前態、動作、可見證據、變化與後態。
