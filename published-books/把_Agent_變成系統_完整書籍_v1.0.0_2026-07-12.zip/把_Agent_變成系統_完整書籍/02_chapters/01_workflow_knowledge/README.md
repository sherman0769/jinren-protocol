# 第一章｜工作流也是知識：AI 專案不能只留下成果

## 檔案

- `chapter_01_main.md`：本章正式內容來源
- `chapter_01_speech_notes.md`：演講筆記
- `chapter_01_slide_outline.md`：簡報大綱
- `chapter_01_quotes.md`：章末金句
- `chapter_01_model_canvas.md`：本章模型畫布

## 唯一任務

一條 AI 工作流完成後，應該留下哪些可恢復、可審查與可教學的資訊？

## 核心答案

保存工作流定義、執行實例、上下文、推論、衍生計算、批准與依賴，並區分 derive 與 infer。
