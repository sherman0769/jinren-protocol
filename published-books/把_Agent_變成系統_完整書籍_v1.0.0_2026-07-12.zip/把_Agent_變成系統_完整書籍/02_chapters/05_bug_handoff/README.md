# 第五章｜如何把問題交給 Coding Agent：好的交接，比好的提示詞更重要

## 檔案

- `chapter_05_main.md`：本章正式內容來源
- `chapter_05_speech_notes.md`：演講筆記
- `chapter_05_slide_outline.md`：簡報大綱
- `chapter_05_quotes.md`：章末金句
- `chapter_05_model_canvas.md`：本章模型畫布

## 唯一任務

Coding Agent 需要什麼樣的問題描述，才能真正重現、定位與修復？

## 核心答案

以預期行為、可執行重現腳本、錯誤位置、相關原始碼、限制與驗收測試提供結構化交接。
