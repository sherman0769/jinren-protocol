# 第八章｜AI 學習助理進入校園：使用率不是學習成效

## 檔案

- `chapter_08_main.md`：本章正式內容來源
- `chapter_08_speech_notes.md`：演講筆記
- `chapter_08_slide_outline.md`：簡報大綱
- `chapter_08_quotes.md`：章末金句
- `chapter_08_model_canvas.md`：本章模型畫布

## 唯一任務

AI 學習助理的登入與對話數，為什麼不能直接代表學生學會？

## 核心答案

Log 能描述誰在何時使用，不能單獨證明理解、遷移與長期成果；評估要從採用走向互動、過程、成果、公平與依賴。
