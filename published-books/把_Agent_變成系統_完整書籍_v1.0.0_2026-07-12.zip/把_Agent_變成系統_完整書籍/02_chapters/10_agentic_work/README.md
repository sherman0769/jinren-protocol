# 第十章｜從對話到委派：Codex 顯示 AI 工作單位正在變大

## 檔案

- `chapter_10_main.md`：本章正式內容來源
- `chapter_10_speech_notes.md`：演講筆記
- `chapter_10_slide_outline.md`：簡報大綱
- `chapter_10_quotes.md`：章末金句
- `chapter_10_model_canvas.md`：本章模型畫布

## 唯一任務

當 AI 接手數十分鐘到數小時的任務，人要如何從提問者轉成委派者？

## 核心答案

長任務需要 Objective、Workspace、Inputs、Constraints、Acceptance Criteria、Checkpoints、Authority 與 Deliverables。
