# 第七章｜虛擬教練開始動起來：互動式人體動作生成與健身 AI

## 檔案

- `chapter_07_main.md`：本章正式內容來源
- `chapter_07_speech_notes.md`：演講筆記
- `chapter_07_slide_outline.md`：簡報大綱
- `chapter_07_quotes.md`：章末金句
- `chapter_07_model_canvas.md`：本章模型畫布

## 唯一任務

即時、可控制的人體動作生成，如何走向虛擬教練，又有哪些安全限制？

## 核心答案

ARDY 結合自回歸、擴散、根部與身體混合表示，接受文字與運動學限制；流暢控制不等於生物力學安全。
