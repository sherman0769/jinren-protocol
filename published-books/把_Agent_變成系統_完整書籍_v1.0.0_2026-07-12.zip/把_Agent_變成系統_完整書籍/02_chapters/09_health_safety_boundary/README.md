# 第九章｜看得懂不等於算得準：健身 AI 與健康建議的安全邊界

## 檔案

- `chapter_09_main.md`：本章正式內容來源
- `chapter_09_speech_notes.md`：演講筆記
- `chapter_09_slide_outline.md`：簡報大綱
- `chapter_09_quotes.md`：章末金句
- `chapter_09_model_canvas.md`：本章模型畫布

## 唯一任務

AI 能辨識食物，為什麼仍不能直接給精準營養與疾病建議？

## 核心答案

Semantic-Physical Gap 讓語意辨識無法直接推得份量與營養；高風險建議需要資料庫、風險分級與專業放行。
