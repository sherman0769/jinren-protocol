# 第四章｜讓 Agent 探索，讓系統接手：成功流程的漸進式固化

## 檔案

- `chapter_04_main.md`：本章正式內容來源
- `chapter_04_speech_notes.md`：演講筆記
- `chapter_04_slide_outline.md`：簡報大綱
- `chapter_04_quotes.md`：章末金句
- `chapter_04_model_canvas.md`：本章模型畫布

## 唯一任務

已經成功很多次的工作，為什麼還要讓 Agent 每次重新思考？

## 核心答案

未知工作先由 Agent 探索，累積軌跡與驗收證據後升級成混合或確定性流程，偏移時再降級。
