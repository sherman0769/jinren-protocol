# 序章｜為什麼我們不能只停留在 Prompt Engineering？

## 檔案

- `chapter_00_main.md`：本章正式內容來源
- `chapter_00_speech_notes.md`：演講筆記
- `chapter_00_slide_outline.md`：簡報大綱
- `chapter_00_quotes.md`：章末金句
- `chapter_00_model_canvas.md`：本章模型畫布

## 唯一任務

當 AI 從回答走向長任務，為什麼提示詞已不足以承擔整套系統責任？

## 核心答案

Prompt 處理意圖，Loop Engineering 處理工具、流程、狀態、限制、驗收、固化與人工接管。
