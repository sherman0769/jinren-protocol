# 序章｜為什麼我們不能只停留在 Prompt Engineering？｜簡報大綱

## Slide 1｜章名與核心問題

- 當 AI 從回答走向長任務，為什麼提示詞已不足以承擔整套系統責任？

## Slide 2｜常見現象

- 一個看似成功、實際缺少系統責任的場景
- 讀者目前依賴的舊方法

## Slide 3｜舊方法的限制

- 為什麼只靠 Prompt、模型能力或使用率不足
- 錯誤如何在長任務中被放大

## Slide 4｜研究在做什麼

- 研究問題與方法
- 主要資料或實驗範圍

## Slide 5｜核心技術

- Prompt 處理意圖，Loop Engineering 處理工具、流程、狀態、限制、驗收、固化與人工接管。

## Slide 6｜本書模型：九層 Loop Engineering

- Prompt：說清楚意圖
- Tool：提供有限行動能力
- Workflow：安排狀態與步驟
- Memory：在關鍵時刻恢復條件
- Contract：用程式守住規則
- Eval：用證據判斷通過
- Crystallization：固化成功路徑
- Governance：管理權限與責任
- Human on Loop：批准、暫停與接管

## Slide 7｜研究限制

- 哪些結論不能外推
- 哪些問題仍需正式部署或後續研究驗證

## Slide 8｜李詩民場景

- 內容自動化、健身 AI、美髮 AI 與企業導入都不再只看模型回答，而看完整責任迴路。

## Slide 9｜企業與教學行動

- 課程應新增的能力
- 企業應移到系統層的控制

## Slide 10｜一句話收束

- Prompt Engineering 教你怎麼對 AI 開口；Loop Engineering 教你怎麼讓事情在你沒有逐步盯著時，仍然能正確前進。
