# 第二章｜記憶不是資料庫：真正重要的是何時提醒

## 檔案

- `chapter_02_main.md`：本章正式內容來源
- `chapter_02_speech_notes.md`：演講筆記
- `chapter_02_slide_outline.md`：簡報大綱
- `chapter_02_quotes.md`：章末金句
- `chapter_02_model_canvas.md`：本章模型畫布

## 唯一任務

長任務中，重要資訊仍存在，為什麼 Agent 還是會忘記？

## 核心答案

Behavioral State Decay 讓早期條件失去行為影響；記憶系統要維護結構化狀態並在相關節點選擇性提醒。
