# 第三章｜從提示詞到契約：企業 Agent 不能只靠「請你遵守」

## 檔案

- `chapter_03_main.md`：本章正式內容來源
- `chapter_03_speech_notes.md`：演講筆記
- `chapter_03_slide_outline.md`：簡報大綱
- `chapter_03_quotes.md`：章末金句
- `chapter_03_model_canvas.md`：本章模型畫布

## 唯一任務

為什麼公司規則寫進 Prompt，仍不能算真正的控制？

## 核心答案

Prompt 是意圖，Harness 以 code、schema、manifest、validator、trace 與 output contract 提供可執行保證。
