# 名詞登錄表

| 中文名稱 | 英文／代碼 | 本書定義與使用原則 |
|---|---|---|
| 迴路工程 | Loop Engineering | 設計 Agent 任務如何持續執行、觀察、記憶、約束、驗證、回退、固化與治理的工作方法；本書的整合框架，不宣稱為正式標準。 |
| 提示工程 | Prompt Engineering | 設計模型收到的意圖、背景、限制與輸出格式。 |
| 工作流 | Workflow | 任務的狀態、步驟、依賴、分支、重試、停止與交接結構。 |
| 語意持久化 | Semantic Persistence | 讓工作流定義、實例、推論、脈絡、批准與依賴以有角色與身分的知識物件保存。 |
| 執行持久化 | Execution Persistence | 保存執行狀態、Log、工具呼叫與恢復能力。 |
| 衍生計算 | Derive／D | 確定性、可測試、可重播的計算或驗證。 |
| 模型推論 | Infer／I | 模型在特定脈絡與權限下做出的語意判斷。 |
| 人工介入 | Human／H | 人的修改、批准、拒絕、專業判斷或接管。 |
| 外部行動 | Action／A | 對檔案、系統、平台或真實世界產生影響的工具操作。 |
| 行為狀態衰退 | Behavioral State Decay | 長任務中，早期重要資訊雖仍存在，卻逐漸失去對後續行動的影響。 |
| 主動記憶 Agent | Proactive Memory Agent | 維護結構化記憶並判斷何時選擇性提醒主 Agent 的獨立角色。 |
| Harness 工程 | Harness Engineering | 用程式、Manifest、Schema、Validator、Trace 與契約包住可替換模型邊界。 |
| 漸進式固化 | Progressive Crystallization | 根據成功軌跡與驗收證據，把 Agent 探索逐步轉成混合或確定性流程。 |
| 確定性工作流 | Deterministic Workflow | 在相同輸入、版本與規則下，可穩定重播的固定流程。 |
| 影格鏈推理 | Chain-of-Frame | 以時間連續影格承載中間狀態、因果與事件變化的影片推理方式。 |
| 語意—物理落差 | Semantic-Physical Gap | 模型能辨識語意標籤，卻無法等比例掌握重量、尺度與營養等物理量。 |
| 迴路上方的人 | Human on Loop | 人設計、觀察、批准、暫停、回退與接管整套迴路，而非逐步操作每個動作。 |
| 工作流護照 | Workflow Passport | 本書工作表：集中記錄任務、步驟、角色、工具、版本、脈絡、批准、驗收與保存政策。 |
| 探索稅 | Exploration Tax | 本書概念：對已知路徑仍反覆使用高成本 Agent 規劃所付出的額外成本。 |
| 僵化債務 | Rigidity Debt | 本書概念：過早固化流程，導致環境改變時難以適應的累積代價。 |
