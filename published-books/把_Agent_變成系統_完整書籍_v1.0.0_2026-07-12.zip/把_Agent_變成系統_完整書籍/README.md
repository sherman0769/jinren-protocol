# 《把 Agent 變成系統》完整書籍專案

**書名：**《把 Agent 變成系統：從 Prompt Engineering 到 Loop Engineering》  
**副標：**寫給李詩民自己的 AI Agent 工作流閱讀筆記  
**版本：**v1.0.0  
**日期：**2026-07-12

## 最快閱讀

- `01_master/full_book.md`：全書唯一正式內容來源
- `01_master/full_book.docx`：全書閱讀版
- `03_research/research_registry.md`：十項來源、支持觀點與限制
- `04_quality/QA_REPORT.md`：品質、字數與檔案驗證結果
- `05_delivery/delivery_manifest.txt`：交付檔案清單

## 資料夾

- `00_project`：專案摘要、Book Bible、風格、名詞、進度與變更紀錄
- `01_master`：全書 Markdown、DOCX 與附錄
- `02_chapters`：十二篇章正式稿與演講、簡報、金句、模型畫布
- `03_research`：研究登錄與事實查核
- `04_quality`：字數、去重與品質報告
- `05_delivery`：交付清單

## 核心主張

> Agent 負責探索，系統負責記憶、約束、驗證與固化。

## 內容維護規則

修改正文時，先更新對應 `chapter_XX_main.md`，再重新合併 `01_master/full_book.md`，最後同步 DOCX、衍生內容、字數與 QA 報告。
