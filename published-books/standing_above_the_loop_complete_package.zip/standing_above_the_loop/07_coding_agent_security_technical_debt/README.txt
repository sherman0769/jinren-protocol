第七章｜Coding Agent 從寫程式，走向資安、盤點與技術債整理

用途：本資料夾為本章完整交付包，可作為書稿、自讀筆記、演講素材、投影片大綱與課程轉化基底。

包含檔案：
- chapter_07_main.docx：本章 Word 書稿
- chapter_07_main.md：本章 Markdown 書稿
- chapter_07_speech_notes.md：演講轉化筆記
- chapter_07_slide_outline.md：投影片大綱
- chapter_07_quotes.md：金句庫
- chapter_07_loop_canvas.md：概念模型與課程轉化畫布
- README.txt：本說明

估算字數：3116

核心問題：Coding Agent 的價值，只是幫工程師寫新功能嗎？
核心觀點：Coding Agent 的企業價值，正在從寫程式擴展到理解舊系統、找出風險、整理技術債。

資料校準提醒：若本章引用 arXiv 預印本，請把它視為最新研究趨勢與觀念校準，不要直接當成已定型的產業標準。
