第二章｜真實世界不是 Demo：為什麼 Agent 一上線就變笨？

用途：本資料夾為本章完整交付包，可作為書稿、自讀筆記、演講素材、投影片大綱與課程轉化基底。

包含檔案：
- chapter_02_main.docx：本章 Word 書稿
- chapter_02_main.md：本章 Markdown 書稿
- chapter_02_speech_notes.md：演講轉化筆記
- chapter_02_slide_outline.md：投影片大綱
- chapter_02_quotes.md：金句庫
- chapter_02_loop_canvas.md：概念模型與課程轉化畫布
- README.txt：本說明

估算字數：3313

核心問題：為什麼 AI Agent 在 demo 裡很強，一進企業現場就常常失效？
核心觀點：不要用展示效果判斷 Agent 能不能導入企業，要用真實流程、髒資料、模糊需求與權限限制去測試。

資料校準提醒：若本章引用 arXiv 預印本，請把它視為最新研究趨勢與觀念校準，不要直接當成已定型的產業標準。
