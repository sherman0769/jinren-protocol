第六章｜影音生成開始進入「時間」與「視角」的時代

用途：本資料夾為本章完整交付包，可作為書稿、自讀筆記、演講素材、投影片大綱與課程轉化基底。

包含檔案：
- chapter_06_main.docx：本章 Word 書稿
- chapter_06_main.md：本章 Markdown 書稿
- chapter_06_speech_notes.md：演講轉化筆記
- chapter_06_slide_outline.md：投影片大綱
- chapter_06_quotes.md：金句庫
- chapter_06_loop_canvas.md：概念模型與課程轉化畫布
- README.txt：本說明

估算字數：3137

核心問題：AI 影片的難題，真的只是讓圖片動起來嗎？
核心觀點：AI 影片的下一步，不只是生成畫面，而是掌握時間、視角、證據與連續性。

資料校準提醒：若本章引用 arXiv 預印本，請把它視為最新研究趨勢與觀念校準，不要直接當成已定型的產業標準。
