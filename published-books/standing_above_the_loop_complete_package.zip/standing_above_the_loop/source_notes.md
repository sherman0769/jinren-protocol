# 本書引用來源整理

資料校準日期：2026-07-08

提醒：arXiv 預印本是最新研究趨勢，不等於已完成同儕審查或已成產業標準。正式出版前建議再次查證版本、日期與後續更新。

## OpenAI - New tools for building agents / Agents SDK documentation
- 類型：官方文件與官方部落格
- 日期：2025-03 起持續更新
- URL：https://openai.com/index/new-tools-for-building-agents/ ; https://openai.github.io/openai-agents-python/tools/
- 本書用途：用於校準 agent、工具、tracing、workflow 可觀測性等概念。

## LLM-as-a-Verifier: A General-Purpose Verification Framework
- 類型：arXiv 預印本
- 日期：2026-07-06
- URL：https://arxiv.org/abs/2607.05391
- 本書用途：提出 verification 作為 LLM 能力提升的新 scaling axis，包含細緻分數、重複驗證、標準拆解與 agentic task 監控。

## AgentGym2: Benchmarking Large Language Model Agents in De-Idealized Real-World Environments
- 類型：arXiv 預印本
- 日期：2026-07-06
- URL：https://arxiv.org/html/2607.05174v1
- 本書用途：用於說明真實部署與 demo benchmark 的落差：模糊需求、工具探索、髒資料、不完整資訊與 end-to-end task completion。

## FORGE: Research-Trajectory Hijacking Attacks on Deep Research Agents
- 類型：arXiv 預印本
- 日期：2026-07-06
- URL：https://arxiv.org/html/2607.04718v1
- 本書用途：用於說明 deep research agent 的 retrieval-planning coupling、planning-layer poisoning、PRISM 與 Root Query Anchoring。

## MRMS: A Multi-Resolution Memory Substrate for Long-Lived AI Agents
- 類型：arXiv 預印本
- 日期：2026-07-06
- URL：https://arxiv.org/abs/2607.04617
- 本書用途：用於說明長期 Agent 記憶不是長上下文，而是結構化、向量、圖關係與短中長期記憶治理。

## Search Beyond What Can Be Taught: Evolving the Knowledge Boundary in Agentic Visual Generation
- 類型：arXiv 預印本
- 日期：2026-07-06
- URL：https://arxiv.org/abs/2607.05382
- 本書用途：用於說明圖像生成的世界知識瓶頸，以及搜尋接地的視覺生成。

## MV-Forcing: Long Multi-View Video Generation via 4D-Grounded Spatio-Temporal Self-Forcing
- 類型：arXiv 預印本與專案頁
- 日期：2026-07-06
- URL：https://arxiv.org/abs/2607.05376 ; https://galfiebelman.github.io/mv-forcing/
- 本書用途：用於說明長時間、多視角、4D 幾何一致性的影片生成方向。

## TimeThink: Reasoning with Time for Video LLMs
- 類型：arXiv 預印本
- 日期：2026-07-06
- URL：https://arxiv.org/abs/2607.05089
- 本書用途：用於說明 Video-LLM 的時間證據探索、候選時間區間與 step-wise temporal process reward。

## Government of Alberta uses Claude to find and fix cybersecurity vulnerabilities across government systems
- 類型：Anthropic 官方案例
- 日期：2026-07-06
- URL：https://www.anthropic.com/news/alberta-government-claude-cybersecurity
- 本書用途：用於說明 Claude Code、Opus、Sonnet 在政府系統資安盤點、技術債與漏洞修補中的案例。

## How A2A is Building a World of Collaborative Agents
- 類型：Google Developers Blog 官方文章
- 日期：2026-06-18
- URL：https://developers.googleblog.com/how-a2a-is-building-a-world-of-collaborative-agents/
- 本書用途：用於說明 A2A 如何讓專門 Agent 安全協作、交接任務、保持 secure boundary 與減少 context pollution。

## Claude Science, an AI workbench for scientists, is now available
- 類型：Anthropic 官方公告與 Reuters 報導
- 日期：2026-06-30
- URL：https://www.anthropic.com/news/claude-science-ai-workbench ; https://www.reuters.com/science/anthropic-unveils-claude-science-ai-platform-scientific-research-2026-06-30/
- 本書用途：用於說明 AI research workbench、auditable artifacts、compute、source code、environment 與研究流程整合。
