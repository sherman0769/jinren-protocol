第十章｜教學的改變：從提示詞教學，走向流程設計教學

用途：本資料夾為本章完整交付包，可作為書稿、自讀筆記、演講素材、投影片大綱與課程轉化基底。

包含檔案：
- chapter_10_main.docx：本章 Word 書稿
- chapter_10_main.md：本章 Markdown 書稿
- chapter_10_speech_notes.md：演講轉化筆記
- chapter_10_slide_outline.md：投影片大綱
- chapter_10_quotes.md：金句庫
- chapter_10_loop_canvas.md：概念模型與課程轉化畫布
- README.txt：本說明

估算字數：3580

核心問題：如果 AI 的下一階段是 Agent 工作流，那 AI 教學要怎麼改？
核心觀點：AI 教學不能停在 prompt，下一階段要教的是任務、工具、工作流、記憶、驗證、治理與 Human on Loop。

資料校準提醒：若本章引用 arXiv 預印本，請把它視為最新研究趨勢與觀念校準，不要直接當成已定型的產業標準。
