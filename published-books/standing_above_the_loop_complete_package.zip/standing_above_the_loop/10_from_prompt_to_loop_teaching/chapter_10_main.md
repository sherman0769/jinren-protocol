# 第十章｜教學的改變：從提示詞教學，走向流程設計教學

**核心問題：**如果 AI 的下一階段是 Agent 工作流，那 AI 教學要怎麼改？

**核心觀點：**AI 教學不能停在 prompt，下一階段要教的是任務、工具、工作流、記憶、驗證、治理與 Human on Loop。

**本章比喻：**Prompt 教學像教學生怎麼跟助理說話；流程設計教學像教管理者怎麼設計一間可以運轉的辦公室。

**本章校準來源：**

- OpenAI - New tools for building agents / Agents SDK documentation（官方文件與官方部落格，2025-03 起持續更新）
  URL：https://openai.com/index/new-tools-for-building-agents/ ; https://openai.github.io/openai-agents-python/tools/
  用途：用於校準 agent、工具、tracing、workflow 可觀測性等概念。
- LLM-as-a-Verifier: A General-Purpose Verification Framework（arXiv 預印本，2026-07-06）
  URL：https://arxiv.org/abs/2607.05391
  用途：提出 verification 作為 LLM 能力提升的新 scaling axis，包含細緻分數、重複驗證、標準拆解與 agentic task 監控。
- AgentGym2: Benchmarking Large Language Model Agents in De-Idealized Real-World Environments（arXiv 預印本，2026-07-06）
  URL：https://arxiv.org/html/2607.05174v1
  用途：用於說明真實部署與 demo benchmark 的落差：模糊需求、工具探索、髒資料、不完整資訊與 end-to-end task completion。
- MRMS: A Multi-Resolution Memory Substrate for Long-Lived AI Agents（arXiv 預印本，2026-07-06）
  URL：https://arxiv.org/abs/2607.04617
  用途：用於說明長期 Agent 記憶不是長上下文，而是結構化、向量、圖關係與短中長期記憶治理。
- How A2A is Building a World of Collaborative Agents（Google Developers Blog 官方文章，2026-06-18）
  URL：https://developers.googleblog.com/how-a2a-is-building-a-world-of-collaborative-agents/
  用途：用於說明 A2A 如何讓專門 Agent 安全協作、交接任務、保持 secure boundary 與減少 context pollution。
- Claude Science, an AI workbench for scientists, is now available（Anthropic 官方公告與 Reuters 報導，2026-06-30）
  URL：https://www.anthropic.com/news/claude-science-ai-workbench ; https://www.reuters.com/science/anthropic-unveils-claude-science-ai-platform-scientific-research-2026-06-30/
  用途：用於說明 AI research workbench、auditable artifacts、compute、source code、environment 與研究流程整合。
提醒：若來源為 arXiv 預印本，本書將它視為最新研究趨勢與觀念校準，不把它寫成已定型的產業標準。

---

## 一、這一章要解決的問題

如果 AI 的下一階段是 Agent 工作流，那 AI 教學要怎麼改？

這個問題表面上是技術問題，實際上是工作方法問題。當 AI 還停留在聊天視窗裡，我們只需要追問答案是否好用；但當 AI 開始進入任務、工具、資料、流程與組織權限，問題就會變成：這個系統能不能被信任、被追蹤、被修正、被放行。

## 二、章首開場

這本書一路走到這裡，其實都在回答同一個問題：AI 教學要怎麼從「提示詞課」走向「工作流課」。Prompt Engineering 不是不重要，而是它已經不夠。

如果 AI 只是一個聊天工具，教 prompt 就夠了。但當 AI 變成 Agent，開始查資料、記憶、操作工具、生成影像、寫程式、與其他 Agent 協作時，教學就必須升級。因為學生真正需要的，不只是更會問，而是更會設計。

## 三、現象觀察

現在很多人看 AI，還是習慣從單點能力開始看：會不會寫、會不會查、會不會畫、會不會改程式、會不會整理資料。這些能力當然重要，但它們只是節點，不是系統。真正的工作發生在節點之間：資料如何進來、任務如何拆解、工具如何被呼叫、結果如何被驗證、錯誤如何被回報、人如何決定是否放行。

以「李詩民式 AI 教學七層框架」來看，本章真正要處理的不是單一功能，而是把功能放回工作迴路。只要沒有迴路，AI 再會做，都可能只是一次漂亮的展示；只要迴路設計得好，AI 的能力才有機會變成可累積的工作產能。

## 四、用白話講清楚核心技術

把前面九章收束，可以得到一個七層框架。第一層是 Prompt：把需求說清楚。第二層是 Tool：知道 AI 能使用哪些工具與資料。第三層是 Workflow：把任務拆成可執行、可回報的流程。第四層是 Memory：設計什麼該記、該忘、該更新。第五層是 Verification：設定驗收標準。第六層是 Governance：處理權限、風險、審計與責任。第七層是 Human on Loop：人站在迴路之上設計整個系統。

這七層不是技術名詞堆疊，而是一套教學順序。初學者先學會說清楚需求；進階者學會接工具、設流程；企業導入者要學記憶、驗證與治理；真正的 AI 架構師則要能站在迴路之上，看整個系統如何接地、行動、驗證、追蹤、記憶、治理與改善。

這也是從 Prompt Engineering 到 Loop Engineering 的路徑。Prompt Engineering 解決的是輸入品質；Loop Engineering 解決的是工作系統品質。

## 五、這個技術為什麼重要

如果 AI 教學一直停在 prompt，會產生兩個問題。第一，學員會把 AI 當成文案產生器，而不是工作系統。第二，企業會以為導入 AI 就是買工具與辦訓練，卻忽略資料、流程、權限、驗證與治理。

真正有價值的 AI 教學，應該幫學員建立 Loop Literacy：看懂一個 AI 任務是否有清楚輸入、可用工具、明確流程、合適記憶、驗證標準、風險治理與人工放行。這比背 prompt 模板更難，但也更有長期價值。

## 六、模型整理

### 李詩民式 AI 教學七層框架

1. Prompt 層：怎麼說清楚需求
2. Tool 層：AI 可以使用哪些工具
3. Workflow 層：任務如何拆解、執行、回報
4. Memory 層：哪些資訊需要被保留與更新
5. Verification 層：如何驗證結果正確性
6. Governance 層：權限、風險、審計、責任
7. Human on Loop 層：人站在迴路上方設計整個系統


這個模型可以作為上課、演講與企業訪談時的白板框架。它的用途不是讓聽眾背名詞，而是讓聽眾看到：AI 工作流不是一段 prompt，而是一組需要被設計、檢查與更新的關係。

## 七、實際情境

對企業內訓，可以把七層框架拆成一天課或兩天課。第一階段讓學員盤點自己的工作任務；第二階段設計工具與資料；第三階段畫出工作流；第四階段設定記憶與驗證；第五階段討論權限與風險；最後讓主管看整個 Human on Loop 儀表板。

對社群內容，可以把每一層拆成一篇 FB 長文。Prompt 層談「不要只問，要說清楚任務」；Tool 層談「AI 的能力來自它接上什麼」；Workflow 層談「流程不是 prompt」；Memory 層談「記憶不是聊天紀錄」；Verification 層談「會做不等於做對」；Governance 層談「自動化需要邊界」；Human on Loop 層談「人站在迴路之上」。

## 八、李詩民自己的閱讀筆記

這章是我自己的課程轉型宣言。未來我不能只做 AI 工具老師，而要做 AI 工作流老師。工具會變，模型會變，平台會變，但流程設計、驗證、記憶、治理與人機協作的位置，會長期存在。

我真正想教的是：讓一般人也能看懂 AI 系統怎麼工作，讓企業主管知道不是買一個模型就能導入，讓內容創作者知道 AI 不是產文案，而是建立知識工作迴路。

## 九、演講提煉

1. 先用一句話破題：AI 教學不能停在 prompt，下一階段要教的是任務、工具、工作流、記憶、驗證、治理與 Human on Loop。
2. 再用生活比喻降低門檻：Prompt 教學像教學生怎麼跟助理說話；流程設計教學像教管理者怎麼設計一間可以運轉的辦公室。
3. 接著畫出模型：李詩民式 AI 教學七層框架。
4. 最後連回 Human on Loop：人不是消失，而是站在迴路上方設計規則、驗證與放行。

## 十、可以轉成課程的一句話

> Prompt Engineering 教你怎麼跟 AI 說話；Loop Engineering 教你怎麼讓 AI 在真實世界可靠工作。

## 十一、可以轉成 FB 貼文的一段話

AI 教學要升級了。提示詞仍然重要，但已經不是終點。未來真正有價值的 AI 課程，要教 Prompt、Tool、Workflow、Memory、Verification、Governance 與 Human on Loop。因為 AI 的下一階段不是更會回答，而是更能進入真實工作流。會問 AI 是起點，會設計 AI 工作迴路才是下一階段能力。

## 十二、延伸問題：這個技術未來還會怎麼發展？

1. AI 教學市場是否會從 prompt template 課程，轉向 AI workflow architecture 課程？
2. 企業是否會需要專門的 Loop Engineering 顧問與內訓教材？

## 十三、章末金句庫

1. Prompt Engineering 是入口，Loop Engineering 是下一階段。
2. AI 教學不能只教怎麼問，要教怎麼設計工作迴路。
3. 工具會變，但工作流設計能力會留下來。
4. 會問 AI 是起點，會設計 AI 工作系統才是能力。
5. Human on Loop 是 AI 教學的終點，也是企業導入的起點。

## 十四、三個常見誤解

### 誤解一：只要模型更強，這個問題自然會消失。
模型變強會改善表現，但不會自動產生工作流。如果 AI 的下一階段是 Agent 工作流，那 AI 教學要怎麼改？ 這類問題通常不是單純智力不足，而是資料、工具、流程、權限、驗證與責任沒有被設計。真正的關鍵是把模型能力放進可追蹤的迴路。

### 誤解二：工具接越多，Agent 就越成熟。
工具越多，能力邊界也越大；但如果沒有權限、驗證、日誌與人工放行，工具越多反而風險越大。李詩民式 AI 教學七層框架 的目的，就是讓工具不只是被接上，而是被放進有邊界的工作系統。

### 誤解三：Human on Loop 是把人拿掉。
Human on Loop 不是無人化，而是讓人從每一步的救火者，變成整個迴路的設計者與監督者。人仍然負責標準、風險、倫理、責任與最後放行，只是不再被迫卡在每一個微小步驟裡。

## 十五、企業導入檢核表

1. 這個任務的原始需求是否已經被清楚定義？是否存在模糊、衝突或隱含假設？
2. AI 需要讀取哪些資料？資料是否最新、完整、可追溯？
3. AI 會使用哪些工具？每個工具的權限、限制與風險是否清楚？
4. 本章模型「李詩民式 AI 教學七層框架」中的每一步是否都有對應的輸入、輸出與驗收標準？
5. 如果 AI 做錯，錯誤會停在哪裡？誰會收到通知？誰可以決定重跑或放行？
6. 哪些結果可以自動通過？哪些結果必須人工審核？
7. 過程是否留下日誌、版本、引用、工具呼叫與人工修改紀錄？
8. 這次任務的回饋，如何進入下一輪流程改善？

## 十六、課程設計練習

如果把這一章設計成 30 分鐘企業內訓，可以安排三段練習。第一段，請學員寫下自己部門一個真實任務，並回答：如果 AI 的下一階段是 Agent 工作流，那 AI 教學要怎麼改？ 第二段，請學員把任務套進「李詩民式 AI 教學七層框架」，找出目前缺少的步驟。第三段，請學員設計一個最小可行迴路：只改一個流程、只接一個工具、只建立一個驗證點，先讓 AI 從 demo 走向小規模真實使用。

如果把這一章設計成社群內容，可以拆成三篇。第一篇用比喻破題：Prompt 教學像教學生怎麼跟助理說話；流程設計教學像教管理者怎麼設計一間可以運轉的辦公室。 第二篇解釋技術趨勢，但提醒來源若為預印本就只能當趨勢校準。第三篇轉成實務建議：Prompt Engineering 教你怎麼跟 AI 說話；Loop Engineering 教你怎麼讓 AI 在真實世界可靠工作。

## 十七、本章可延伸的產品或服務構想

1. 企業內訓工作坊：用「李詩民式 AI 教學七層框架」盤點一個部門的 AI 導入流程。
2. 顧問診斷表：把本章檢核表做成訪談問卷，協助企業看見 AI 導入缺口。
3. 社群系列文：用本章金句作為每篇貼文標題，拆成 5 到 7 篇短文。
4. 課程教材：把本章投影片大綱改成 10 張簡報，搭配一個真實任務練習。

## 十八、給未來自己的備忘

未來重讀這一章時，不要只看技術名稱是否還流行，而要看它背後解決的結構問題是否仍然存在。工具、模型、平台都會變，但「如果 AI 的下一階段是 Agent 工作流，那 AI 教學要怎麼改？」這類問題，只要 AI 要進入真實工作，就不會消失。

真正值得累積的，是把這章轉成自己的方法論：能上台講，能帶企業討論，能讓學員做練習，能變成一張圖，能拆成一系列貼文，也能回到書稿裡成為一段有深度的文字。

## 十九、章末收束

這一章最後要留下的不是一個名詞，而是一個位置感：AI 不只是工具，AI 開始成為工作迴路裡的行動者。當 AI 成為行動者，人就不能只當提問者。人要成為設計迴路、設定標準、檢查結果、決定放行的人。這就是《站在迴路之上》真正想建立的思考方式。
