第四章｜AI 的記憶不是聊天紀錄，而是一種系統設計

用途：本資料夾為本章完整交付包，可作為書稿、自讀筆記、演講素材、投影片大綱與課程轉化基底。

包含檔案：
- chapter_04_main.docx：本章 Word 書稿
- chapter_04_main.md：本章 Markdown 書稿
- chapter_04_speech_notes.md：演講轉化筆記
- chapter_04_slide_outline.md：投影片大綱
- chapter_04_quotes.md：金句庫
- chapter_04_loop_canvas.md：概念模型與課程轉化畫布
- README.txt：本說明

估算字數：3175

核心問題：AI 助理到底應該記住什麼？又應該忘掉什麼？
核心觀點：真正好的 AI 助理，不是什麼都記得，而是知道什麼該記、什麼該忘、什麼需要證據、什麼已經過期。

資料校準提醒：若本章引用 arXiv 預印本，請把它視為最新研究趨勢與觀念校準，不要直接當成已定型的產業標準。
