第九章｜AI for Science：研究不只是摘要，而是可稽核的工作台

用途：本資料夾為本章完整交付包，可作為書稿、自讀筆記、演講素材、投影片大綱與課程轉化基底。

包含檔案：
- chapter_09_main.docx：本章 Word 書稿
- chapter_09_main.md：本章 Markdown 書稿
- chapter_09_speech_notes.md：演講轉化筆記
- chapter_09_slide_outline.md：投影片大綱
- chapter_09_quotes.md：金句庫
- chapter_09_loop_canvas.md：概念模型與課程轉化畫布
- README.txt：本說明

估算字數：3163

核心問題：AI 做研究，只是幫我們摘要論文嗎？
核心觀點：AI 正在從聊天工具走向專業工作台，把資料、工具、程式、圖表、引用、審查與產出串成可追蹤流程。

資料校準提醒：若本章引用 arXiv 預印本，請把它視為最新研究趨勢與觀念校準，不要直接當成已定型的產業標準。
