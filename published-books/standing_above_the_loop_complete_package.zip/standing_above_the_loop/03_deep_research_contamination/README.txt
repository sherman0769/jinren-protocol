第三章｜Deep Research 的風險：AI 查資料，也可能被資料牽著走

用途：本資料夾為本章完整交付包，可作為書稿、自讀筆記、演講素材、投影片大綱與課程轉化基底。

包含檔案：
- chapter_03_main.docx：本章 Word 書稿
- chapter_03_main.md：本章 Markdown 書稿
- chapter_03_speech_notes.md：演講轉化筆記
- chapter_03_slide_outline.md：投影片大綱
- chapter_03_quotes.md：金句庫
- chapter_03_loop_canvas.md：概念模型與課程轉化畫布
- README.txt：本說明

估算字數：3165

核心問題：AI 查到錯資料，只是答案錯而已嗎？還是整個研究方向都會被帶歪？
核心觀點：Deep Research 的風險不只在資料污染，而在研究路徑污染。

資料校準提醒：若本章引用 arXiv 預印本，請把它視為最新研究趨勢與觀念校準，不要直接當成已定型的產業標準。
