第五章｜圖像生成的下一步：不是提示詞，而是搜尋接地

用途：本資料夾為本章完整交付包，可作為書稿、自讀筆記、演講素材、投影片大綱與課程轉化基底。

包含檔案：
- chapter_05_main.docx：本章 Word 書稿
- chapter_05_main.md：本章 Markdown 書稿
- chapter_05_speech_notes.md：演講轉化筆記
- chapter_05_slide_outline.md：投影片大綱
- chapter_05_quotes.md：金句庫
- chapter_05_loop_canvas.md：概念模型與課程轉化畫布
- README.txt：本說明

估算字數：3166

核心問題：為什麼 AI 圖像模型畫得很漂亮，卻還是會畫錯？
核心觀點：未來圖像生成不是只靠 prompt，而是要先查資料、抓參考、確認世界知識，再生成畫面。

資料校準提醒：若本章引用 arXiv 預印本，請把它視為最新研究趨勢與觀念校準，不要直接當成已定型的產業標準。
