第一章｜AI Agent 的新問題：不是能不能做，而是能不能證明它做對了

用途：本資料夾為本章完整交付包，可作為書稿、自讀筆記、演講素材、投影片大綱與課程轉化基底。

包含檔案：
- chapter_01_main.docx：本章 Word 書稿
- chapter_01_main.md：本章 Markdown 書稿
- chapter_01_speech_notes.md：演講轉化筆記
- chapter_01_slide_outline.md：投影片大綱
- chapter_01_quotes.md：金句庫
- chapter_01_loop_canvas.md：概念模型與課程轉化畫布
- README.txt：本說明

估算字數：3215

核心問題：AI 做完事情之後，誰來判斷它做得對不對？
核心觀點：Agent 時代的第一個核心能力，不是生成，而是驗證。

資料校準提醒：若本章引用 arXiv 預印本，請把它視為最新研究趨勢與觀念校準，不要直接當成已定型的產業標準。
