# 序章｜為什麼 ChatGPT 已經不是重點了？｜金句庫

1. ChatGPT 是入口，Agent 是流程。
2. Prompt 是一句話，Loop 是一套系統。
3. 會回答，不代表會工作；會生成，不代表能交付。
4. 流程是把事情做完，迴路是讓事情越做越好。
5. Human in the Loop 是人在流程裡救火；Human on the Loop 是人在流程之上設計系統。
6. 未來稀缺的人，不是最會問 AI 的人，而是最會設計 AI 工作迴路的人。
