# 序章｜為什麼 ChatGPT 已經不是重點了？｜投影片大綱

## Slide 1｜封面
序章｜為什麼 ChatGPT 已經不是重點了？

## Slide 2｜核心問題
為什麼我們不能再只把 AI 當成一個聊天視窗？

## Slide 3｜一句話觀點
ChatGPT 是入口，Agent 是流程；Prompt 是一句話，Loop 是一套系統。

## Slide 4｜生活比喻
ChatGPT 像櫃台問答，Agent 像一套會接單、查資料、執行、驗收、回報的工作站。

## Slide 5｜技術白話化
用本章來源校準，但不寫成論文摘要。

## Slide 6｜Trusted Agent Loop：可信 Agent 迴路
Ground 接地 / Act 行動 / Verify 驗證 / Trace 追蹤 / Remember 記憶 / Govern 治理 / Improve 改善

## Slide 7｜企業或教學應用
企業導入 AI，不應該只是架一個內部聊天機器人，而要先盤點任務迴路：客服如何分類客訴、財務如何核對憑證、行銷如何生成素材並回收成效、工程如何讓 Coding Agent 掃描程式碼並留下修補紀錄。

## Slide 8｜李詩民閱讀筆記
我真正要內化的不是「我比別人更會問 AI」，而是「我比以前更會設計 AI 如何工作」。當 AI 只是回答者，我站在對話框前；當 AI 變成工作者，我必須站在迴路之上。

## Slide 9｜課程一句話
Prompt Engineering 教你怎麼跟 AI 說話；Loop Engineering 教你怎麼讓 AI 在真實世界可靠工作。

## Slide 10｜結尾金句
ChatGPT 是入口，Agent 是流程。
