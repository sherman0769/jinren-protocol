序章｜為什麼 ChatGPT 已經不是重點了？

用途：本資料夾為本章完整交付包，可作為書稿、自讀筆記、演講素材、投影片大綱與課程轉化基底。

包含檔案：
- chapter_00_main.docx：本章 Word 書稿
- chapter_00_main.md：本章 Markdown 書稿
- chapter_00_speech_notes.md：演講轉化筆記
- chapter_00_slide_outline.md：投影片大綱
- chapter_00_quotes.md：金句庫
- chapter_00_loop_canvas.md：概念模型與課程轉化畫布
- README.txt：本說明

估算字數：3232

核心問題：為什麼我們不能再只把 AI 當成一個聊天視窗？
核心觀點：ChatGPT 是入口，Agent 是流程；Prompt 是一句話，Loop 是一套系統。

資料校準提醒：若本章引用 arXiv 預印本，請把它視為最新研究趨勢與觀念校準，不要直接當成已定型的產業標準。
