# 序章｜為什麼 ChatGPT 已經不是重點了？｜Loop Canvas

## 核心問題
為什麼我們不能再只把 AI 當成一個聊天視窗？

## 核心觀點
ChatGPT 是入口，Agent 是流程；Prompt 是一句話，Loop 是一套系統。

## 模型
Trusted Agent Loop：可信 Agent 迴路

## 迴路步驟
- Ground 接地
- Act 行動
- Verify 驗證
- Trace 追蹤
- Remember 記憶
- Govern 治理
- Improve 改善

## 放進課程時的轉換
- 課程一句話：Prompt Engineering 教你怎麼跟 AI 說話；Loop Engineering 教你怎麼讓 AI 在真實世界可靠工作。
- 練習設計：請學員把自己的真實任務放進本章模型，標出輸入、工具、驗證、記憶與人工放行點。

## 放進企業內訓時的轉換
- 先盤點真實流程，再決定 AI 介入位置。
- 每個 AI 介入點都要定義資料來源、工具權限、驗收標準與異常處理。
