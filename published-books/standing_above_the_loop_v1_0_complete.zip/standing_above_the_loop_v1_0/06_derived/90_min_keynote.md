# 《站在迴路之上》90 分鐘主題演講設計

## 演講題目

《站在迴路之上：當 Agent 開始工作，人如何重新設計 AI、組織與自己的位置》

## 聽眾承諾

90 分鐘後，聽眾能用一張圖理解 Agent 為何需要 Context、Harness、Runtime、Loop、證據與人類責任，並完成一份自己的「AI 工作迴路初稿」。

## 時間配置

| 時間 | 段落 | 唯一任務 |
|---|---|---|
| 0–8 分 | 開場：真正改變的是動詞 | 從「問 AI」切換成「交辦工作」 |
| 8–20 分 | Task → Workflow → Outcome | 說清楚 AI 到底要完成什麼 |
| 20–32 分 | 能力不等於可靠 | 看見 Context、工具、權限與資料品質缺口 |
| 32–47 分 | Agent 的工作現場 | 用 Context、Harness、Runtime 三層建立可工作系統 |
| 47–62 分 | 七環工作迴路 | 把一次成功變成可驗證、可回饋、可交接的循環 |
| 62–74 分 | 雙閘門證據迴路 | 在行動前與主張釋出前設置可信邊界 |
| 74–84 分 | AI 原生組織 | 從工具覆蓋轉向 DRI＋Agents 與共同作業層 |
| 84–90 分 | Human Above the Loop | 定義人不可外包的八項責任 |

## 演講主線

### 第 1 站｜AI 不再只回答：從 Chatbot 到 Agent

- 問題：AI 從回答走向行動後，真正新增的是什麼責任？
- 核心答案：Agent 的分水嶺不是文字更好，而是能在環境中根據目標採取行動；因此必須同時設計完成條件、資料、工具、權限、停止與責任。
- 模型：Agent 自主性六面向（目標自主、規劃自主、資料自主、工具自主、影響自主、停止自主）

### 第 2 站｜從 Task 到 Workflow，再到 Outcome

- 問題：做了很多 AI 功能，為什麼仍沒有真正改善工作？
- 核心答案：Task 只交出動作，Workflow 交出流程，Outcome 才定義真實世界的完成、品質、邊界與證據。
- 模型：Outcome Contract 八問（目標、使用者、完成條件、禁止條件、證據、停止、核准、回寫）

### 第 3 站｜智能變便宜，工作為什麼沒有自動變好

- 問題：模型與生成愈便宜，為什麼企業成本與工作複雜度可能仍然上升？
- 核心答案：更便宜的生成會增加使用量並把稀缺轉移到選擇、驗證、脈絡、維護與責任；只有重設 Outcome 與流程，速度才會轉化成生產力。
- 模型：AI 工作總成本（生成、脈絡、整合、驗證、人工例外、錯誤影響、維護治理、下游吸收）

### 第 4 站｜Context Engineering：AI 所處的世界

- 問題：同一句 Prompt 為什麼在不同工作環境中會產生完全不同結果？
- 核心答案：模型只能根據被提供的世界行動；必須以最小必要 Context 管理正式來源、狀態、工具、限制、記憶與交接。
- 模型：Context 五層結構（長期憲法、專案世界、任務包、執行狀態、交接摘要）

### 第 5 站｜Harness Engineering：模型之外的工作契約

- 問題：模型已經很強，為什麼 Agent 系統仍常在工具、權限與交付上失敗？
- 核心答案：失敗常在模型之外；Harness 必須把指令、工具、路由、輸出、驗證、權限、預算、停止與學習變成可測試契約。
- 模型：Harness 九元件（指令、工具、路由、輸出、驗證、權限、預算時間、停止升級、版本學習）

### 第 6 站｜Runtime：讓 AI 能持續工作的現場

- 問題：Agent 如何跨時間、工具、人員與失敗持續完成工作？
- 核心答案：Runtime 要管理任務身份、狀態、checkpoint、工具、沙箱、秘密、事件、併發、成本、人工介入、觀測與回寫。
- 模型：Runtime 十二能力（任務身份、狀態、Checkpoint、工具執行、隔離、秘密身份、事件佇列、併發鎖定、成本資源、人工介入、可觀測性、成果回寫）

### 第 7 站｜Loop Engineering：從一次成功到持續改善

- 問題：如何把一次 Agent 成功，變成能在變化中持續改善的系統？
- 核心答案：迴路必須把目標、脈絡、工具、驗證、回饋、監督與交接連起來，並有停止條件與回寫。
- 模型：七環工作迴路（目標、脈絡、工具、驗證、回饋、監督、交接）

### 第 8 站｜看得見才改得動：Tracing、Evals 與可觀測性

- 問題：Agent 錯了之後，如何從猜測變成可定位、可重現、可修正？
- 核心答案：要連結 logs、traces、metrics、trials、graders 與真實 outcomes，並同時評估結果、過程與邊界。
- 模型：Agent 可觀測四訊號（Logs、Traces、Metrics、Outcomes）

### 第 9 站｜行動前先過閘門：Runtime Data-Quality Gating

- 問題：模型推理很好，為什麼仍可能在錯誤資料上自信行動？
- 核心答案：許多缺陷藏在 freshness、lineage、schema、authority 與 metadata；必須由 Runtime 在行動路徑上執行確定性與語意品質閘門。
- 模型：資料品質八維（Freshness、Lineage、Schema、Consistency、Completeness、Authority、Integrity、Scope）

### 第 10 站｜主張釋出前要有帳：Evidence Ledger、Guardrails 與人工審查

- 問題：有來源的 AI 內容，為什麼仍可能不可信？
- 核心答案：來源可用不等於支持主張；必須拆解 claim、建立 evidence packet、判定 supports/contradicts/mixed/insufficient，並以 Guardrails 與 Human Review 控制釋出。
- 模型：雙閘門證據迴路（行動前資料品質閘門、Agent 分析／生成、主張原子化、證據關係判定、Guardrails、人工審查、證據帳本）

### 第 11 站｜AI 原生組織：從一號位工程、AI OS 到 DRI＋Agents

- 問題：公司裡到處都有 AI，為什麼仍不算 AI 原生組織？
- 核心答案：AI 原生需要一號位方向、共同 Ontology、Context、Tools、Runtime、Evidence、Observability 與 DRI 責任，不只是工具覆蓋。
- 模型：AI OS 八層（Model、Ontology/Data、Context、Tool/Interoperability、Harness/Runtime、Evidence/Quality、Observability/Improvement、Governance/Responsibility）

### 第 12 站｜人站在迴路之上：Human Above the Loop

- 問題：當 AI 開始自己做事，人真正不可外包的工作是什麼？
- 核心答案：人可以離開重複步驟，但必須負責定義、設計、設界、觀測、驗證、介入、判斷與承擔後果。
- 模型：Human Above the Loop 八責任（定義、設計、設界、觀測、驗證、介入、判斷、負責）

## 建議現場互動

請每位聽眾選一個每週重複的工作，依序回答：

1. 真正 Outcome 是什麼？
2. AI 需要哪些 Context？
3. 哪些工具與權限可給、哪些不可給？
4. 怎麼驗證？什麼情況必須停止？
5. 哪些證據要留下？
6. 最後誰判斷、誰負責？

## 收束金句

> AI 可以離開某些步驟，人不能離開責任。站在迴路之上，不是遠離工作，而是對整個工作系統負責。
