# 第二部｜替 Agent 建立工作現場

Agent 不能只靠模型能力工作。它需要一個由 Context、Harness、Runtime 與改善 Loop 共同構成的現場。本部把「會做事」拆成可設計、可執行、可恢復、可交接的系統。
