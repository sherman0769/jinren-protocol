# 名詞登錄表

| 名詞 | 本書中文用法 | 定義與邊界 |
|---|---|---|
| Chatbot | 對話型 AI | 以問答與生成為主，不預設能持續操作環境。 |
| Copilot | 副駕型 AI | 人主導流程，AI 在局部步驟提供建議或產出。 |
| Workflow | 工作流 | 由預先設計的路徑串接模型、工具與規則。 |
| Agent | AI Agent／代理 | 能根據目標，在多個步驟中選擇工具與行動的系統；不等同人類員工。 |
| Context Engineering | 脈絡工程 | 在推論過程中策展與維護模型當下需要的高訊號資訊。 |
| Harness Engineering | 駕馭層工程／Harness 工程 | 模型之外的工作契約與支架，包含指令、工具、路由、驗證、權限與輸出要求。 |
| Runtime | 運行環境／運行層 | Agent 真正執行、保存狀態、呼叫工具、處理錯誤、暫停與恢復的現場。 |
| Loop Engineering | 迴路工程 | 新興產業語言；本書用來描述可重複、可驗證、可回饋、可監督的 AI 工作循環設計，不宣稱成熟學術標準。 |
| Tracing | 追蹤 | 記錄一次 Agent 執行中的模型呼叫、工具呼叫、交接、規則與狀態。 |
| Observability | 可觀測性 | 能從 traces、metrics、logs 與結果理解系統內部狀態。 |
| Evals | 評測 | 用任務、試次、評分器與結果衡量 Agent 是否達成成功條件。 |
| Guardrails | 防護欄／規則閘門 | 對輸入、輸出、工具與行動做自動檢查或限制。 |
| Human-in-the-Loop | 人在迴路中 | 在特定步驟由人批准、修正或補充。 |
| Human-on-the-Loop | 人監督迴路 | 系統可自主運作，人持續監督並在必要時介入。 |
| Human Above the Loop | 人站在迴路之上 | 本書工作概念：人負責定義、設計、設界、觀測、驗證、介入、判斷與承擔責任。 |
| DRI | 直接責任人 | 對特定結果具清楚責任與決策權的人；不能把最終責任轉嫁給 Agent。 |
| AI OS | 企業 AI 工作／決策作業層 | 本書廣義用法：連結模型、資料、Ontology、Context、權限、工具、流程、觀測與治理的組織運作層；不是單一產品名稱。 |
| MCP | 模型脈絡協定 | 讓 AI 應用以標準化方式連接外部 Context、Resources 與 Tools；不是記憶、治理或完整 Runtime。 |
| A2A | Agent2Agent 協定 | 讓不同 Agent 系統發現能力、溝通、交換資訊與協調任務的開放協定。 |
| Ontology | 企業語意與行動模型 | 把資料映射到真實業務物件、關係、動作與權限的操作層；本書不把它簡化成知識圖譜。 |
| Data-Quality Gate | 資料品質閘門 | Agent 行動前檢查 freshness、lineage、schema、consistency 等證據條件。 |
| Evidence Ledger | 證據帳本 | 將主張與證據包、支持關係、信心與審查路由連結成可追溯紀錄。 |
