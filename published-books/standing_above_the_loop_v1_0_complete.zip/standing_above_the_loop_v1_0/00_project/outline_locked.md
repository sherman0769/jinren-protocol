# 已鎖定全書架構

## 序｜AI 已經開始做事，我們還在學怎麼問

## 導讀｜從《AI未來已來》出發，但不把未來交給任何一本書

# 第一部｜當能力開始成為勞動

1. AI 不再只回答：從 Chatbot 到 Agent
2. 從 Task 到 Workflow，再到 Outcome
3. 智能變便宜，工作為什麼沒有自動變好

# 第二部｜替 Agent 建立工作現場

4. Context Engineering：AI 所處的世界
5. Harness Engineering：模型之外的工作契約
6. Runtime：讓 AI 能持續工作的現場
7. Loop Engineering：從一次成功到持續改善

# 第三部｜讓系統值得信任

8. 看得見才改得動：Tracing、Evals 與可觀測性
9. 行動前先過閘門：Runtime Data-Quality Gating
10. 主張釋出前要有帳：Evidence Ledger、Guardrails 與人工審查

# 第四部｜重新設計組織與人的位置

11. AI 原生組織：從一號位工程、AI OS 到 DRI＋Agents
12. 人站在迴路之上：Human Above the Loop

## 結語｜不要等待被定義，成為定義迴路的人

## 附錄

A. 七環工作迴路實作畫布
B. 雙閘門證據迴路檢查表
C. 30 天建立第一個 AI 工作系統
D. 核心名詞與研究來源
E. 從展示走向正式運行：AI 工作系統上線審查表
