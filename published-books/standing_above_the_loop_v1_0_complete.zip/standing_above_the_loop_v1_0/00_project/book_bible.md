# Book Bible｜《站在迴路之上》

## 1. 書名與定位

- 書名：《站在迴路之上》
- 副標：當 Agent 開始工作，人如何重新設計 AI、組織與自己的位置
- 一句話定位：一本把 Agent 的能力、Runtime 的工程、企業的組織改造與人的責任連成同一條思想線的 AI 工作系統之書。
- 作者角色：AI 架構師、講師、教育推廣者、企業 AI 應用觀察者與實作者。

## 2. 核心讀者

### 核心讀者

已經使用生成式 AI，卻仍停在一次性問答、複製貼上或單點工具的人；以及正在思考 AI 導入、Agent 落地、流程自動化與組織責任的主管與工作者。

### 次要讀者

- AI 應用開發者與產品經理
- 企業顧問、講師與教育工作者
- 想建立個人 AI 工作系統的自由工作者與創作者

## 3. 讀者困境

1. 工具愈來愈多，工作反而更碎。
2. Agent 看起來會做事，卻不知道是否可信。
3. 企業做了許多 PoC，卻沒有改變真正的營運結果。
4. 團隊缺乏 Context、版本、權限、驗證與交接規則。
5. 人不是過度干預每一步，就是把責任錯交給 AI。

## 4. 閱讀後轉變

讀者將能：

- 分辨 Chatbot、Copilot、Workflow、Agent、Runtime 與 AI OS。
- 理解能力、可靠、可治理、可負責之間的差距。
- 建立最小可行 Context、Harness 與 Runtime。
- 用七環工作迴路設計可重複、可改善的 AI 流程。
- 使用 Tracing、Evals、Guardrails、資料品質閘門與證據帳本建立信任。
- 重新理解 DRI、主管與工作者在 Agent 時代的位置。
- 實踐 Human Above the Loop：人在迴路之上的八個責任。

## 5. 核心問題、答案與主張

### 核心問題

當 AI 開始自主執行工作，人應該站在哪裡？

### 核心答案

人要從「每一步的操作者」上移成「整個工作迴路的定義者、設計者、治理者與責任承擔者」。

### 核心主張

1. AI 的下一個分水嶺不是更會回答，而是更能在環境中行動。
2. 模型能力不是工作成果；成果來自模型與 Context、工具、Harness、Runtime、資料、規則和人的共同系統。
3. 能力不等於可靠，可靠不等於可負責，可負責也不代表值得做。
4. Prompt 是一句話，Context 是 AI 所處的世界；Harness 是模型之外的工作契約；Runtime 是契約真正運轉的現場。
5. Loop Engineering 的核心不是讓 AI 無限重試，而是設計有目標、證據、停止條件與回饋的工作循環。
6. Agent 行動前要有最低證據條件，主張釋出前要有可追溯的證據關係。
7. 企業 AI 轉型不能只買 Agent；它必須重做資料、權限、決策、責任與改善迴路。
8. 最終責任不能被模型吸收。人類真正上移的價值，是定義方向、處理例外、判斷取捨與承擔後果。

## 6. 全書思想線

Chatbot 回答問題
→ Agent 開始行動
→ 工作從 Task 走向 Workflow 與 Outcome
→ 能力暴露可靠性與責任缺口
→ Context、Harness、Runtime 建立工作現場
→ Loop Engineering 建立持續改善
→ Tracing、Evals、Guardrails 建立可觀察與可控制
→ Data-Quality Gate 與 Evidence Ledger 建立證據基礎設施
→ AI OS、DRI、Multi-Agent 重寫組織
→ Human Above the Loop 重新定義人的位置

## 7. 原創概念與作者整合框架

### 7.1 七環工作迴路｜Seven-Link Work Loop

本書提出的作者整合框架：

1. 目標 Goal
2. 脈絡 Context
3. 工具 Tools
4. 驗證 Validation
5. 回饋 Feedback
6. 監督 Oversight
7. 交接 Handoff

它不是既有產業標準，而是把 Agent Workflow、Context／Harness Engineering、Evals、DevOps 與 Human Oversight 整理成一般讀者可操作的方法。

### 7.2 雙閘門證據迴路｜Dual-Gate Evidence Loop

本書在 SARC-DQ 與 Evidence-Ledger 研究之上提出的作者整合框架：

- 第一閘門：行動閘門。資料未達「行動前最低證據條件」，Agent 不得採取高影響行動。
- 第二閘門：主張釋出閘門。證據不能支持主張，或出現矛盾、缺漏、混合證據時，必須退回修正或人工審查。

### 7.3 Human Above the Loop｜人站在迴路之上

本書工作概念，不宣稱為既有標準。人的八個上位責任：

1. 定義 Define
2. 設計 Design
3. 設界 Constrain
4. 觀測 Observe
5. 驗證 Validate
6. 介入 Intervene
7. 判斷 Judge
8. 負責 Take Responsibility

## 8. 書籍類型、語氣與深度

- 類型：AI 思想 × 系統工程 × 組織管理 × 工作方法
- 語氣：白話、具觀點、可朗讀、可教學；避免學術論文腔與工具百科。
- 深度：讓一般讀者理解核心邏輯，也讓技術與管理讀者看見可落地的架構。
- 案例：以一般情境、假設案例與公開來源為主；不得虛構作者親身專案或企業成果。

## 9. 不寫什麼

- 不寫成《AI未來已來》摘要、導讀或改寫。
- 不寫成模型、產品、API 功能大全。
- 不預測確切失業比例或沒有可靠依據的市場數據。
- 不把 Loop Engineering、Human Above the Loop、雙閘門證據迴路冒充學術共識或產業標準。
- 不用「AI 會取代所有人」或「AI 永遠不會取代人」的二元口號。
- 不虛構作者學員對話、企業客戶、課程成果或個人經歷。

## 10. 研究與更新邊界

必須更新的項目：Agents SDK、MCP、A2A、Context／Harness Engineering、Evals、Guardrails、Runtime、資料品質研究、法規與標準。

相對穩定的項目：工作迴路、責任設計、證據條件、組織權責與 Human Above the Loop 的思想主張。

## 11. 全書規模與用途

- 章數：12 章＋序、導讀、結語、5 份附錄
- 目標字數：至少 85,000 個中文字符（去除 Markdown 標記後，以品質報告實測為準）
- 正式來源：`01_master/full_book.md`
- 衍生用途：書稿 DOCX、演講筆記、簡報大綱、金句、模型畫布、課程設計

## 12. 已鎖定與待確認

### 已鎖定

- 書名、副標、核心問題與核心答案
- 李開復觀點為重要對話來源，不是全書母體
- 12 章四部結構
- 七環工作迴路、雙閘門證據迴路、Human Above the Loop 為作者整合框架

### 待作者後續補充

- 【待補作者案例】一個從單次 Prompt 走向完整 Runtime 專案的真實案例
- 【待補作者案例】一個課堂上學員從工具焦慮轉向流程理解的真實案例
- 【待補作者案例】一個企業導入中因責任不清而失敗或修正的匿名案例
- 出版社、版權頁、推薦序與最終封面文案
