# CHANGELOG

## V1.0｜2026-08-08

- 鎖定書名《站在迴路之上》與副標「當 Agent 開始工作，人如何重新設計 AI、組織與自己的位置」。
- 將《AI未來已來》定位為管理與組織對話來源，而非全書母體。
- 完成四部、12 章、結語與 5 份附錄。
- 納入 Context、Harness、Runtime、Loop Engineering、Tracing、Evals、Guardrails、Runtime Data-Quality Gating、Evidence Ledger、AI OS 與 DRI＋Agents。
- 正式定義三個作者整合框架：七環工作迴路、雙閘門證據迴路、Human Above the Loop。
- 完成全書 Markdown、全書／分章 DOCX、12 組章節衍生內容、全書課程與演講衍生內容。
- 全書中文字實測 87081；12 章正文 76051。
- 全書 DOCX 261 頁，完成逐頁 render、視覺檢查、a11y 與結構稽核。
- 完成 12 份分章 ZIP、完整 ZIP、交付清單、SHA-256 與雙重解壓／雜湊驗證。
