# 第 8 章交付說明

- 章名：看得見才改得動：Tracing、Evals 與可觀測性
- 正式內容來源：`chapter_08_main.md`
- 章節唯一任務：把 Agent 的品質、成本、風險與學習轉成可重複測量與改進的訊號。
- 核心問題：Agent 錯了之後，如何從猜測變成可定位、可重現、可修正？
- 核心答案：要連結 logs、traces、metrics、trials、graders 與真實 outcomes，並同時評估結果、過程與邊界。
- 本章模型：Agent 可觀測四訊號
- 與下一章關係：第 9 章處理模型看不見的資料品質缺陷。

## 檔案

- `chapter_08_main.md`：正式 Markdown 章稿
- `chapter_08_main.docx`：由正式 Markdown 產生的閱讀版
- `chapter_08_speech_notes.md`：演講筆記
- `chapter_08_slide_outline.md`：簡報大綱
- `chapter_08_quotes.md`：章末金句
- `chapter_08_model_canvas.md`：本章模型畫布

所有修改應先更新 `chapter_08_main.md`，再重新產生 DOCX 與衍生內容。
