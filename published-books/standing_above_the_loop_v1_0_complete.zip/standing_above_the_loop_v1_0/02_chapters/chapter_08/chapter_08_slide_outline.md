# 第 8 章簡報大綱｜看得見才改得動：Tracing、Evals 與可觀測性

## Slide 1｜第 8 章｜看得見才改得動：Tracing、Evals 與可觀測性

Agent 錯了之後，如何從猜測變成可定位、可重現、可修正？

## Slide 2｜讀者原本的理解

只看最後輸出或一次漂亮示範。

## Slide 3｜問題重新定義

把 Agent 的品質、成本、風險與學習轉成可重複測量與改進的訊號。

## Slide 4｜核心答案

要連結 logs、traces、metrics、trials、graders 與真實 outcomes，並同時評估結果、過程與邊界。

## Slide 5｜Agent 可觀測四訊號

Logs、Traces、Metrics、Outcomes

## Slide 6｜系統架構

把本章模型放入 Goal → Context → Action → Evidence → Human Responsibility 的全書主線。

## Slide 7｜常見失敗

挑選正文中三個最具代表性的錯誤，不用功能清單代替論點。

## Slide 8｜假設情境

用一個低風險與一個高影響情境比較自動化邊界。

## Slide 9｜進階治理

可觀測性架構：在看得見、付得起與守得住之間取捨

## Slide 10｜現場練習

讓聽眾用自己的工作填入本章模型。

## Slide 11｜帶走的一句話

最危險的不是 Agent 失敗，而是失敗之後只能靠猜。

## Slide 12｜下一章

第 9 章處理模型看不見的資料品質缺陷。

