# 第 1 章交付說明

- 章名：AI 不再只回答：從 Chatbot 到 Agent
- 正式內容來源：`chapter_01_main.md`
- 章節唯一任務：建立 Chatbot、Copilot、Workflow 與 Agent 的責任差異，避免把工具呼叫誤認為工作完成。
- 核心問題：AI 從回答走向行動後，真正新增的是什麼責任？
- 核心答案：Agent 的分水嶺不是文字更好，而是能在環境中根據目標採取行動；因此必須同時設計完成條件、資料、工具、權限、停止與責任。
- 本章模型：Agent 自主性六面向
- 與下一章關係：第 2 章把行動單位從 Task 推進到 Workflow 與 Outcome。

## 檔案

- `chapter_01_main.md`：正式 Markdown 章稿
- `chapter_01_main.docx`：由正式 Markdown 產生的閱讀版
- `chapter_01_speech_notes.md`：演講筆記
- `chapter_01_slide_outline.md`：簡報大綱
- `chapter_01_quotes.md`：章末金句
- `chapter_01_model_canvas.md`：本章模型畫布

所有修改應先更新 `chapter_01_main.md`，再重新產生 DOCX 與衍生內容。
