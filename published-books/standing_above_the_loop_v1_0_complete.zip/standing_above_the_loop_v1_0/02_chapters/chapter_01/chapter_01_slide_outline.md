# 第 1 章簡報大綱｜AI 不再只回答：從 Chatbot 到 Agent

## Slide 1｜第 1 章｜AI 不再只回答：從 Chatbot 到 Agent

AI 從回答走向行動後，真正新增的是什麼責任？

## Slide 2｜讀者原本的理解

把 AI 視為回答器或生成器。

## Slide 3｜問題重新定義

建立 Chatbot、Copilot、Workflow 與 Agent 的責任差異，避免把工具呼叫誤認為工作完成。

## Slide 4｜核心答案

Agent 的分水嶺不是文字更好，而是能在環境中根據目標採取行動；因此必須同時設計完成條件、資料、工具、權限、停止與責任。

## Slide 5｜Agent 自主性六面向

目標自主、規劃自主、資料自主、工具自主、影響自主、停止自主

## Slide 6｜系統架構

把本章模型放入 Goal → Context → Action → Evidence → Human Responsibility 的全書主線。

## Slide 7｜常見失敗

挑選正文中三個最具代表性的錯誤，不用功能清單代替論點。

## Slide 8｜假設情境

用一個低風險與一個高影響情境比較自動化邊界。

## Slide 9｜進階治理

用三軸決定自主性：影響、可逆性與不確定性

## Slide 10｜現場練習

讓聽眾用自己的工作填入本章模型。

## Slide 11｜帶走的一句話

從 Chatbot 到 Agent，真正改變的不是介面，而是動詞：從問問題走向交辦工作。

## Slide 12｜下一章

第 2 章把行動單位從 Task 推進到 Workflow 與 Outcome。

