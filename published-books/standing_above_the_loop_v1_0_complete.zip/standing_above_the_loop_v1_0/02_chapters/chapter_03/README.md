# 第 3 章交付說明

- 章名：智能變便宜，工作為什麼沒有自動變好
- 正式內容來源：`chapter_03_main.md`
- 章節唯一任務：拆解 Token 成本、總工作成本、生產力與組織瓶頸的差異。
- 核心問題：模型與生成愈便宜，為什麼企業成本與工作複雜度可能仍然上升？
- 核心答案：更便宜的生成會增加使用量並把稀缺轉移到選擇、驗證、脈絡、維護與責任；只有重設 Outcome 與流程，速度才會轉化成生產力。
- 本章模型：AI 工作總成本
- 與下一章關係：第 4 章開始建立 Agent 的工作現場，先處理 Context。

## 檔案

- `chapter_03_main.md`：正式 Markdown 章稿
- `chapter_03_main.docx`：由正式 Markdown 產生的閱讀版
- `chapter_03_speech_notes.md`：演講筆記
- `chapter_03_slide_outline.md`：簡報大綱
- `chapter_03_quotes.md`：章末金句
- `chapter_03_model_canvas.md`：本章模型畫布

所有修改應先更新 `chapter_03_main.md`，再重新產生 DOCX 與衍生內容。
