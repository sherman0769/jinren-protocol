# 第 11 章交付說明

- 章名：AI 原生組織：從一號位工程、AI OS 到 DRI＋Agents
- 正式內容來源：`chapter_11_main.md`
- 章節唯一任務：把企業 AI 從工具與 PoC 集合，提升為共同資料、Runtime、證據、責任與 Outcome 作業層。
- 核心問題：公司裡到處都有 AI，為什麼仍不算 AI 原生組織？
- 核心答案：AI 原生需要一號位方向、共同 Ontology、Context、Tools、Runtime、Evidence、Observability 與 DRI 責任，不只是工具覆蓋。
- 本章模型：AI OS 八層
- 與下一章關係：第 12 章回到人的八個上位責任。

## 檔案

- `chapter_11_main.md`：正式 Markdown 章稿
- `chapter_11_main.docx`：由正式 Markdown 產生的閱讀版
- `chapter_11_speech_notes.md`：演講筆記
- `chapter_11_slide_outline.md`：簡報大綱
- `chapter_11_quotes.md`：章末金句
- `chapter_11_model_canvas.md`：本章模型畫布

所有修改應先更新 `chapter_11_main.md`，再重新產生 DOCX 與衍生內容。
