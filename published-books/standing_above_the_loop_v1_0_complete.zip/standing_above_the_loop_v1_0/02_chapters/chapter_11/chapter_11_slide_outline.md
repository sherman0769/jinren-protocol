# 第 11 章簡報大綱｜AI 原生組織：從一號位工程、AI OS 到 DRI＋Agents

## Slide 1｜第 11 章｜AI 原生組織：從一號位工程、AI OS 到 DRI＋Agents

公司裡到處都有 AI，為什麼仍不算 AI 原生組織？

## Slide 2｜讀者原本的理解

以使用人數、PoC 與 Agent 數量衡量轉型。

## Slide 3｜問題重新定義

把企業 AI 從工具與 PoC 集合，提升為共同資料、Runtime、證據、責任與 Outcome 作業層。

## Slide 4｜核心答案

AI 原生需要一號位方向、共同 Ontology、Context、Tools、Runtime、Evidence、Observability 與 DRI 責任，不只是工具覆蓋。

## Slide 5｜AI OS 八層

Model、Ontology/Data、Context、Tool/Interoperability、Harness/Runtime、Evidence/Quality、Observability/Improvement、Governance/Responsibility

## Slide 6｜系統架構

把本章模型放入 Goal → Context → Action → Evidence → Human Responsibility 的全書主線。

## Slide 7｜常見失敗

挑選正文中三個最具代表性的錯誤，不用功能清單代替論點。

## Slide 8｜假設情境

用一個低風險與一個高影響情境比較自動化邊界。

## Slide 9｜進階治理

組織改造的難題不在工具，而在誘因、身份與參與方式

## Slide 10｜現場練習

讓聽眾用自己的工作填入本章模型。

## Slide 11｜帶走的一句話

公司裡到處都有 AI，不代表公司已經成為 AI 原生組織。

## Slide 12｜下一章

第 12 章回到人的八個上位責任。

