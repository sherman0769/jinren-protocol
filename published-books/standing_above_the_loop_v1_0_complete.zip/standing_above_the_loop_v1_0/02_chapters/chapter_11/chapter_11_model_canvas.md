# 第 11 章模型畫布｜AI OS 八層

## 一句話定義

AI 原生需要一號位方向、共同 Ontology、Context、Tools、Runtime、Evidence、Observability 與 DRI 責任，不只是工具覆蓋。

## 要解決的問題

公司裡到處都有 AI，為什麼仍不算 AI 原生組織？

## 核心構成

1. **Model**：請依本章正文，寫入此項在你的工作中代表的責任、資料、機制與負責人。
2. **Ontology/Data**：請依本章正文，寫入此項在你的工作中代表的責任、資料、機制與負責人。
3. **Context**：請依本章正文，寫入此項在你的工作中代表的責任、資料、機制與負責人。
4. **Tool/Interoperability**：請依本章正文，寫入此項在你的工作中代表的責任、資料、機制與負責人。
5. **Harness/Runtime**：請依本章正文，寫入此項在你的工作中代表的責任、資料、機制與負責人。
6. **Evidence/Quality**：請依本章正文，寫入此項在你的工作中代表的責任、資料、機制與負責人。
7. **Observability/Improvement**：請依本章正文，寫入此項在你的工作中代表的責任、資料、機制與負責人。
8. **Governance/Responsibility**：請依本章正文，寫入此項在你的工作中代表的責任、資料、機制與負責人。

## 實作欄位

- 使用情境：
- 核心 Outcome：
- 目前最弱的一項：
- 風險最高的一項：
- 可在七天內改善的一項：
- DRI／責任人：
- 驗證證據：
- 停止或升級條件：

## 適用範圍

適合用於需要把本章觀念轉成工作規格、課程練習或團隊共識的情境。簡單任務可縮減，不應為了套模型而增加不必要流程。

## 不適用範圍

不把本畫布當成產業標準、法律責任判定或單一產品操作手冊；高風險領域仍需專業、法規與組織治理。

## 圖解方式

以中央標示「AI OS 八層」，四周依序排列：Model → Ontology/Data → Context → Tool/Interoperability → Harness/Runtime → Evidence/Quality → Observability/Improvement → Governance/Responsibility。用箭頭標出資料、行動、證據與人工責任的流向。

## 演講說法

讀者閱讀前：以使用人數、PoC 與 Agent 數量衡量轉型。  
讀者閱讀後：能用 AI OS 八層、DRI＋Agents 責任包與成熟階梯規劃組織。
