# 第 12 章交付說明

- 章名：人站在迴路之上：Human Above the Loop
- 正式內容來源：`chapter_12_main.md`
- 章節唯一任務：重新定義人在高自主 Agent 系統中的目的、邊界、觀察、判斷與責任。
- 核心問題：當 AI 開始自己做事，人真正不可外包的工作是什麼？
- 核心答案：人可以離開重複步驟，但必須負責定義、設計、設界、觀測、驗證、介入、判斷與承擔後果。
- 本章模型：Human Above the Loop 八責任
- 與下一章關係：結語與附錄把思想轉成畫布、檢查表與 30 天行動。

## 檔案

- `chapter_12_main.md`：正式 Markdown 章稿
- `chapter_12_main.docx`：由正式 Markdown 產生的閱讀版
- `chapter_12_speech_notes.md`：演講筆記
- `chapter_12_slide_outline.md`：簡報大綱
- `chapter_12_quotes.md`：章末金句
- `chapter_12_model_canvas.md`：本章模型畫布

所有修改應先更新 `chapter_12_main.md`，再重新產生 DOCX 與衍生內容。
