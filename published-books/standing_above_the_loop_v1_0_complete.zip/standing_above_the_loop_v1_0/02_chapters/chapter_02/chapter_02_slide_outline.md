# 第 2 章簡報大綱｜從 Task 到 Workflow，再到 Outcome

## Slide 1｜第 2 章｜從 Task 到 Workflow，再到 Outcome

做了很多 AI 功能，為什麼仍沒有真正改善工作？

## Slide 2｜讀者原本的理解

用產出量與步驟自動化衡量 AI。

## Slide 3｜問題重新定義

把 AI 導入從單點功能移向可驗收結果與責任包。

## Slide 4｜核心答案

Task 只交出動作，Workflow 交出流程，Outcome 才定義真實世界的完成、品質、邊界與證據。

## Slide 5｜Outcome Contract 八問

目標、使用者、完成條件、禁止條件、證據、停止、核准、回寫

## Slide 6｜系統架構

把本章模型放入 Goal → Context → Action → Evidence → Human Responsibility 的全書主線。

## Slide 7｜常見失敗

挑選正文中三個最具代表性的錯誤，不用功能清單代替論點。

## Slide 8｜假設情境

用一個低風險與一個高影響情境比較自動化邊界。

## Slide 9｜進階治理

Outcome 的反指標：別讓漂亮數字把工作帶往錯誤方向

## Slide 10｜現場練習

讓聽眾用自己的工作填入本章模型。

## Slide 11｜帶走的一句話

Task 把一個動作交出去，Workflow 把一段流程交出去，Outcome 才把可驗收結果說清楚。

## Slide 12｜下一章

第 3 章檢查智能成本下降，為什麼不等於總工作成本下降。

