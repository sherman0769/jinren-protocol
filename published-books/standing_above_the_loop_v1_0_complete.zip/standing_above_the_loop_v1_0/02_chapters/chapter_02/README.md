# 第 2 章交付說明

- 章名：從 Task 到 Workflow，再到 Outcome
- 正式內容來源：`chapter_02_main.md`
- 章節唯一任務：把 AI 導入從單點功能移向可驗收結果與責任包。
- 核心問題：做了很多 AI 功能，為什麼仍沒有真正改善工作？
- 核心答案：Task 只交出動作，Workflow 交出流程，Outcome 才定義真實世界的完成、品質、邊界與證據。
- 本章模型：Outcome Contract 八問
- 與下一章關係：第 3 章檢查智能成本下降，為什麼不等於總工作成本下降。

## 檔案

- `chapter_02_main.md`：正式 Markdown 章稿
- `chapter_02_main.docx`：由正式 Markdown 產生的閱讀版
- `chapter_02_speech_notes.md`：演講筆記
- `chapter_02_slide_outline.md`：簡報大綱
- `chapter_02_quotes.md`：章末金句
- `chapter_02_model_canvas.md`：本章模型畫布

所有修改應先更新 `chapter_02_main.md`，再重新產生 DOCX 與衍生內容。
