# 第 10 章簡報大綱｜主張釋出前要有帳：Evidence Ledger、Guardrails 與人工審查

## Slide 1｜第 10 章｜主張釋出前要有帳：Evidence Ledger、Guardrails 與人工審查

有來源的 AI 內容，為什麼仍可能不可信？

## Slide 2｜讀者原本的理解

把連結數量、模型信心或最後人工按鈕當成可信。

## Slide 3｜問題重新定義

建立主張—證據—關係—審查路由，避免引用很多卻無法支持結論。

## Slide 4｜核心答案

來源可用不等於支持主張；必須拆解 claim、建立 evidence packet、判定 supports/contradicts/mixed/insufficient，並以 Guardrails 與 Human Review 控制釋出。

## Slide 5｜雙閘門證據迴路

行動前資料品質閘門、Agent 分析／生成、主張原子化、證據關係判定、Guardrails、人工審查、證據帳本

## Slide 6｜系統架構

把本章模型放入 Goal → Context → Action → Evidence → Human Responsibility 的全書主線。

## Slide 7｜常見失敗

挑選正文中三個最具代表性的錯誤，不用功能清單代替論點。

## Slide 8｜假設情境

用一個低風險與一個高影響情境比較自動化邊界。

## Slide 9｜進階治理

更正如何沿證據鏈傳播：可信系統也要能承認自己曾經錯過

## Slide 10｜現場練習

讓聽眾用自己的工作填入本章模型。

## Slide 11｜帶走的一句話

有來源，不代表來源真的支持你的話。

## Slide 12｜下一章

第 11 章把系統能力接回 AI OS、DRI 與企業組織。

