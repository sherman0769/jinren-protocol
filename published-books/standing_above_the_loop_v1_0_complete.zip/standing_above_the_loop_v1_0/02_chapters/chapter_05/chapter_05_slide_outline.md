# 第 5 章簡報大綱｜Harness Engineering：模型之外的工作契約

## Slide 1｜第 5 章｜Harness Engineering：模型之外的工作契約

模型已經很強，為什麼 Agent 系統仍常在工具、權限與交付上失敗？

## Slide 2｜讀者原本的理解

遇到失敗只會加長 Prompt 或更換模型。

## Slide 3｜問題重新定義

定義模型之外如何以工具、權限、驗證與停止條件把能力變成可用工作。

## Slide 4｜核心答案

失敗常在模型之外；Harness 必須把指令、工具、路由、輸出、驗證、權限、預算、停止與學習變成可測試契約。

## Slide 5｜Harness 九元件

指令、工具、路由、輸出、驗證、權限、預算時間、停止升級、版本學習

## Slide 6｜系統架構

把本章模型放入 Goal → Context → Action → Evidence → Human Responsibility 的全書主線。

## Slide 7｜常見失敗

挑選正文中三個最具代表性的錯誤，不用功能清單代替論點。

## Slide 8｜假設情境

用一個低風險與一個高影響情境比較自動化邊界。

## Slide 9｜進階治理

Harness 變更治理：每一條規則都應有理由、擁有者與退路

## Slide 10｜現場練習

讓聽眾用自己的工作填入本章模型。

## Slide 11｜帶走的一句話

模型能力很強，不代表模型之外的工作契約已經完整。

## Slide 12｜下一章

第 6 章把 Harness 放進真正執行、保存與恢復的 Runtime。

