# 第 5 章交付說明

- 章名：Harness Engineering：模型之外的工作契約
- 正式內容來源：`chapter_05_main.md`
- 章節唯一任務：定義模型之外如何以工具、權限、驗證與停止條件把能力變成可用工作。
- 核心問題：模型已經很強，為什麼 Agent 系統仍常在工具、權限與交付上失敗？
- 核心答案：失敗常在模型之外；Harness 必須把指令、工具、路由、輸出、驗證、權限、預算、停止與學習變成可測試契約。
- 本章模型：Harness 九元件
- 與下一章關係：第 6 章把 Harness 放進真正執行、保存與恢復的 Runtime。

## 檔案

- `chapter_05_main.md`：正式 Markdown 章稿
- `chapter_05_main.docx`：由正式 Markdown 產生的閱讀版
- `chapter_05_speech_notes.md`：演講筆記
- `chapter_05_slide_outline.md`：簡報大綱
- `chapter_05_quotes.md`：章末金句
- `chapter_05_model_canvas.md`：本章模型畫布

所有修改應先更新 `chapter_05_main.md`，再重新產生 DOCX 與衍生內容。
