# 第 4 章交付說明

- 章名：Context Engineering：AI 所處的世界
- 正式內容來源：`chapter_04_main.md`
- 章節唯一任務：讓讀者理解 Context 是策展出的工作世界，而非無限制堆疊資料。
- 核心問題：同一句 Prompt 為什麼在不同工作環境中會產生完全不同結果？
- 核心答案：模型只能根據被提供的世界行動；必須以最小必要 Context 管理正式來源、狀態、工具、限制、記憶與交接。
- 本章模型：Context 五層結構
- 與下一章關係：第 5 章把 Context 放進模型之外的工作契約 Harness。

## 檔案

- `chapter_04_main.md`：正式 Markdown 章稿
- `chapter_04_main.docx`：由正式 Markdown 產生的閱讀版
- `chapter_04_speech_notes.md`：演講筆記
- `chapter_04_slide_outline.md`：簡報大綱
- `chapter_04_quotes.md`：章末金句
- `chapter_04_model_canvas.md`：本章模型畫布

所有修改應先更新 `chapter_04_main.md`，再重新產生 DOCX 與衍生內容。
