# 第 4 章簡報大綱｜Context Engineering：AI 所處的世界

## Slide 1｜第 4 章｜Context Engineering：AI 所處的世界

同一句 Prompt 為什麼在不同工作環境中會產生完全不同結果？

## Slide 2｜讀者原本的理解

把 Context 當成聊天紀錄或知識庫附件。

## Slide 3｜問題重新定義

讓讀者理解 Context 是策展出的工作世界，而非無限制堆疊資料。

## Slide 4｜核心答案

模型只能根據被提供的世界行動；必須以最小必要 Context 管理正式來源、狀態、工具、限制、記憶與交接。

## Slide 5｜Context 五層結構

長期憲法、專案世界、任務包、執行狀態、交接摘要

## Slide 6｜系統架構

把本章模型放入 Goal → Context → Action → Evidence → Human Responsibility 的全書主線。

## Slide 7｜常見失敗

挑選正文中三個最具代表性的錯誤，不用功能清單代替論點。

## Slide 8｜假設情境

用一個低風險與一個高影響情境比較自動化邊界。

## Slide 9｜進階治理

Context Security：當外部內容試圖改寫 Agent 的工作世界

## Slide 10｜現場練習

讓聽眾用自己的工作填入本章模型。

## Slide 11｜帶走的一句話

Prompt 是你說的話，Context 是 AI 所處的世界。

## Slide 12｜下一章

第 5 章把 Context 放進模型之外的工作契約 Harness。

