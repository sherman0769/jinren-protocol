# 第 9 章簡報大綱｜行動前先過閘門：Runtime Data-Quality Gating

## Slide 1｜第 9 章｜行動前先過閘門：Runtime Data-Quality Gating

模型推理很好，為什麼仍可能在錯誤資料上自信行動？

## Slide 2｜讀者原本的理解

把資料品質等同空值、錯字或模型自己判斷。

## Slide 3｜問題重新定義

讓高影響行動在資料未達最低證據條件時自動停止、補充或升級。

## Slide 4｜核心答案

許多缺陷藏在 freshness、lineage、schema、authority 與 metadata；必須由 Runtime 在行動路徑上執行確定性與語意品質閘門。

## Slide 5｜資料品質八維

Freshness、Lineage、Schema、Consistency、Completeness、Authority、Integrity、Scope

## Slide 6｜系統架構

把本章模型放入 Goal → Context → Action → Evidence → Human Responsibility 的全書主線。

## Slide 7｜常見失敗

挑選正文中三個最具代表性的錯誤，不用功能清單代替論點。

## Slide 8｜假設情境

用一個低風險與一個高影響情境比較自動化邊界。

## Slide 9｜進階治理

讓資料閘門安全上線：影子、金絲雀與分層放行

## Slide 10｜現場練習

讓聽眾用自己的工作填入本章模型。

## Slide 11｜帶走的一句話

模型可能完全不知道，眼前內容正確的資料已經不能用了。

## Slide 12｜下一章

第 10 章把輸入品質接到輸出主張與證據關係。

