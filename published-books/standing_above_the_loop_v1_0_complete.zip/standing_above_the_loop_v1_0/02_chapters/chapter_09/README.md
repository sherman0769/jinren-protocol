# 第 9 章交付說明

- 章名：行動前先過閘門：Runtime Data-Quality Gating
- 正式內容來源：`chapter_09_main.md`
- 章節唯一任務：讓高影響行動在資料未達最低證據條件時自動停止、補充或升級。
- 核心問題：模型推理很好，為什麼仍可能在錯誤資料上自信行動？
- 核心答案：許多缺陷藏在 freshness、lineage、schema、authority 與 metadata；必須由 Runtime 在行動路徑上執行確定性與語意品質閘門。
- 本章模型：資料品質八維
- 與下一章關係：第 10 章把輸入品質接到輸出主張與證據關係。

## 檔案

- `chapter_09_main.md`：正式 Markdown 章稿
- `chapter_09_main.docx`：由正式 Markdown 產生的閱讀版
- `chapter_09_speech_notes.md`：演講筆記
- `chapter_09_slide_outline.md`：簡報大綱
- `chapter_09_quotes.md`：章末金句
- `chapter_09_model_canvas.md`：本章模型畫布

所有修改應先更新 `chapter_09_main.md`，再重新產生 DOCX 與衍生內容。
