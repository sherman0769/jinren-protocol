# 第 6 章簡報大綱｜Runtime：讓 AI 能持續工作的現場

## Slide 1｜第 6 章｜Runtime：讓 AI 能持續工作的現場

Agent 如何跨時間、工具、人員與失敗持續完成工作？

## Slide 2｜讀者原本的理解

把 Agent 的連續性理解成一個很長的聊天視窗。

## Slide 3｜問題重新定義

把短暫模型呼叫提升為可保存狀態、可恢復、可治理的長任務執行。

## Slide 4｜核心答案

Runtime 要管理任務身份、狀態、checkpoint、工具、沙箱、秘密、事件、併發、成本、人工介入、觀測與回寫。

## Slide 5｜Runtime 十二能力

任務身份、狀態、Checkpoint、工具執行、隔離、秘密身份、事件佇列、併發鎖定、成本資源、人工介入、可觀測性、成果回寫

## Slide 6｜系統架構

把本章模型放入 Goal → Context → Action → Evidence → Human Responsibility 的全書主線。

## Slide 7｜常見失敗

挑選正文中三個最具代表性的錯誤，不用功能清單代替論點。

## Slide 8｜假設情境

用一個低風險與一個高影響情境比較自動化邊界。

## Slide 9｜進階治理

災難恢復與營運持續：Agent 停下來時，工作不能一起消失

## Slide 10｜現場練習

讓聽眾用自己的工作填入本章模型。

## Slide 11｜帶走的一句話

回答發生在對話裡，工作發生在 Runtime 裡。

## Slide 12｜下一章

第 7 章讓 Runtime 不只重複執行，而能形成改善 Loop。

