# 第 6 章交付說明

- 章名：Runtime：讓 AI 能持續工作的現場
- 正式內容來源：`chapter_06_main.md`
- 章節唯一任務：把短暫模型呼叫提升為可保存狀態、可恢復、可治理的長任務執行。
- 核心問題：Agent 如何跨時間、工具、人員與失敗持續完成工作？
- 核心答案：Runtime 要管理任務身份、狀態、checkpoint、工具、沙箱、秘密、事件、併發、成本、人工介入、觀測與回寫。
- 本章模型：Runtime 十二能力
- 與下一章關係：第 7 章讓 Runtime 不只重複執行，而能形成改善 Loop。

## 檔案

- `chapter_06_main.md`：正式 Markdown 章稿
- `chapter_06_main.docx`：由正式 Markdown 產生的閱讀版
- `chapter_06_speech_notes.md`：演講筆記
- `chapter_06_slide_outline.md`：簡報大綱
- `chapter_06_quotes.md`：章末金句
- `chapter_06_model_canvas.md`：本章模型畫布

所有修改應先更新 `chapter_06_main.md`，再重新產生 DOCX 與衍生內容。
