# 第 7 章交付說明

- 章名：Loop Engineering：從一次成功到持續改善
- 正式內容來源：`chapter_07_main.md`
- 章節唯一任務：建立可重複、可驗證、可回饋、可監督與可交接的 AI 工作循環。
- 核心問題：如何把一次 Agent 成功，變成能在變化中持續改善的系統？
- 核心答案：迴路必須把目標、脈絡、工具、驗證、回饋、監督與交接連起來，並有停止條件與回寫。
- 本章模型：七環工作迴路
- 與下一章關係：第 8 章用 Tracing、Evals 與 Observability 看見迴路是否真的改善。

## 檔案

- `chapter_07_main.md`：正式 Markdown 章稿
- `chapter_07_main.docx`：由正式 Markdown 產生的閱讀版
- `chapter_07_speech_notes.md`：演講筆記
- `chapter_07_slide_outline.md`：簡報大綱
- `chapter_07_quotes.md`：章末金句
- `chapter_07_model_canvas.md`：本章模型畫布

所有修改應先更新 `chapter_07_main.md`，再重新產生 DOCX 與衍生內容。
