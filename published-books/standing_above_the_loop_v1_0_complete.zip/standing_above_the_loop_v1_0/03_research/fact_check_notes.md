# Fact Check Notes

## 已校正

- 「Agent」不等同「完全自主」；本書依 Anthropic 區分 workflow 與動態決定步驟的 agentic system。
- MCP 於 2026-07-28 版本採 stateless protocol core；舊版的 session／initialize 描述不得當成最新現況。
- MCP 是 Context／Tools 交換協定，不是完整 Agent Runtime、記憶或治理框架。
- A2A 由 Linux Foundation 託管，目標是獨立 Agent 系統的互通；互通不代表信任。
- Loop Engineering 不是成熟學術標準。本書明確標示其為新興產業語言與作者整合框架。
- Human Above the Loop、七環工作迴路、雙閘門證據迴路均為本書工作概念，不冒充既有標準。
- SARC-DQ 與 Evidence-Ledger 均為 2026 年 7 月預印本；實驗結果不可直接外推所有產業。
- Palantir Ontology 與零一萬物「一號位工程」屬企業官方方法與產品敘事，使用時保留來源立場。

## 出版前應重新查證

- OpenAI Agents SDK 最新 API 與產品名稱
- MCP 最新規格版本與 deprecated features
- A2A 最新正式規格與 SDK 狀態
- SARC-DQ、Evidence-Ledger 是否有後續版本、同儕審查或勘誤
- 台灣、歐盟、美國、中國大陸與其他地區的 AI 法規更新
- 《AI未來已來》正式紙本版權頁、頁數與目錄資訊
