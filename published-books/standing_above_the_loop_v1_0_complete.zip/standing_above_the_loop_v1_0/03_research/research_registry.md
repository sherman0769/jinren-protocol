# Research Registry｜研究來源登錄

- 查閱日期：2026-08-08
- 用途：校準《站在迴路之上》中的技術、研究、組織與治理敘述
- 原則：正文只保留必要的 `[Rxx]` 標記；本表記錄來源、日期、支持章節、限制與更新需求。

## R01｜李開復《AI未來已來》微信讀書正式條目

- 來源：微信讀書
- 書名：《AI未來已來：CEO、組織、個人的時代紅利（微信讀書特別版）》
- 作者：李開復
- 日期：2026-07-25（條目顯示日期）
- URL：https://weread.qq.com/web/reader/9dc32090813abbbd7g0178b5
- 支持章節：導讀、3、11、12
- 支持觀點：該書將 AI 視為正在改變企業成本、決策、組織與個人行動的力量。
- 限制：本專案未取得可合法重製的全書檔案；不引用或改寫受著作權保護的長段文字，只以正式書目與公開方法論進行思想對話。

## R02｜零一萬物「一號位工程」

- 來源：零一萬物官方網站
- 日期：2026（頁面未標明精確發布日；查閱日 2026-08-08）
- URL：https://www.lingyiwanwu.com/top-down.html
- 支持章節：導讀、3、11
- 支持觀點：CEO／CAIO 直接負責、以財務與營運結果定義成功；企業 AI 決策中樞由模型、Ontology 2.0、即時脈絡與作業系統組成；老闆 AI 與 DRI 重新組織責任。
- 限制：屬企業自身方法論與產品敘事，不能視為中立產業標準；案例成效需另行查核。

## R03｜OpenAI Agents SDK Overview

- 來源：OpenAI 官方 Agents SDK 文件
- 日期：持續更新；查閱日 2026-08-08
- URL：https://openai.github.io/openai-agents-python/
- 支持章節：1、2、5、6、8、10
- 支持觀點：Agent SDK 提供工具、交接、sessions、human-in-the-loop 與 tracing；SDK 是模型呼叫之上的高階 runtime。
- 限制：產品與 SDK 介面會更新，出版前應重新查閱。

## R04｜OpenAI Guardrails and Human Review

- 來源：OpenAI 官方 API 文件
- 日期：持續更新；查閱日 2026-08-08
- URL：https://developers.openai.com/api/docs/guides/agents/guardrails-approvals
- 支持章節：8、10、12
- 支持觀點：Guardrails 可自動驗證輸入、輸出或工具行為；人工審查可暫停流程並核准或拒絕敏感行動。
- 限制：文件描述 OpenAI 生態的實作，不代表唯一治理方式。

## R05｜OpenAI Tracing

- 來源：OpenAI 官方 Agents SDK 文件
- 日期：持續更新；查閱日 2026-08-08
- URL：https://openai.github.io/openai-agents-python/tracing/
- 支持章節：6、8
- 支持觀點：Tracing 可記錄模型生成、工具呼叫、handoffs、guardrails 與自訂事件，用於開發與正式環境的除錯、視覺化與監控。
- 限制：Trace 本身不等於證據正確，也不代表已完成治理。

## R06｜OpenAI Evaluate Agent Workflows

- 來源：OpenAI 官方 API 文件
- 日期：持續更新；查閱日 2026-08-08
- URL：https://developers.openai.com/api/docs/guides/agent-evals
- 支持章節：7、8、10
- 支持觀點：可用 traces、graders、datasets 與 eval runs 持續改善 Agent 品質。
- 限制：評分器品質、資料集代表性與人類校準仍是必要條件。

## R07｜OpenAI Harness Engineering

- 來源：OpenAI 官方文章
- 日期：2026-02-11
- URL：https://openai.com/index/harness-engineering/
- 支持章節：5、7、12
- 支持觀點：當 Agent 失敗時，團隊可把缺少的工具、防護欄、文件與驗證回寫到環境；人仍在迴路裡，但工作位於更高抽象層。
- 限制：屬 OpenAI 內部工程經驗，不能直接外推所有產業。

## R08｜OpenAI Unrolling the Codex Agent Loop

- 來源：OpenAI 官方文章
- 日期：2026-01-23
- URL：https://openai.com/index/unrolling-the-codex-agent-loop/
- 支持章節：4、5、6、7
- 支持觀點：Agent loop 涉及脈絡策展、模型呼叫、工具輸出、狀態與下一輪決策。
- 限制：以 Codex 類場景為主；非所有 Agent 都採相同迴路。

## R09｜Anthropic Building Effective Agents

- 來源：Anthropic 官方工程文章
- 日期：2024-12-19
- URL：https://www.anthropic.com/engineering/building-effective-agents
- 支持章節：1、2、6、7、11
- 支持觀點：應區分預先編排的 workflows 與由模型動態決定步驟的 agents；從最簡單可行方法開始，只有在需要時增加複雜度。
- 限制：屬工程建議，不是正式標準。

## R10｜Anthropic Effective Context Engineering for AI Agents

- 來源：Anthropic 官方工程文章
- 日期：2025-09-29
- URL：https://www.anthropic.com/engineering/effective-context-engineering-for-ai-agents
- 支持章節：4、6、7、11
- 支持觀點：Context 是有限資源；Context Engineering 是在推論時策展與維護最佳資訊集合；長任務可採 compaction、結構化筆記與子 Agent。
- 限制：部分產品能力與範例會隨 Claude 平台更新。

## R11｜Anthropic Writing Effective Tools for Agents

- 來源：Anthropic 官方工程文章
- 日期：2025-09-11
- URL：https://www.anthropic.com/engineering/writing-tools-for-agents
- 支持章節：4、5、7、8
- 支持觀點：工具是確定性系統與非確定性 Agent 的契約；工具要有清楚邊界、可驗證輸入輸出、高訊號回傳與評測。
- 限制：工具設計需依任務、模型與風險調整。

## R12｜Anthropic Demystifying Evals for AI Agents

- 來源：Anthropic 官方工程文章
- 日期：2026-01-09
- URL：https://www.anthropic.com/engineering/demystifying-evals-for-ai-agents
- 支持章節：8、10、11
- 支持觀點：Agent eval 要區分 task、trial、grader、transcript／trace、outcome、evaluation harness 與 agent harness；多次試驗與結果狀態比單次文字輸出更重要。
- 限制：Evals 不能完全取代正式環境監測與人工測試。

## R13｜Anthropic Multi-Agent Research System

- 來源：Anthropic 官方工程文章
- 日期：2025-06-13
- URL：https://www.anthropic.com/engineering/multi-agent-research-system
- 支持章節：4、6、8、11
- 支持觀點：Orchestrator-worker、平行子 Agent、獨立 Context 與結果壓縮可改善開放式研究，但成本、協調與可靠性更複雜。
- 限制：官方公布的內部評測只適用其系統與任務；本書不把數字外推成普遍效果。

## R14｜Anthropic Harness Design for Long-Running Application Development

- 來源：Anthropic 官方工程文章
- 日期：2026-03-24
- URL：https://www.anthropic.com/engineering/harness-design-long-running-apps
- 支持章節：5、6、7
- 支持觀點：Harness 的元件都隱含對模型能力的假設，必須逐項測試、簡化與隨模型能力更新。
- 限制：以長時間軟體開發為主要情境。

## R15｜Model Context Protocol Specification 2026-07-28

- 來源：MCP 官方規格與架構文件
- 日期：2026-07-28
- URL：https://modelcontextprotocol.io/specification/2026-07-28/architecture
- 支持章節：4、5、6、11
- 支持觀點：MCP 採 host-client-server 架構；2026-07-28 版將協定核心改為 stateless，每個 request 自帶版本與能力資訊；核心用途是脈絡與工具交換。
- 限制：規格更新快速；MCP 不是完整 Runtime、記憶、權限治理或 Agent 組織架構。

## R16｜Agent2Agent Protocol

- 來源：A2A 官方 GitHub／Linux Foundation
- 日期：2025-06-23 起由 Linux Foundation 託管；查閱日 2026-08-08
- URL：https://github.com/a2aproject/A2A
- 支持章節：6、11
- 支持觀點：A2A 是讓獨立、可能不透明的 Agent 系統進行能力發現、溝通與協調的開放協定。
- 限制：規格與 SDK 仍持續演進；互通不等於信任，仍需身份、權限、證據與責任設計。

## R17｜NIST AI RMF 1.0

- 來源：NIST
- 日期：2023-01-26
- URL：https://doi.org/10.6028/NIST.AI.100-1
- 支持章節：8、10、11、12
- 支持觀點：AI 風險管理以 GOVERN、MAP、MEASURE、MANAGE 四項功能組織；治理是跨越全生命週期的活動。
- 限制：自願性框架，需依產業、法規與風險層級落地。

## R18｜NIST Generative AI Profile

- 來源：NIST
- 日期：2024-07-26
- URL：https://doi.org/10.6028/NIST.AI.600-1
- 支持章節：8、10、11、12
- 支持觀點：補充生成式 AI 的風險、評估與管理行動，強調資料、內容完整性、資訊安全、人類監督與持續評估。
- 限制：不是 Agent 專屬框架；需再補 Runtime 與自主行動風險。

## R19｜W3C PROV-O

- 來源：W3C Recommendation
- 日期：2013-04-30
- URL：https://www.w3.org/TR/prov-o/
- 支持章節：9、10
- 支持觀點：提供跨系統表示、交換與整合 provenance 的基礎語彙。
- 限制：PROV-O 提供語意基礎，不直接完成 Agent 證據判決或資料品質閘門。

## R20｜ReAct

- 來源：Yao et al., arXiv／ICLR
- 日期：2022-10-06（預印本）
- URL：https://arxiv.org/abs/2210.03629
- 支持章節：1、6、7
- 支持觀點：將推理軌跡與外部行動交錯，使模型能根據環境觀察更新計畫。
- 限制：研究範例不代表現代產品 Agent 的完整工程架構。

## R21｜Toolformer

- 來源：Schick et al., arXiv
- 日期：2023-02-09
- URL：https://arxiv.org/abs/2302.04761
- 支持章節：1、5、6
- 支持觀點：模型可學習決定何時呼叫 API、使用何種參數，以及如何把結果納入後續預測。
- 限制：研究方法與現代 function calling／Agent Runtime 不完全相同。

## R22｜Reflexion

- 來源：Shinn et al., arXiv／OpenReview
- 日期：2023-03-20
- URL：https://arxiv.org/abs/2303.11366
- 支持章節：7、8
- 支持觀點：可將環境回饋轉為文字反思並寫入 episodic memory，改善下一次嘗試，而不必更新模型權重。
- 限制：自我反思可能產生錯誤解釋，仍需外部評分與驗證。

## R23｜AutoGen

- 來源：Wu et al., arXiv／Microsoft Research
- 日期：2023-08-16
- URL：https://arxiv.org/abs/2308.08155
- 支持章節：6、11
- 支持觀點：可用可對話、可自訂的多 Agent 組合模型、工具與人類輸入。
- 限制：框架證明可組裝，不代表多 Agent 一定優於單 Agent。

## R24｜SARC-DQ

- 來源：Gaston Besanson, arXiv:2607.26313
- 日期：2026-07-28
- URL：https://arxiv.org/abs/2607.26313
- 支持章節：9、10
- 支持觀點：metadata-borne 的 silent evidence defects 可能在模型完全看不到的情況下導致高成本行動；模型能力提升不會自動帶來資料懷疑；pre-action gate 的效果取決於 predicate coverage 與部署位置。
- 限制：預印本、單一作者、特定補貨定價 benchmark；本書僅採其系統軸洞見，不將實驗比例外推所有產業。

## R25｜Evidence-Ledger Adjudication

- 來源：Chen, Yu, Wang, arXiv:2607.26512
- 日期：2026-07-29
- URL：https://arxiv.org/abs/2607.26512
- 支持章節：10
- 支持觀點：將 claim、evidence packet、support relation、confidence、rationale 與 author-review route 連結，可建立 AI 輔助寫作的可審核追溯層。
- 限制：預印本；研究集中在主張—證據關係判定，不等於完整事實查核或法律責任判決。

## R26｜OpenTelemetry GenAI Observability

- 來源：OpenTelemetry 官方文章與語意慣例
- 日期：2026-05-14（文章）
- URL：https://opentelemetry.io/blog/2026/genai-observability/
- 支持章節：6、8
- 支持觀點：Agent 執行可拆成 invoke_agent、model chat、execute_tool 等 spans，透過分散式追蹤找出延遲、重試與錯誤來源。
- 限制：GenAI semantic conventions 仍持續移動與演進；實作需注意敏感內容與成本。

## R27｜Palantir Ontology Overview

- 來源：Palantir 官方文件
- 日期：持續更新；查閱日 2026-08-08
- URL：https://palantir.com/docs/foundry/ontology/overview/
- 支持章節：3、4、11
- 支持觀點：Ontology 是組織的 operational layer，將資料與真實物件、關係、actions、functions、security 連結，可支援決策與行動。
- 限制：屬特定商業平台的架構；本書用作具體案例，不把其產品設計視為唯一企業 AI OS。

## R28｜Palantir AIP Observability and Evals

- 來源：Palantir 官方文件
- 日期：持續更新；查閱日 2026-08-08
- URL：https://palantir.com/docs/foundry/aip-observability/overview/
- 支持章節：8、11
- 支持觀點：企業 Agent 與 workflow 可整合 metrics、tracing、logs、execution history 與模擬式 eval。
- 限制：產品能力描述，不代表中立基準。

## R29｜OpenAI Monitoring Internal Coding Agents for Misalignment

- 來源：OpenAI 官方文章
- 日期：2026-03-19
- URL：https://openai.com/index/how-we-monitor-internal-coding-agents-misalignment/
- 支持章節：8、10、12
- 支持觀點：更自主的 Agent 需要持續監控、風險訊號與分層緩解，而不是只依賴單次輸出檢查。
- 限制：內部監控方法只揭露部分細節。

## R30｜OpenAI Symphony Orchestration

- 來源：OpenAI 官方文章
- 日期：2026-04-27
- URL：https://openai.com/index/open-source-codex-orchestration-symphony/
- 支持章節：6、7、11
- 支持觀點：可把工作看板變成 Agent control plane，由持續運作的 Agent 接任務、人類審查成果。
- 限制：以軟體開發與特定組織經驗為主；不能直接外推一般企業。

---

# 研究結論摘要

1. Agent 的學術骨架早於「Loop Engineering」這個名稱：ReAct、Toolformer、Reflexion、AutoGen 已建立推理—行動—工具—回饋—多 Agent 的關鍵零件。
2. 2024 至 2026 的官方工程文件把這些零件推進為可運營的 Context、Harness、Runtime、Tracing、Evals、Guardrails、HITL 與 durable workflow。
3. 「Loop Engineering」目前適合描述新興工作方法，不宜宣稱為成熟學術標準。它最有價值之處，是把分散的 Agent Workflow、Context／Harness Engineering、DevOps 與 Human Oversight 統整為人可操作的工作循環。
4. SARC-DQ 與 Evidence-Ledger 分別補上「行動以前的資料品質」與「主張釋出以前的證據關係」。兩者可由作者整合成雙閘門證據迴路，但必須清楚標示為本書方法論。
5. 李開復與零一萬物提供企業與組織視角；本書的差異，是把「一號位工程、AI 決策中樞、DRI」接到 Context、Harness、Runtime、Loop 與證據治理的底層。
