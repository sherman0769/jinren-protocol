# 來源整理與查證筆記｜10萬字出版擴充版

資料校準日期：2026-07-09

本書使用來源的原則是：技術論文作為趨勢校準，官方文件與官方案例作為產品與產業動態校準。所有 arXiv 來源均以「預印本／最新研究線索」處理，不把它們寫成已完成同儕審查或已成產業標準的結論。

## 核心來源

1. LLM-as-a-Verifier: A General-Purpose Verification Framework, arXiv:2607.05391, 2026-07-06。
   - 用途：建立「驗證層」概念。重點包含 continuous scores、repeated evaluation、criteria decomposition、agentic task progress monitoring，以及 Terminal-Bench V2、SWE-Bench Verified、RoboRewardBench、MedAgentBench 等評估情境。
   - URL：https://arxiv.org/abs/2607.05391

2. AgentGym2: Benchmarking Large Language Model Agents in De-Idealized Real-World Environments, arXiv:2607.05174 / ACL Anthology 2026。
   - 用途：建立「真實環境測試」概念。重點包含 de-idealized environments、tool discovery、tool composition、noise、underspecified information、end-to-end working demands。
   - URL：https://arxiv.org/html/2607.05174v1

3. FORGE: Research-Trajectory Hijacking Attacks on Deep Research Agents, arXiv:2607.04718, 2026-07-06。
   - 用途：建立 Deep Research 的研究路徑污染風險。重點包含 retrieval-planning coupling、planning-layer poisoning、report-level contamination、PRISM、Root Query Anchoring。
   - URL：https://arxiv.org/html/2607.04718v1

4. MRMS: A Multi-Resolution Memory Substrate for Long-Lived AI Agents, arXiv:2607.04617, 2026-07-06。
   - 用途：建立長期 Agent 記憶設計觀念。重點包含 structured records、vector representations、graph relations、short-term traces、medium-term abstractions、long-term semantic commitments。
   - URL：https://arxiv.org/abs/2607.04617

5. Search Beyond What Can Be Taught: Evolving the Knowledge Boundary in Agentic Visual Generation, arXiv:2607.05382, 2026-07-06。
   - 用途：建立「搜尋接地的圖像生成」概念。重點包含 SearchGen-20K、SearchGen-Bench、world-knowledge bottleneck、knowledge boundary、tool-augmented visual generation。
   - URL：https://arxiv.org/abs/2607.05382

6. MV-Forcing: Long Multi-View Video Generation via 4D-Grounded Spatio-Temporal Self-Forcing, arXiv:2607.05376, 2026-07-06。
   - 用途：說明長時間、多視角一致影片生成。重點包含 4D geometric bridge、temporal and view-wise autoregression、multi-view consistency。
   - URL：https://arxiv.org/abs/2607.05376

7. TimeThink: Reasoning with Time for Video LLMs, arXiv:2607.05089, 2026-07-06。
   - 用途：說明 Video-LLM 的時間證據推理。重點包含 temporal evidence discovery、candidate time interval、step-wise temporal process reward。
   - URL：https://arxiv.org/abs/2607.05089

8. Government of Alberta uses Claude to find and fix cybersecurity vulnerabilities across government systems, Anthropic, 2026-07-06。
   - 用途：作為 Coding Agent 進入政府與企業級資安盤點的案例。官方文中提到 Alberta 使用 Claude Code、Opus、Sonnet 掃描大規模程式碼、找漏洞、產修補建議與文件。
   - URL：https://www.anthropic.com/news/alberta-government-claude-cybersecurity

9. How A2A is Building a World of Collaborative Agents, Google Developers Blog, 2026-06-18；Announcing the Agent2Agent Protocol, Google Developers Blog, 2025-04-09。
   - 用途：建立多 Agent 協作、secure boundary、context pollution、agent interoperability 與 A2A/MCP 分工概念。
   - URL：https://developers.googleblog.com/how-a2a-is-building-a-world-of-collaborative-agents/
   - URL：https://developers.googleblog.com/en/a2a-a-new-era-of-agent-interoperability/

10. Claude Science: an AI workbench for scientists, Anthropic, 2026-06-30；Anthropic unveils Claude Science for scientific research, Reuters, 2026-06-30。
    - 用途：建立「可稽核研究工作台」概念。重點包含 research workbench、auditable artifacts、compute access、source code、environment、research workflow。
    - URL：https://www.anthropic.com/news/claude-science-ai-workbench
    - URL：https://www.reuters.com/science/anthropic-unveils-claude-science-ai-platform-scientific-research-2026-06-30/

11. OpenAI Agents SDK / Responses API / Tools 官方文件與部落格。
    - 用途：校準 agent 建置、內建工具、MCP、file search、web search、computer use、tracing、Agents SDK 等概念。
    - URL：https://openai.com/index/new-tools-for-building-agents/
    - URL：https://developers.openai.com/api/docs/guides/agents
    - URL：https://openai.github.io/openai-agents-python/tools/

## 寫作轉化原則

- 不把 benchmark 分數寫成永久結論，因為模型與評估框架會持續變動。
- 不把預印本寫成已定型標準，而是把它們當作「問題正在浮現」的訊號。
- 技術名詞保留必要英文，但先用繁體中文解釋。
- 每一個來源都必須回到課程、演講、企業內訓或自讀內化，不讓書稿變成文獻列表。
