第二章｜真實世界不是 Demo：為什麼 Agent 一上線就變笨？
版本：10萬字出版擴充版
資料校準日期：2026-07-09

本章內容包含：
1. chapter_02_main.md / docx：章節正文擴充版
2. chapter_02_speech_notes.md：演講轉化筆記
3. chapter_02_slide_outline.md：投影片大綱
4. chapter_02_quotes.md：金句庫
5. chapter_02_loop_canvas.md：Loop Canvas

本章中文字數估算：9,410 字（以 CJK 字元估算，不含英文與標點）。
核心模型：Demo-to-Deployment Gap：展示到部署落差
核心用途：自讀、課程、演講、社群貼文、企業內訓與顧問提案。
