# 序章｜為什麼 ChatGPT 已經不是重點了？｜Loop Canvas（10萬字擴充版）

## 任務定義
為什麼我們不能再只把 AI 當成一個聊天視窗？

## 核心觀點
ChatGPT 是入口，Agent 是流程；Prompt 是一句話，Loop 是一套系統。

## 來源校準
OpenAI, New tools for building agents, 2025-03-11；OpenAI API / Agents SDK docs, 2026 年持續更新

## 模型
Trusted Agent Loop：可信 Agent 迴路

## 迴路節點
- Ground 接地
- Act 行動
- Verify 驗證
- Trace 追蹤
- Remember 記憶
- Govern 治理
- Improve 改善

## 風險提醒
把 AI 只當聊天介面，會讓人誤以為「問得好」就是全部能力，忽略資料、工具、驗證、權限與回饋。

## 教學轉化
把「AI 入門課」從提示詞模板課，升級成任務迴路設計課。

## 企業轉化
企業導入不是裝一個聊天機器人，而是盤點任務、資料、工具、驗證與治理節點。

## Human on Loop 問題
- 人應該站在哪一個放行點？
- 哪些標準可以預先寫入系統？
- 哪些例外必須人工判斷？
- 這一章如何變成一張流程檢查表？
