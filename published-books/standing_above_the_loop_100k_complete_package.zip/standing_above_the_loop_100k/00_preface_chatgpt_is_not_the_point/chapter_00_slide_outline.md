# 序章｜為什麼 ChatGPT 已經不是重點了？｜投影片大綱（10萬字擴充版）

1. 封面：序章｜為什麼 ChatGPT 已經不是重點了？
2. 今日問題：為什麼我們不能再只把 AI 當成一個聊天視窗？
3. 常見誤解：把 AI 只當聊天介面，會讓人誤以為「問得好」就是全部能力，忽略資料、工具、驗證、權限與回饋。
4. 白話比喻：ChatGPT 像櫃台問答，Agent 像一座有接單、派工、驗收、記錄與改善機制的工作站。
5. 來源校準：OpenAI, New tools for building agents, 2025-03-11；OpenAI API / Agents SDK docs, 2026 年持續更新
6. 核心觀點：ChatGPT 是入口，Agent 是流程；Prompt 是一句話，Loop 是一套系統。
7. 模型圖：Trusted Agent Loop：可信 Agent 迴路
8. 模型節點：Ground 接地 / Act 行動 / Verify 驗證 / Trace 追蹤 / Remember 記憶 / Govern 治理 / Improve 改善
9. 個人應用：自讀、寫作、備課、顧問整理
10. 企業應用：企業導入不是裝一個聊天機器人，而是盤點任務、資料、工具、驗證與治理節點。
11. 課堂練習：畫出一個最小 AI 工作迴路
12. 金句收束：很多人還在學怎麼把 prompt 寫漂亮，但下一階段真正稀缺的是能設計 AI 工作迴路的人。
