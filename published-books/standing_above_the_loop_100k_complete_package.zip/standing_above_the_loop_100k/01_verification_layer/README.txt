第一章｜AI Agent 的新問題：不是能不能做，而是能不能證明它做對了
版本：10萬字出版擴充版
資料校準日期：2026-07-09

本章內容包含：
1. chapter_01_main.md / docx：章節正文擴充版
2. chapter_01_speech_notes.md：演講轉化筆記
3. chapter_01_slide_outline.md：投影片大綱
4. chapter_01_quotes.md：金句庫
5. chapter_01_loop_canvas.md：Loop Canvas

本章中文字數估算：9,467 字（以 CJK 字元估算，不含英文與標點）。
核心模型：Verification Ladder：驗證階梯
核心用途：自讀、課程、演講、社群貼文、企業內訓與顧問提案。
