第五章｜圖像生成的下一步：不是提示詞，而是搜尋接地
版本：10萬字出版擴充版
資料校準日期：2026-07-09

本章內容包含：
1. chapter_05_main.md / docx：章節正文擴充版
2. chapter_05_speech_notes.md：演講轉化筆記
3. chapter_05_slide_outline.md：投影片大綱
4. chapter_05_quotes.md：金句庫
5. chapter_05_loop_canvas.md：Loop Canvas

本章中文字數估算：9,267 字（以 CJK 字元估算，不含英文與標點）。
核心模型：Search-Grounded Visual Loop：搜尋接地視覺迴路
核心用途：自讀、課程、演講、社群貼文、企業內訓與顧問提案。
