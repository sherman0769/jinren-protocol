第六章｜影音生成開始進入「時間」與「視角」的時代
版本：10萬字出版擴充版
資料校準日期：2026-07-09

本章內容包含：
1. chapter_06_main.md / docx：章節正文擴充版
2. chapter_06_speech_notes.md：演講轉化筆記
3. chapter_06_slide_outline.md：投影片大綱
4. chapter_06_quotes.md：金句庫
5. chapter_06_loop_canvas.md：Loop Canvas

本章中文字數估算：9,390 字（以 CJK 字元估算，不含英文與標點）。
核心模型：Video Continuity Stack：影片連續性堆疊
核心用途：自讀、課程、演講、社群貼文、企業內訓與顧問提案。
