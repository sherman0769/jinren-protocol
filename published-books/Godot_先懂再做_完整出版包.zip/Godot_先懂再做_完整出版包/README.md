# 《先懂再做：用 Godot 建立遊戲開發的全局觀》完整出版包

作者：李詩民  
技術基準：Godot 4.7 Stable  
研究查閱基準日：2026-07-12  
版本：V1.0

## 閱讀入口

1. `01_master/full_book.docx`：完整閱讀版。
2. `01_master/full_book.md`：全書唯一合併內容來源。
3. `02_chapters/`：逐章正文、Podcast／演講筆記、簡報、金句、模型畫布、Codex 指令與 DOCX。
4. `03_research/`：官方來源與事實查核。
5. `04_quality/`：字數、重複、品質與驗證報告。
6. `05_delivery/chapter_zips/`：各單元獨立 ZIP。
7. `05_delivery/delivery_manifest.txt`：交付檔案、大小與 SHA-256。

## 內容維護原則

每章 `chapter_XX_main.md` 是正式來源；修改後先更新 Markdown，再重新生成 DOCX、全書合併稿與受影響衍生內容。版本敏感的介面、平台匯出與 Codex 功能必須重新查證。
