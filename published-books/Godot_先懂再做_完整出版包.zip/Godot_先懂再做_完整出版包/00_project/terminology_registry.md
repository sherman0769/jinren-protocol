# Terminology Registry｜術語一致性登錄

本檔與附錄一使用同一份正式術語資料。正文第一次出現時採中文解釋加英文，後續依語境使用英文類別名或台灣常用中文。

| 英文／程式名稱 | 本書中文 | 一句定義 | 首要關聯 | 禁止混淆 |
|---|---|---|---|---|
| Godot Engine | Godot 遊戲引擎 | 自由、開源、社群驅動的 2D 與 3D 遊戲引擎與工具集。 | 編輯器、專案、Runtime、場景與節點。 | 它不是一款遊戲，也不等於 GDScript。 |
| Editor | 編輯器 | 開發者用來建立場景、設定屬性、編輯腳本、執行與除錯的工作環境。 | Scene Dock、Viewport、Inspector、FileSystem。 | 編輯器畫面不是玩家最後執行的成品。 |
| Project | 專案 | 以含有 project.godot 的根目錄為邊界，集合場景、腳本、資源、素材與設定。 | res://、版本控制、主場景。 | 專案不是單一場景，也不是匯出的執行檔。 |
| Runtime | 執行時期 | 按下執行後，場景被實例化、節點進入 SceneTree 並依規則運轉的階段。 | 生命週期、遊戲迴路、狀態。 | Runtime 中的變化通常不會自動寫回原始場景。 |
| Stable | 穩定版 | 完成正式發布流程、適合作為一般專案基準的版本狀態。 | RC、Beta、版本遷移。 | 穩定版不代表完全沒有錯誤。 |
| Release Candidate | 候選版 | 接近正式發布、用於發現最後回歸問題的預發布版本，常縮寫為 RC。 | Stable、回歸測試。 | RC 並不等於已經正式發布。 |
| Beta | 測試版 | 功能大致成形但仍可能改動或包含較多問題的預發布階段。 | Dev Snapshot、RC。 | 不應把 Beta 行為寫成長期穩定承諾。 |
| Dev Snapshot | 開發快照 | 較早期的開發版本，用於讓社群試驗尚未穩定的功能。 | Beta、版本控制、備份。 | 最新的 dev 數字不代表最適合正式專案。 |
| MIT License | MIT 授權 | Godot 引擎採用的寬鬆開源授權，允許個人、教育與商業使用並要求保留授權文字。 | 第三方素材、外掛授權。 | Godot 採 MIT 不代表專案內所有素材都自動採 MIT。 |
| Standard Build | 標準版 | 以 GDScript 與 GDExtension 等為主要使用方式、不包含 .NET/C# 支援的 Godot 發行版本。 | .NET Build、GDScript。 | 標準版不是功能不足版，只是語言工具鏈不同。 |
| .NET Build | .NET 版 | 加入 C#/.NET 支援的 Godot 發行版本，需要相符 .NET 工具鏈。 | C#、Export Templates、平台支援。 | 不能假設它在所有平台與標準版的匯出能力完全相同。 |
| Renderer | 渲染器 | 把場景中的幾何、材質、光線與畫面資料轉成螢幕影像的系統。 | Rendering Method、GPU、Shader。 | 渲染器不是一個單純的畫質高低按鈕。 |
| Rendering Method | 渲染方法 | Godot 專案依平台與功能選擇的渲染路徑，例如 Forward+、Mobile 或 Compatibility。 | Renderer、目標平台、驅動。 | 不能脫離平台條件宣稱某一種永遠最好。 |
| Export Template | 匯出範本 | Godot 用來為各目標平台建立成品所需的引擎範本。 | Export Preset、Godot 版本。 | 版本不相符的範本可能造成匯出失敗。 |
| Export Preset | 匯出設定檔 | 針對某一平台保存架構、資源、圖示、簽章等匯出選項的設定。 | export_presets.cfg、Export Template。 | 成功建立 preset 不等於已在目標裝置驗收。 |
| Debug Build | 除錯建置 | 保留較多診斷資訊、方便開發與追蹤錯誤的成品模式。 | Release Build、Debugger。 | Debug 表現不能直接代表正式版效能。 |
| Release Build | 發行建置 | 偏向正式散布與效能的建置模式，通常較少除錯資訊。 | Debug Build、平台驗收。 | Release 檔生成成功不代表所有功能與授權都完成。 |
| Node | 節點 | Godot 的基本構成單位，每種 Node 類型代表一組責任與引擎能力。 | Scene、SceneTree、父子關係。 | Node 不一定可見，也不等於一張圖片。 |
| Scene | 場景 | 一棵具有意義、可保存與可重複實例化的節點樹。 | Node、PackedScene、Instance。 | Scene 不只代表完整關卡。 |
| SceneTree | 場景樹管理器 | 管理 Runtime 中活動節點樹與主迴路的 Godot 類別。 | Node、生命週期、Group、暫停。 | 它不是硬碟上的單一 .tscn 檔。 |
| Main Scene | 主場景 | 專案執行時最先載入的場景入口。 | project.godot、GameFlow。 | 主場景不一定要包含所有遊戲內容。 |
| Root Node | 根節點 | 一個場景最上層的節點，代表該場景對外的主要身分。 | Scene、公開介面。 | 根節點不應只依第一個方便加入的類型決定。 |
| Parent Node | 父節點 | 在樹狀結構中直接擁有子節點的上層節點。 | Child Node、Transform、生命週期。 | 父節點不必承擔所有子節點的業務邏輯。 |
| Child Node | 子節點 | 隸屬於某個父節點的節點，會參與同一子樹的生命週期。 | Parent Node、local transform。 | 子節點的 local position 不是世界座標。 |
| NodePath | 節點路徑 | 用名稱與階層描述 SceneTree 中節點位置的路徑資料。 | get_node、$、封裝。 | 長而跨場景的硬編碼路徑容易因重構失效。 |
| Instance | 實例 | 依場景或類別定義建立出的具體 Runtime 個體。 | PackedScene、instantiate、狀態。 | 修改一個實例不一定會改原始場景或其他實例。 |
| PackedScene | 封裝場景資源 | 保存場景節點結構並可在程式中 instantiate 的 Resource 類型。 | Scene、Resource、Instance。 | 它是場景資料，不是已加入 SceneTree 的活動節點。 |
| Owner | 場景擁有者 | Node 的保存所有權資訊，決定節點是否隨某個 PackedScene 一起保存。 | Parent、PackedScene、工具腳本。 | 成為 child 不一定就自動成為場景保存內容。 |
| Composition | 組合 | 以多個具有清楚責任的節點或元件共同構成更複雜角色。 | Node、Scene、元件。 | 組合不是把每個變數都拆成一個節點。 |
| Inheritance | 繼承 | 讓腳本或類別在既有類型能力上擴充行為的機制。 | extends、基底類別、組合。 | 繼承不是所有重用問題的唯一解法。 |
| Encapsulation | 封裝 | 透過公開方法、屬性與訊號隱藏可替換的內部細節。 | 場景邊界、耦合。 | 封裝不是禁止所有互動，而是控制互動入口。 |
| Autoload | 自動載入／全域單例 | 專案啟動時自動加入並可跨場景持續存在的節點或腳本。 | SceneTree、全域狀態、服務。 | 不應把所有方便取得的變數都塞進一個 Global。 |
| Group | 群組 | 附加在節點上的標籤，SceneTree 可用它查找或批次呼叫一群節點。 | SceneTree、共同身分。 | 加入群組不會自動保證所有成員都有同一方法。 |
| Signal | 訊號 | 物件在事件發生時發出的訊息，連接者可據此呼叫回應函式。 | Event、Callable、低耦合。 | Signal 適合宣告事件，不是把所有直接方法呼叫全部替換。 |
| Callable | 可呼叫物件 | 封裝某個可被呼叫方法及其目標的 Godot 資料型別。 | Signal、method。 | Callable 有效不代表目標物件永遠仍存在。 |
| Local Scene | 本地場景視圖 | 編輯器中保存與編輯的場景來源結構。 | Remote SceneTree、.tscn。 | 它不會顯示所有 Runtime 動態生成的節點。 |
| Remote SceneTree | 遠端場景樹 | 遊戲執行時，編輯器顯示的實際活動節點樹。 | Runtime、除錯、Instance。 | 停止遊戲後 Remote 變化不會自動保存回場景來源。 |
| Asset | 素材／資產 | 從外部進入專案的圖片、音訊、字型、模型、外掛等內容與來源。 | Resource、授權、Import。 | 素材能被 Godot 匯入，不代表使用權已經確認。 |
| Resource | 資源 | 可保存、載入、共享並由 Inspector 編輯的資料容器。 | Node、Custom Resource、.tres。 | Resource 通常不需要成為 SceneTree 節點。 |
| Custom Resource | 自訂資源 | 由腳本 extends Resource 所建立、具有專案語意的資料類型。 | Resource、@export、資料驅動。 | 不應把每個實例的即時狀態無差別放進共用資源。 |
| Texture2D | 二維紋理資源 | 保存可供 2D 顯示與 UI 使用的圖像資料。 | Sprite2D、TextureRect、Import。 | Texture2D 是資料，不具有自己的世界位置。 |
| AudioStream | 音訊串流資源 | 表示可由音訊播放節點載入與播放的聲音資料。 | AudioStreamPlayer、Import。 | 它不是播放節點，單獨 Resource 不會自己發聲。 |
| Material | 材質 | 描述表面如何被渲染的資源，可引用 Shader 與紋理。 | Mesh、Shader、共享 Resource。 | 修改共用 Material 可能讓所有引用實例一起變化。 |
| Shader | 著色器 | 在圖形管線中運算像素、頂點或其他視覺效果的程式。 | Material、Renderer、GPU。 | Shader 能做特效，不代表所有遊戲規則都應放進 GPU。 |
| Theme | 介面主題資源 | 集中定義 Control 節點的字型、顏色、樣式盒與其他 UI 外觀。 | Control、Font、StyleBox。 | 修改共用 Theme 會影響所有使用者，單一例外要另行覆寫。 |
| .tres | 文字資源檔 | Godot 可讀、較適合版本控制的文字格式 Resource 檔。 | Resource、Custom Resource、Git。 | 文字可讀不代表適合無限制整檔重寫。 |
| .res | 二進位資源檔 | Godot 的二進位 Resource 格式，通常較不適合人工差異審查。 | Resource、.tres。 | 它不是一般文字檔，不能期待 Codex 直接安全編輯。 |
| .tscn | 文字場景檔 | 以文字形式保存場景節點、屬性與資源引用的檔案。 | Scene、PackedScene、Git。 | 複雜 .tscn 含 ID 與引用，整份重寫可能遺失關係。 |
| project.godot | 專案設定檔 | Godot 專案根目錄的入口與專案層級設定檔。 | Project Settings、Input Map、Main Scene。 | 它不是整個遊戲，也不應為加一項設定而整份覆寫。 |
| res:// | 專案資源根路徑 | 指向目前 Godot 專案根目錄的虛擬路徑前綴。 | Project、ResourceLoader、檔案引用。 | 它不是電腦上固定的絕對磁碟路徑。 |
| user:// | 使用者資料路徑 | 指向應用在目前平台可寫入之使用者資料位置的虛擬路徑。 | Save Data、偏好設定。 | 它在各作業系統的實際路徑不同。 |
| .godot/ | Godot 快取目錄 | 保存匯入快取與編輯器產生中間資料的可重建目錄。 | Import、Git ignore。 | 通常不應當成正式來源提交或讓 Codex 直接維護。 |
| Import | 匯入 | Godot 將外部素材轉成引擎可使用資料與快取的流程。 | Asset、Resource、.godot。 | 原始素材、匯入設定與 Runtime 資源是不同層次。 |
| GDScript | Godot 腳本語言 | 與 Godot 深度整合、支援物件導向與逐步型別的高階腳本語言。 | Node、Resource、Signal。 | 學 Godot 不等於只背 GDScript 語法。 |
| C# | C# 語言 | Godot .NET 版正式支援的程式語言與工具鏈選項。 | .NET Build、平台匯出。 | 不能把 GDScript API 寫法直接逐字換成 C#。 |
| GDExtension | 原生擴充介面 | 讓原生程式庫與 Godot 互動而不必自行維護完整引擎分支的擴充機制。 | C、C++、效能、外掛。 | 它不是初學者每個功能都需要的最佳化捷徑。 |
| extends | 繼承宣告 | GDScript 指定目前腳本建立在哪個基底類別能力上的語法。 | Node、Resource、Inheritance。 | extends 的類型與腳本掛載節點不相容會造成問題。 |
| class_name | 全域類別名稱 | 讓 GDScript 類別以專案可識別名稱出現在型別與編輯器中的宣告。 | Type Hint、Custom Resource。 | 不是每個小腳本都必須宣告全域名稱。 |
| @export | 匯出屬性註記 | 讓腳本欄位可在 Inspector 設定與序列化的 GDScript 註記。 | Inspector、設計參數。 | 不應把所有內部變數都公開給 Inspector。 |
| @onready | 準備時初始化註記 | 讓變數在節點接近 ready 階段時初始化，常用於取得子節點引用。 | _ready、NodePath。 | 方便取得節點不代表長路徑耦合自動消失。 |
| Variable | 變數 | 保存會依實例或執行狀態改變資料的具名位置。 | State、Type Hint、Resource。 | 同一個數值也要區分設計設定與 Runtime 狀態。 |
| Constant | 常數 | 在腳本中用來表達不應於 Runtime 任意改變的具名值或引用。 | Variable、預載資源。 | 宣告為常數不代表其引用的 Resource 內容絕對不可變。 |
| Function | 函式 | 具有名稱、輸入、輸出與可能副作用的一段可呼叫行為。 | Method、Callable、公開介面。 | 函式名稱若無法說明副作用，結構可能過度混雜。 |
| Type Hint | 型別提示 | 明確指出變數、參數與回傳值預期資料類型的註記。 | GDScript、靜態檢查。 | 型別不只為效能，也是一份合約。 |
| _enter_tree() | 進入樹回呼 | 節點加入 SceneTree 時由引擎呼叫的生命週期方法。 | _ready、父子順序。 | 不等同所有初始化都應放在這裡。 |
| _ready() | 準備完成回呼 | 節點與必要子樹準備完成後由引擎呼叫的方法。 | @onready、初始化。 | 同一實例移出再加入樹時不應假設一定自動再次呼叫。 |
| _process() | 閒置幀處理 | 依顯示幀率反覆呼叫、接收 delta 的更新方法。 | delta、_physics_process。 | 不應把只在事件發生時需要的工作全部每幀重做。 |
| _physics_process() | 物理幀處理 | 以固定物理節奏反覆呼叫、適合物理與角色移動的更新方法。 | CharacterBody2D、delta。 | 實際頻率可設定，不必硬記永遠六十次。 |
| delta | 幀間時間差 | 距離上一次處理經過的秒數，用來把每幀變化轉成時間相關變化。 | 速度、計時、process。 | 不是所有 API 都要再乘 delta；有些方法已處理時間。 |
| _input() | 輸入事件回呼 | 節點接收輸入事件時由引擎呼叫的回呼之一。 | Input Event、Input Map。 | 持續移動不一定只靠單次 _input 事件。 |
| await | 等待 | 暫停目前函式流程，直到訊號或可等待結果完成後再繼續。 | Signal、Timer、Animation。 | 等待期間世界仍會改變，節點可能被移除或流程重入。 |
| queue_free() | 排程釋放節點 | 把節點安排在安全時機從場景樹移除並釋放。 | 生命週期、Instance。 | 呼叫後不要假設節點與所有引用仍可長期使用。 |
| Process Mode | 處理模式 | 決定節點在一般、暫停或特定條件下是否繼續處理的設定。 | Pause、SceneTree。 | 只設定 get_tree().paused 不代表所有節點都符合需求。 |
| Input Map | 輸入映射 | 把實體按鍵、按鈕或軸轉成遊戲抽象動作的設定系統。 | Action、Input Event、project.godot。 | 動作字串拼錯時，程式可能只表現成沒有反應。 |
| Input Event | 輸入事件 | 描述鍵盤、滑鼠、手把、觸控等一次輸入資訊的事件物件。 | _input、Input Map。 | 原始事件不應直接滲透所有遊戲規則。 |
| Action Strength | 動作強度 | Input Map 動作目前的數值強度，可表達數位按鍵或類比軸。 | Input Map、Vector2。 | 它不一定只有零或一。 |
| Vector2 | 二維向量 | 含 X、Y 兩個分量的資料型別，可表達位置、方向、速度或尺寸。 | Node2D、Velocity。 | 同一 Vector2 值需辨認它是位置、方向還是速度。 |
| Velocity | 速度向量 | 描述物體每單位時間移動方向與速率的向量。 | CharacterBody2D、delta。 | 速度與本次位移不是同一個量。 |
| CharacterBody2D | 二維角色物理節點 | 適合由程式控制並與世界碰撞的 2D 角色 Body。 | velocity、move_and_slide、CollisionShape2D。 | 不要把一般 position 積分公式無條件套到其所有移動 API。 |
| RigidBody2D | 二維剛體 | 主要由物理模擬、力與碰撞反應控制的 2D Body。 | Force、Impulse、Physics。 | 每幀硬改 transform 可能與物理模擬對抗。 |
| StaticBody2D | 二維靜態物體 | 通常代表不移動的物理碰撞環境。 | 牆、地面、CollisionShape2D。 | 不適合直接拿來做持續移動的角色。 |
| AnimatableBody2D | 二維可動畫物體 | 由程式或動畫移動、同時希望正確影響其他物理物件的 Body。 | 移動平台、Physics。 | 它與由力控制的 RigidBody2D 角色不同。 |
| Area2D | 二維偵測區域 | 偵測 Body 或其他 Area 進入、離開與重疊的 2D 節點。 | Signal、Layer、Mask。 | Area2D 通常不是用來像牆一樣阻擋角色。 |
| CollisionShape2D | 二維碰撞形狀節點 | 為父 Body 或 Area 提供實際碰撞邊界的節點。 | Shape2D Resource、Physics。 | 只建立節點而沒有指定 Shape Resource 不會得到有效碰撞。 |
| Collision Layer | 碰撞層 | 表示物理物件屬於哪些分類的位元設定，可口語理解為「我是誰」。 | Collision Mask、Project Settings。 | Layer 本身不等於它會偵測誰。 |
| Collision Mask | 碰撞遮罩 | 表示物理物件關心或偵測哪些碰撞層，可理解為「我要看誰」。 | Collision Layer、Area2D。 | Layer 與 Mask 未匹配時，形狀重疊也可能沒有事件。 |
| Timer | 計時器節點 | 在指定時間後發出 timeout，或週期性觸發的時間工具。 | Signal、無敵時間、生成。 | 暫停政策與 process mode 會影響是否繼續計時。 |
| Tween | 補間動畫 | 以程式建立，把數值從起點平滑過渡到終點的時間流程。 | UI、視覺回饋、AnimationPlayer。 | Tween 適合插值，不應取代所有狀態與遊戲規則。 |
| AnimationPlayer | 動畫播放器 | 保存並播放可編輯的多軌屬性動畫。 | Animation、Signal、await。 | 每幀重播同一動畫可能讓它永遠停在開頭。 |
| AnimationTree | 動畫樹 | 用節點圖混合與控制複雜動畫狀態的系統。 | AnimationPlayer、State Machine。 | 小型單一動畫不一定需要先建立 AnimationTree。 |
| Control | 介面控制節點 | Godot UI 系統的基礎節點，使用錨點、尺寸與容器版面。 | Container、Anchor、Theme。 | 不應只把 Control 當成可自由擺放的 Sprite2D。 |
| Container | 介面容器 | 依規則自動排列與調整子 Control 節點的 UI 節點。 | HBox、VBox、Grid、size flags。 | 容器擁有子項版面，手動位置常會被重新計算。 |
| Anchor | 錨點 | Control 相對父節點尺寸的比例參考位置。 | Offset、Responsive UI。 | Anchor 不是直接以像素表示位置。 |
| Offset | 位移邊界 | Control 在 Anchor 參考位置上增加的像素邊界差。 | Anchor、Control。 | 只調 Offset 而不理解 Anchor，視窗變化時容易跑版。 |
| CanvasLayer | 畫布層 | 讓 2D 子節點在獨立畫布層中繪製，不受一般世界 Camera2D 變換的節點。 | HUD、Camera2D。 | CanvasLayer 不是遊戲狀態管理器。 |
| Camera2D | 二維攝影機 | 決定 2D 世界哪一區域與如何映射到視窗的節點。 | World coordinates、CanvasLayer。 | 玩家世界位置與螢幕位置不是同一座標。 |
| Node3D | 三維節點 | 具有 3D 位置、旋轉與縮放的空間節點基礎。 | Transform3D、Camera3D、Mesh。 | 從 2D 遷移時仍需重新學三維方向與旋轉。 |
| Transform | 變換 | 描述物件位置、旋轉與縮放，以及它如何從局部空間映射到父空間。 | Local、Global、父子階層。 | Transform 不是只有 position 一個值。 |
| Local Coordinates | 局部座標 | 相對父節點所表示的位置或方向。 | Global Coordinates、Transform。 | 同一 local position 在不同父節點下會對應不同世界位置。 |
| Global Coordinates | 全域座標 | 經父節點變換鏈組合後，在整個世界或畫布中的位置。 | Local Coordinates、Camera。 | 滑鼠 viewport 座標不能不轉換就當世界 global position。 |
| State | 狀態 | 系統此刻記住的資料或模式，會影響下一步允許的行為。 | Game Loop、State Machine。 | 畫面看起來暫停不代表內部狀態與所有系統都已暫停。 |
| State Machine | 狀態機 | 集中管理有限狀態、轉換條件、進入與退出行為的模型。 | State、AnimationTree、流程。 | 狀態少時不一定要先建立大型通用框架。 |
| Coupling | 耦合 | 模組彼此依賴的程度與方式。 | Encapsulation、Signal、NodePath。 | 目標不是零耦合，而是必要、清楚且方向合理的依賴。 |
| Single Source of Truth | 單一真相來源 | 同一核心狀態由一個明確擁有者保存與修改，其他對象只讀取或接收事件。 | Data Flow、HUD、GameState。 | 不是說整個遊戲只能有一個全域物件。 |
| Save Data | 存檔資料 | 從 Runtime 狀態中挑選、序列化並跨啟動保存的版本化資料。 | user://、Resource、版本遷移。 | 不應直接把整棵 SceneTree 當成可靠存檔。 |
| Debugger | 除錯器 | 提供錯誤、堆疊、變數與 Runtime 診斷資訊的工具。 | Output、Remote SceneTree、Profiler。 | 只把錯誤訊息隱藏不等於完成除錯。 |
| Profiler | 效能分析器 | 量測腳本、物理、渲染與其他系統耗時或資源使用的工具。 | Optimization、目標裝置。 | 它不會替你自動決定所有效能目標。 |
| Git Checkpoint | Git 檢查點 | 在 AI 任務前後建立可比較、可提交與可回退的版本狀態。 | Diff、Codex、版本控制。 | Git 不只是最後備份，checkpoint 應在變更前建立。 |
| Headless Mode | 無頭模式 | 在沒有圖形編輯器視窗的環境執行 Godot 指令、檢查或匯出的方式。 | CLI、CI、自動驗證。 | 無頭啟動通過不代表畫面、音訊與手感已人工驗收。 |
| WebAssembly | WebAssembly | 讓 Godot Web 成品在瀏覽器中執行核心程式的二進位指令格式。 | Web Export、WebGL、伺服器。 | Web 匯出仍受瀏覽器音訊、檔案、執行緒與安全政策限制。 |
| Android App Bundle | Android 應用程式套件 | Google Play 常用的 Android 發布封裝格式，副檔名通常為 AAB。 | Android Export、簽章、版本碼。 | AAB 產生成功不代表觸控、背景切換與商店規則已驗收。 |
| Codex | Codex 程式代理 | OpenAI 的 coding agent，可在授權環境中閱讀、修改、執行與審查程式碼。 | Git、AGENTS.md、八格規格單。 | 它能產生與執行，不代表需求、API 與結果自動正確。 |
| AGENTS.md | 專案代理指示檔 | 可放在程式庫中的代理工作指示與導覽文件，實際支援方式依 Codex 最新文件。 | Codex、專案規則、README。 | 不應塞入所有背景造成冗長矛盾，也不能取代每次任務目標。 |
| Acceptance Criteria | 驗收條件 | 用可觀察結果定義一項工作何時算完成的條件。 | 八格規格單、測試、交付。 | 「程式碼已產生」或「看起來可以」不是充分驗收。 |
