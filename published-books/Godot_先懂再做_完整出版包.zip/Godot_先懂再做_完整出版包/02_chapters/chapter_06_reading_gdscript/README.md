# 第六章｜GDScript 不必先背，但必須看懂它在表達什麼

本資料夾是本單元的單一交付包。正式內容來源為 `chapter_06_main.md`；DOCX 與衍生內容都必須由該 Markdown 同步生成。

## 檔案用途

- `chapter_06_main.md`：正式書稿來源。
- `chapter_06_main.docx`：閱讀與編輯版。
- `chapter_06_speech_notes.md`：NotebookLM、Podcast、演講與口語複習。
- `chapter_06_slide_outline.md`：簡報架構。
- `chapter_06_quotes.md`：章末金句。
- `chapter_06_model_canvas.md`：唯一任務、關係鏈與教學目標。
- `chapter_06_codex_prompts.md`：章內可調整的 Codex 任務指令。

## 本單元驗收句

> 不先背完 GDScript，最低限度要看懂什麼？

能以自己的話回答這個問題，並說出「extends／腳本責任 → 變數與型別 → 生命週期入口 → 方法與條件 → 外部引用／Signal → 副作用與風險」，才算完成本單元的概念閉環。
