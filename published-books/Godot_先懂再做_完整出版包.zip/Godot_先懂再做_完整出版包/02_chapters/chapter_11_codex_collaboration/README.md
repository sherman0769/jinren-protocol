# 第十一章｜如何指揮 Codex 開發 Godot，而不是讓它自由發揮

本資料夾是本單元的單一交付包。正式內容來源為 `chapter_11_main.md`；DOCX 與衍生內容都必須由該 Markdown 同步生成。

## 檔案用途

- `chapter_11_main.md`：正式書稿來源。
- `chapter_11_main.docx`：閱讀與編輯版。
- `chapter_11_speech_notes.md`：NotebookLM、Podcast、演講與口語複習。
- `chapter_11_slide_outline.md`：簡報架構。
- `chapter_11_quotes.md`：章末金句。
- `chapter_11_model_canvas.md`：唯一任務、關係鏈與教學目標。
- `chapter_11_codex_prompts.md`：章內可調整的 Codex 任務指令。

## 本單元驗收句

> 如何讓 Codex 成為受控協作者，而不是自由發揮的程式產生器？

能以自己的話回答這個問題，並說出「讀取專案 → 釐清事實／未知 → 八格規格 → 計畫 → 最小修改 → Godot／測試檢查 → 人工驗收 → 回報與 checkpoint」，才算完成本單元的概念閉環。
