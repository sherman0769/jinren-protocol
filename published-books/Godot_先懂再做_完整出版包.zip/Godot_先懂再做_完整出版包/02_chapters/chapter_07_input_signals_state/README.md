# 第七章｜輸入、訊號、事件與狀態：遊戲物件如何互相溝通

本資料夾是本單元的單一交付包。正式內容來源為 `chapter_07_main.md`；DOCX 與衍生內容都必須由該 Markdown 同步生成。

## 檔案用途

- `chapter_07_main.md`：正式書稿來源。
- `chapter_07_main.docx`：閱讀與編輯版。
- `chapter_07_speech_notes.md`：NotebookLM、Podcast、演講與口語複習。
- `chapter_07_slide_outline.md`：簡報架構。
- `chapter_07_quotes.md`：章末金句。
- `chapter_07_model_canvas.md`：唯一任務、關係鏈與教學目標。
- `chapter_07_codex_prompts.md`：章內可調整的 Codex 任務指令。

## 本單元驗收句

> 遊戲物件如何互相溝通，又不彼此綁死？

能以自己的話回答這個問題，並說出「裝置輸入 → Input Map → 行為命令 → Signal 事件 → 狀態所有者更新資料 → UI／其他系統反應」，才算完成本單元的概念閉環。
