# 第八章｜每一幀發生什麼：生命週期、時間、物理與動畫

本資料夾是本單元的單一交付包。正式內容來源為 `chapter_08_main.md`；DOCX 與衍生內容都必須由該 Markdown 同步生成。

## 檔案用途

- `chapter_08_main.md`：正式書稿來源。
- `chapter_08_main.docx`：閱讀與編輯版。
- `chapter_08_speech_notes.md`：NotebookLM、Podcast、演講與口語複習。
- `chapter_08_slide_outline.md`：簡報架構。
- `chapter_08_quotes.md`：章末金句。
- `chapter_08_model_canvas.md`：唯一任務、關係鏈與教學目標。
- `chapter_08_codex_prompts.md`：章內可調整的 Codex 任務指令。

## 本單元驗收句

> 角色為什麼會動，而且在不同幀率下仍應遵守同一規則？

能以自己的話回答這個問題，並說出「進入 SceneTree → ready → process／physics process → 碰撞／Timer／動畫 → 狀態更新 → 離開樹」，才算完成本單元的概念閉環。
