# 序章｜我不想先成為工程師，我只想先看懂遊戲怎麼運作

本資料夾是本單元的單一交付包。正式內容來源為 `chapter_00_main.md`；DOCX 與衍生內容都必須由該 Markdown 同步生成。

## 檔案用途

- `chapter_00_main.md`：正式書稿來源。
- `chapter_00_main.docx`：閱讀與編輯版。
- `chapter_00_speech_notes.md`：NotebookLM、Podcast、演講與口語複習。
- `chapter_00_slide_outline.md`：簡報架構。
- `chapter_00_quotes.md`：章末金句。
- `chapter_00_model_canvas.md`：唯一任務、關係鏈與教學目標。
- `chapter_00_codex_prompts.md`：章內可調整的 Codex 任務指令。

## 本單元驗收句

> 在 Codex 已經能寫程式的時代，為什麼人仍需要先理解遊戲引擎？

能以自己的話回答這個問題，並說出「玩家感受 → 遊戲規則 → Godot 結構 → Runtime 執行 → AI 協作與驗證」，才算完成本單元的概念閉環。
