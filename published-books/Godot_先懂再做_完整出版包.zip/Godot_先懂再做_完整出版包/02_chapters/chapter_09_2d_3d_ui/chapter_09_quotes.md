# 第九章｜2D、3D 與 UI：三個看似不同、其實相通的空間｜章末金句

1. 2D、3D 與 UI 共享節點與場景骨架，卻遵守不同空間規則。
2. Local 說的是相對父節點，Global 說的是整條父鏈作用後的位置。
3. 世界物件追隨攝影機，HUD 應追隨螢幕與版面關係。
4. Anchor 決定相對位置，Container 決定內容如何共同排列。
5. Texture、Mesh、Material 與 Font 是資料；Sprite、MeshInstance 與 Control 才把它們放進 Runtime。
6. 從 2D 到 3D，不是把 API 全部重背，而是保留結構、補上空間。
7. 渲染方法是平台與功能的取捨，不是一個抽象畫質排行榜。
8. 多解析度不是把畫面拉大縮小，而是重新確認世界與 UI 的關係。
