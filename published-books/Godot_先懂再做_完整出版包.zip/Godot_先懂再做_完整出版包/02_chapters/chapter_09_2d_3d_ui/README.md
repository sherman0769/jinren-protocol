# 第九章｜2D、3D 與 UI：三個看似不同、其實相通的空間

本資料夾是本單元的單一交付包。正式內容來源為 `chapter_09_main.md`；DOCX 與衍生內容都必須由該 Markdown 同步生成。

## 檔案用途

- `chapter_09_main.md`：正式書稿來源。
- `chapter_09_main.docx`：閱讀與編輯版。
- `chapter_09_speech_notes.md`：NotebookLM、Podcast、演講與口語複習。
- `chapter_09_slide_outline.md`：簡報架構。
- `chapter_09_quotes.md`：章末金句。
- `chapter_09_model_canvas.md`：唯一任務、關係鏈與教學目標。
- `chapter_09_codex_prompts.md`：章內可調整的 Codex 任務指令。

## 本單元驗收句

> 2D、3D 與 UI 是三套世界，還是共享同一套結構？

能以自己的話回答這個問題，並說出「場景結構 → Local／Global Transform → 可視資源 → Camera／Viewport → 螢幕呈現；UI 另受 Anchor／Container 約束」，才算完成本單元的概念閉環。
