# 第一章｜Godot 到底是什麼：先看懂遊戲引擎的位置

本資料夾是本單元的單一交付包。正式內容來源為 `chapter_01_main.md`；DOCX 與衍生內容都必須由該 Markdown 同步生成。

## 檔案用途

- `chapter_01_main.md`：正式書稿來源。
- `chapter_01_main.docx`：閱讀與編輯版。
- `chapter_01_speech_notes.md`：NotebookLM、Podcast、演講與口語複習。
- `chapter_01_slide_outline.md`：簡報架構。
- `chapter_01_quotes.md`：章末金句。
- `chapter_01_model_canvas.md`：唯一任務、關係鏈與教學目標。
- `chapter_01_codex_prompts.md`：章內可調整的 Codex 任務指令。

## 本單元驗收句

> 當我打開 Godot 時，我其實進入了哪一層系統？

能以自己的話回答這個問題，並說出「作品 ↔ 專案來源 ← 編輯器 ← 引擎能力 ← 程式語言；版本狀態決定風險基準」，才算完成本單元的概念閉環。
