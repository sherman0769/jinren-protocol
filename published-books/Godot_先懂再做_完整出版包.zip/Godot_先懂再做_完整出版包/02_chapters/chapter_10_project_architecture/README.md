# 第十章｜從能跑到能維護：Godot 專案的架構思維

本資料夾是本單元的單一交付包。正式內容來源為 `chapter_10_main.md`；DOCX 與衍生內容都必須由該 Markdown 同步生成。

## 檔案用途

- `chapter_10_main.md`：正式書稿來源。
- `chapter_10_main.docx`：閱讀與編輯版。
- `chapter_10_speech_notes.md`：NotebookLM、Podcast、演講與口語複習。
- `chapter_10_slide_outline.md`：簡報架構。
- `chapter_10_quotes.md`：章末金句。
- `chapter_10_model_canvas.md`：唯一任務、關係鏈與教學目標。
- `chapter_10_codex_prompts.md`：章內可調整的 Codex 任務指令。

## 本單元驗收句

> 專案從「能跑」走向「能維護」，真正要改變什麼？

能以自己的話回答這個問題，並說出「單一責任 → 場景／腳本邊界 → 事件與資料所有權 → 少量跨場景服務 → 版本控制 → 小步重構」，才算完成本單元的概念閉環。
