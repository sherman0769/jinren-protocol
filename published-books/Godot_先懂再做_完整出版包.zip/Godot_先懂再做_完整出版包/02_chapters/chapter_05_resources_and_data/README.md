# 第五章｜資源、素材與資料：哪些東西應該被保存與重複使用

本資料夾是本單元的單一交付包。正式內容來源為 `chapter_05_main.md`；DOCX 與衍生內容都必須由該 Markdown 同步生成。

## 檔案用途

- `chapter_05_main.md`：正式書稿來源。
- `chapter_05_main.docx`：閱讀與編輯版。
- `chapter_05_speech_notes.md`：NotebookLM、Podcast、演講與口語複習。
- `chapter_05_slide_outline.md`：簡報架構。
- `chapter_05_quotes.md`：章末金句。
- `chapter_05_model_canvas.md`：唯一任務、關係鏈與教學目標。
- `chapter_05_codex_prompts.md`：章內可調整的 Codex 任務指令。

## 本單元驗收句

> 這個東西應該成為節點、場景、Resource，還是變數？

能以自己的話回答這個問題，並說出「Asset 匯入 → Resource 保存設計資料 → Scene 保存結構 → Node 執行行為 → 變數保存實例狀態 → user:// 保存持久資料」，才算完成本單元的概念閉環。
