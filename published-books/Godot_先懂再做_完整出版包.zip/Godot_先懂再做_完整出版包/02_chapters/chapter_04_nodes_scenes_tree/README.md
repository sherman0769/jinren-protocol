# 第四章｜場景、節點與樹：Godot 最重要的語法

本資料夾是本單元的單一交付包。正式內容來源為 `chapter_04_main.md`；DOCX 與衍生內容都必須由該 Markdown 同步生成。

## 檔案用途

- `chapter_04_main.md`：正式書稿來源。
- `chapter_04_main.docx`：閱讀與編輯版。
- `chapter_04_speech_notes.md`：NotebookLM、Podcast、演講與口語複習。
- `chapter_04_slide_outline.md`：簡報架構。
- `chapter_04_quotes.md`：章末金句。
- `chapter_04_model_canvas.md`：唯一任務、關係鏈與教學目標。
- `chapter_04_codex_prompts.md`：章內可調整的 Codex 任務指令。

## 本單元驗收句

> 節點、場景與場景樹到底是三個東西，還是同一條生命週期？

能以自己的話回答這個問題，並說出「Node → 父子樹 → Scene／PackedScene → Instance → Runtime SceneTree」，才算完成本單元的概念閉環。
