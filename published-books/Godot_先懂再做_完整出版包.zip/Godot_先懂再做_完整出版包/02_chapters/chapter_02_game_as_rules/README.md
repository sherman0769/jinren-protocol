# 第二章｜遊戲不是畫面，而是一套持續運轉的規則

本資料夾是本單元的單一交付包。正式內容來源為 `chapter_02_main.md`；DOCX 與衍生內容都必須由該 Markdown 同步生成。

## 檔案用途

- `chapter_02_main.md`：正式書稿來源。
- `chapter_02_main.docx`：閱讀與編輯版。
- `chapter_02_speech_notes.md`：NotebookLM、Podcast、演講與口語複習。
- `chapter_02_slide_outline.md`：簡報架構。
- `chapter_02_quotes.md`：章末金句。
- `chapter_02_model_canvas.md`：唯一任務、關係鏈與教學目標。
- `chapter_02_codex_prompts.md`：章內可調整的 Codex 任務指令。

## 本單元驗收句

> 遊戲的本體是畫面，還是持續運轉的規則？

能以自己的話回答這個問題，並說出「輸入 → 規則判斷 → 狀態改變 → 輸出呈現 → 下一輪」，才算完成本單元的概念閉環。
