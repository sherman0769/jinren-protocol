# 第十二章｜完成、匯出與教學：把一次開發變成可複製的方法

本資料夾是本單元的單一交付包。正式內容來源為 `chapter_12_main.md`；DOCX 與衍生內容都必須由該 Markdown 同步生成。

## 檔案用途

- `chapter_12_main.md`：正式書稿來源。
- `chapter_12_main.docx`：閱讀與編輯版。
- `chapter_12_speech_notes.md`：NotebookLM、Podcast、演講與口語複習。
- `chapter_12_slide_outline.md`：簡報架構。
- `chapter_12_quotes.md`：章末金句。
- `chapter_12_model_canvas.md`：唯一任務、關係鏈與教學目標。
- `chapter_12_codex_prompts.md`：章內可調整的 Codex 任務指令。

## 本單元驗收句

> 什麼時候作品才算完成，而且這套能力已經能被教出去？

能以自己的話回答這個問題，並說出「錯誤證據 → Remote／Profiler → Git → Export Preset／Templates → 目標平台實測 → 交付矩陣 → 教學轉譯」，才算完成本單元的概念閉環。
