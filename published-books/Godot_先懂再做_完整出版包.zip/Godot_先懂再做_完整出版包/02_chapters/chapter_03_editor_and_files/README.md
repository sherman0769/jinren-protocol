# 第三章｜打開 Godot 之後：專案、編輯器與檔案正在做什麼

本資料夾是本單元的單一交付包。正式內容來源為 `chapter_03_main.md`；DOCX 與衍生內容都必須由該 Markdown 同步生成。

## 檔案用途

- `chapter_03_main.md`：正式書稿來源。
- `chapter_03_main.docx`：閱讀與編輯版。
- `chapter_03_speech_notes.md`：NotebookLM、Podcast、演講與口語複習。
- `chapter_03_slide_outline.md`：簡報架構。
- `chapter_03_quotes.md`：章末金句。
- `chapter_03_model_canvas.md`：唯一任務、關係鏈與教學目標。
- `chapter_03_codex_prompts.md`：章內可調整的 Codex 任務指令。

## 本單元驗收句

> Godot 編輯器看見的內容，和硬碟裡的檔案如何對應？

能以自己的話回答這個問題，並說出「專案根目錄 → project.godot／場景／腳本／資源／素材 → 編輯器視圖 → 匯入快取 → Runtime Remote 樹」，才算完成本單元的概念閉環。
