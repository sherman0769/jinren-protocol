# Research Registry｜研究來源登錄

- **研究查閱基準日**：2026-07-12
- **技術基準**：Godot 4.7 Stable
- **使用原則**：優先採官方網站、官方文件、官方 GitHub；正式正文只吸收與讀者任務直接相關的事實，不堆疊資料。

| ID | 來源 | 發布／狀態 | 支持章節 | 支持觀點 | 限制與更新提醒 |
|---|---|---|---|---|---|
| R01 | Godot download archive — https://godotengine.org/download/archive/ | 2026-07-12 查閱 | 全書版本基準 | 4.7 Stable 於 2026-06-18；4.7.1 RC2、4.8 dev1 為預發布 | 發布狀態變動快，再版必查 |
| R02 | Godot 4.7 – Lights, Camera, Action! — https://godotengine.org/article/godot-4-7-lights-camera-action/ | 2026-06-18 | 1、3、9、12 | 4.7 正式版與主要改進 | 新功能細節只作版本背景，不取代概念教學 |
| R03 | Godot 4.7.1 RC2 — https://godotengine.org/article/release-candidate-godot-4-7-1-rc-2/ | 2026-07-09，Pre-release | 1、研究註記 | 候選版主要修正回歸問題 | 不作正式教學基準 |
| R04 | Godot 4.8 dev1 — https://godotengine.org/article/dev-snapshot-godot-4-8-dev-1/ | 2026-07-06，Pre-release | 1、結語 | 4.8 尚在開發快照 | 不把快照功能寫成承諾 |
| R05 | Godot Docs 4.7 branch — https://docs.godotengine.org/ | Stable docs | 全書 | 官方穩定文件分支為 4.7 | 介面與平台設定再版需重查 |
| R06 | Godot homepage — https://godotengine.org/ | 2026-07-12 查閱 | 1 | 自由、開源、2D／3D、跨平台 | 宣傳語不作效能證據 |
| R07 | Godot Features — https://godotengine.org/features/ | 2026-07-12 查閱 | 1、4 | 以節點建立可重用場景，強調組合與階層 | 功能頁是產品概覽，細節仍回官方文件 |
| R08 | Node class — https://docs.godotengine.org/en/stable/classes/class_node.html | 4.7 stable docs | 4、8 | Node 是 building block；節點樹形成場景；進入樹與 ready 順序 | 類別頁資訊密集，正文只取必要部分 |
| R09 | Nodes and Scenes — https://docs.godotengine.org/en/stable/getting_started/step_by_step/nodes_and_scenes.html | 4.7 stable docs | 4 | 場景與節點的入門心智模型 | 不把入門範例寫成唯一架構方式 |
| R10 | SceneTree — https://docs.godotengine.org/en/stable/classes/class_scenetree.html | 4.7 stable docs | 2、4、7、8 | 管理活動節點樹與主迴路、群組操作 | API 細節版本敏感 |
| R11 | PackedScene — https://docs.godotengine.org/en/stable/classes/class_packedscene.html | 4.7 stable docs | 4、5 | 場景檔在資料層也是一種 Resource，可實例化 | ownership 細節超出初階主線時不展開 |
| R12 | Resources — https://docs.godotengine.org/en/stable/tutorials/scripting/resources.html | 4.7 stable docs | 5、10 | Resource 是資料容器，可自動序列化、存成 tres/res | 共用資源行為需在實作中驗證 |
| R13 | Resource class — https://docs.godotengine.org/en/stable/classes/class_resource.html | 4.7 stable docs | 5 | 資源、引用與複製等基礎 | 只講有助資料設計的部分 |
| R14 | GDScript basics — https://docs.godotengine.org/en/stable/tutorials/scripting/gdscript/gdscript_basics.html | 4.7 stable docs | 6 | 高階、物件導向、命令式、逐步型別語言 | 語法教材不是本書主體 |
| R15 | Scripting languages — https://docs.godotengine.org/en/stable/getting_started/step_by_step/scripting_languages.html | 4.7 stable docs | 1、6 | 官方支援 GDScript、C#，並可透過 GDExtension 使用 C/C++ | 各平台語言支援可能改變 |
| R16 | Using signals — https://docs.godotengine.org/en/stable/getting_started/step_by_step/signals.html | 4.7 stable docs | 7 | Signal 是事件訊息，可降低物件直接參照與耦合 | 不將所有溝通都改成 signal |
| R17 | Groups — https://docs.godotengine.org/en/stable/tutorials/scripting/groups.html | 4.7 stable docs | 7、10 | 群組可作標籤，SceneTree 可批次尋找或呼叫 | 群組不是完整型別系統 |
| R18 | Input examples — https://docs.godotengine.org/en/stable/tutorials/inputs/input_examples.html | 4.7 stable docs | 7 | Input Map、事件式與輪詢式輸入 | 裝置差異需依目標平台測試 |
| R19 | Idle and Physics Processing — https://docs.godotengine.org/en/stable/tutorials/scripting/idle_and_physics_processing.html | 4.7 stable docs | 2、8 | `_process()`、`_physics_process()` 與 delta | 物理更新頻率可配置，不硬寫單一數值 |
| R20 | CharacterBody2D — https://docs.godotengine.org/en/stable/classes/class_characterbody2d.html | 4.7 stable docs | 8 | 適合由使用者控制的 2D 角色移動 | 具體 API 仍需查類別頁 |
| R21 | Using AnimationTree — https://docs.godotengine.org/en/stable/tutorials/animation/animation_tree.html | 4.7 stable docs | 8 | 動畫混合與狀態控制概念 | 初學書只建立角色，不深入所有節點 |
| R22 | Project Manager — https://docs.godotengine.org/en/stable/tutorials/editor/project_manager.html | 4.7 stable docs | 3 | 建立、匯入、掃描與管理專案 | UI 名稱可能因版本變動 |
| R23 | Godot editor's interface — https://docs.godotengine.org/en/stable/tutorials/editor/introduction_to_the_editor_interface.html | 4.7 stable docs | 3 | Viewport、Inspector、Scene、FileSystem 等工作區 | 不做逐按鈕導覽 |
| R24 | File system — https://docs.godotengine.org/en/stable/tutorials/scripting/filesystem.html | 4.7 stable docs | 3、10 | `res://`、`user://` 與專案檔案存取 | 使用者資料路徑依平台映射 |
| R25 | Multiple resolutions — https://docs.godotengine.org/en/stable/tutorials/rendering/multiple_resolutions.html | 4.7 stable docs | 9 | UI 錨點、容器與多解析度思維 | 實際介面須多裝置測試 |
| R26 | List of features — https://docs.godotengine.org/en/stable/about/list_of_features.html | 4.7 stable docs | 1、9 | 2D、3D、UI、渲染與平台概觀 | 功能存在不等於適合所有規模 |
| R27 | Best practices: Scene organization — https://docs.godotengine.org/en/stable/tutorials/best_practices/scene_organization.html | 4.7 stable docs | 10 | 場景組織與責任分配 | 最佳實務是原則，不是強制標準 |
| R28 | Autoloads versus regular nodes — https://docs.godotengine.org/en/stable/tutorials/best_practices/autoloads_versus_internal_nodes.html | 4.7 stable docs | 10 | Autoload 的適用與濫用風險 | 專案規模不同，選擇不同 |
| R29 | Saving games — https://docs.godotengine.org/en/stable/tutorials/io/saving_games.html | 4.7 stable docs | 5、10、12 | 存檔與可保存狀態的概念 | 正式產品需另做版本遷移與安全設計 |
| R30 | Debugger panel — https://docs.godotengine.org/en/stable/tutorials/scripting/debug/debugger_panel.html | 4.7 stable docs | 11、12 | 錯誤、堆疊、監視與遠端資訊 | 介面位置版本相關 |
| R31 | The Profiler — https://docs.godotengine.org/en/stable/tutorials/scripting/debug/the_profiler.html | 4.7 stable docs | 12 | 用量測而非猜測找效能瓶頸 | 不提供通用效能門檻 |
| R32 | Version control systems — https://docs.godotengine.org/en/stable/tutorials/best_practices/version_control_systems.html | 4.7 stable docs | 3、10、12 | Godot 專案適合 VCS；`.godot/` 等應忽略 | Git 操作本身不在本書詳教 |
| R33 | Exporting projects — https://docs.godotengine.org/en/stable/tutorials/export/exporting_projects.html | 4.7 stable docs | 12 | 匯出範本、preset、資源打包與 export_presets.cfg | 各平台要求可能變動 |
| R34 | Exporting for Android — https://docs.godotengine.org/en/stable/tutorials/export/exporting_for_android.html | 4.7 stable docs | 12 | Android 工具鏈與匯出概念 | SDK、商店規範高度時效性 |
| R35 | Exporting for the Web — https://docs.godotengine.org/en/stable/tutorials/export/exporting_for_web.html | 4.7 stable docs | 12 | WebAssembly／WebGL 與瀏覽器限制 | 瀏覽器相容性需實測 |
| R36 | Command line tutorial — https://docs.godotengine.org/en/stable/tutorials/editor/command_line_tutorial.html | 4.7 stable docs | 11、12 | 命令列啟動、檢查與匯出流程 | 參數依版本與作業系統核對 |
| R37 | Godot License — https://godotengine.org/license/ | 2026-07-12 查閱 | 1、5、12 | MIT 授權、可商業使用、需包含授權文字 | 第三方素材各自有授權，不能混同 |
| R38 | Console support — https://godotengine.org/consoles/ | 2026-07-12 查閱 | 12、附錄 | 主機平台涉及平台商核准、SDK 與第三方方案 | 官方不能公開封閉平台 SDK 範本 |
| R39 | Godot Priorities — https://godotengine.org/priorities/ | 2026-07-12 查閱 | 1、結語 | priorities 是方向與願望清單，不是交付承諾 | 未發布功能不得寫成確定時程 |
| R40 | Upgrading from 4.6 to 4.7 — https://docs.godotengine.org/en/stable/tutorials/migrating/upgrading_to_godot_4.7.html | 4.7 stable docs | 1、12 | 升級可能有破壞性變更，應查遷移指南 | 再版需新增後續升級指南 |
| R41 | OpenAI Codex — https://openai.com/codex/ | 2026-07-12 查閱 | 11、12、附錄 | Codex 可協助撰寫、審查與交付程式工作 | 產品能力與介面持續更新，再版必查 |
| R42 | Codex CLI — https://developers.openai.com/codex/cli | 2026-07-12 查閱 | 3、11、附錄 | 可在選定目錄中檢查、編輯並執行程式工作，需依權限模式控制 | 指令與權限選項可能更新 |
| R43 | Codex quickstart — https://developers.openai.com/codex/quickstart | 2026-07-12 查閱 | 11、附錄 | 建立任務、檢視變更、執行檢查與使用代理模式的基本流程 | 介面名稱依產品更新 |
| R44 | Codex developer overview — https://developers.openai.com/codex | 2026-07-12 查閱 | 11、附錄 | Codex 產品與開發者文件入口 | 只使用官方文件，不推測未發布功能 |
| R45 | Using Codex with your ChatGPT plan — https://help.openai.com/en/articles/11369540-using-codex-with-your-chatgpt-plan | 2026-07-12 查閱 | 11 | ChatGPT 方案中的 Codex 使用與工作表面 | 方案與配額高度時效性，正文不寫固定數字 |

## 研究判讀規則

1. 官方產品頁用於定位與版本；類別頁與教學頁用於技術細節。
2. `stable` 文件在本次查閱時對應 4.7；未來若 stable 指向新版，應切換到固定版本網址重新校對。
3. RC、beta、dev 都標記為預發布；可以觀察，不作本書正式 API 基準。
4. Godot Priorities 只代表方向，不代表日期、版本或完成承諾。
5. AI 生成素材的授權取決於素材來源、模型條款、訓練資料與發布平台規則，本書只提醒風險，不提供法律結論。
