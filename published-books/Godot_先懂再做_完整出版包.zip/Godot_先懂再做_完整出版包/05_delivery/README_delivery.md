# 交付入口與使用方式

## 最快閱讀

- 完整書：`01_master/full_book.docx`
- 完整 Markdown：`01_master/full_book.md`
- 逐章 Podcast／演講素材：`02_chapters/chapter_XX_*/chapter_XX_speech_notes.md`
- 逐章獨立交付：`05_delivery/chapter_zips/`

## 研究與維護

- 官方來源登錄：`03_research/research_registry.md`
- 事實校正：`03_research/fact_check_notes.md`
- 書籍核心基準：`00_project/book_bible.md`
- 術語一致性：`00_project/terminology_registry.md`

## 品質與驗證

- 全書品質報告：`04_quality/QA_REPORT.md`
- 字數報告：`04_quality/word_count_report.md`
- 重複檢查：`04_quality/duplication_check.md`
- ZIP 與檔案驗證：`05_delivery/delivery_verification.md`
- 檔案大小與 SHA-256：`05_delivery/delivery_manifest.txt`

## 修改原則

正式內容先修改各單元的 `chapter_XX_main.md`，再重新合併 `full_book.md` 並生成 DOCX 與衍生內容。版本、介面、平台匯出與 Codex 功能屬於可能變動資訊，再版前必須重新查證。
