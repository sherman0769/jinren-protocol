# QA REPORT｜全書品質驗收報告

- **書名**：《先懂再做：用 Godot 建立遊戲開發的全局觀》
- **作者**：李詩民
- **版本**：V1.0
- **技術基準**：Godot 4.7 Stable
- **研究查閱日期**：2026-07-12

## 一、內容與定位

- [x] 核心主張清楚：先理解遊戲運作與 Godot 結構，再讓 Codex 翻譯成程式碼。
- [x] 12 章各有唯一任務，序章建立學習契約，結語完成知識遷移，附錄提供工作工具。
- [x] 主要讀者是從零建立全局觀、以聆聽內化並需要教學轉譯的作者本人及相近讀者。
- [x] 共同案例「能量收集者」明確標示為概念樣板，不虛構作者實戰成果。
- [x] 五層全局模型、五問導航法、八格規格單明確標示為本書工作概念，不冒充 Godot 官方標準。

## 二、技術與研究

- [x] 版本基準已由 Godot 官方下載封存、4.7 發布頁與 stable docs 校正。
- [x] 4.7.1 RC2 與 4.8 dev1 只列為預發布觀察，不混入正式 API 基準。
- [x] Node、Scene、Resource、Signal、Input、生命週期、物理、UI、Autoload、存檔、除錯、匯出與授權均登錄官方來源。
- [x] Codex 內容只採 OpenAI 官方產品與開發者文件；未寫死易變動方案配額。
- [x] 平台、介面、版本與工具鏈敏感內容均附再版查核提醒。

## 三、寫作與聆聽

- [x] 術語第一次出現時以中文解釋並保留英文定位。
- [x] 每章具口語概念地圖、自我檢查、章末金句與教學轉譯。
- [x] 程式碼只用於概念具體化，沒有把正文寫成逐行語法手冊。
- [x] 各章可獨立聆聽，必要前置概念以短句補回。
- [x] 正式來源中文字數 75,248，通過 75,000–90,000 目標。
- [x] 重複檢查完成：完全相同段落組 0；高相似候選 0。

## 四、檔案與衍生內容

- [x] 正式 Markdown 單元：15。
- [x] 單元 DOCX：15；完整 DOCX：1。
- [x] 每單元均包含 Podcast／演講筆記、簡報大綱、金句、模型畫布、Codex 指令與 README。
- [x] `full_book.md` 由正式章節來源合併；DOCX 由 Markdown 生成。

## 五、DOCX 渲染與版面

- [x] 完整書 DOCX 已渲染為 129 頁。
- [x] 15 個單元 DOCX 共渲染為 127 頁。
- [x] 已檢查封面、目錄、章首、內文、長標題、程式碼、引言框、網址索引、附錄與頁首頁尾。
- [x] 自動邊界／空白頁掃描異常數：0。

| 單元 | DOCX 頁數 | DOCX bytes |
|---|---:|---:|
| chapter_00_preface | 4 | 44,767 |
| chapter_01_engine_position | 6 | 47,299 |
| chapter_02_game_as_rules | 6 | 47,155 |
| chapter_03_editor_and_files | 7 | 48,367 |
| chapter_04_nodes_scenes_tree | 8 | 48,781 |
| chapter_05_resources_and_data | 7 | 48,463 |
| chapter_06_reading_gdscript | 8 | 49,668 |
| chapter_07_input_signals_state | 7 | 48,680 |
| chapter_08_lifecycle_physics_animation | 8 | 49,198 |
| chapter_09_2d_3d_ui | 7 | 48,154 |
| chapter_10_project_architecture | 8 | 48,814 |
| chapter_11_codex_collaboration | 9 | 50,711 |
| chapter_12_delivery_and_teaching | 9 | 50,261 |
| chapter_13_conclusion | 4 | 44,900 |
| chapter_14_appendices | 29 | 73,936 |

## 六、待作者確認與再版項目

- [ ] 作者完成實際「能量收集者」專案後，可補入經確認的開發決策、錯誤與教學現場；目前不虛構。
- [ ] Godot 4.7.1 Stable 或後續穩定版發布後，更新版本註記並重新檢查平台／介面敏感段落。
- [ ] 正式商業出版前，另由出版端處理 ISBN、封面視覺、紙本版型、法律聲明與校對流程。

## 七、ZIP、manifest 與交付判定

- [x] 15 個單元 ZIP 均通過 CRC 測試。
- [x] 15 個單元 ZIP 均完成實際解壓，逐檔 SHA-256 與來源資料夾一致。
- [x] 完整出版包 ZIP 通過 CRC 與路徑安全檢查。
- [x] 完整出版包 ZIP 完成實際解壓，逐檔大小與 SHA-256 與交付資料夾一致。
- [x] `delivery_manifest.txt` 已列出除自身外的全部交付檔案、大小與 SHA-256。
- [x] ZIP 內無舊版暫存檔、QA 渲染圖片或總 ZIP 自我嵌套。

**最終判定：通過，專案狀態為 `DELIVERED`。**
