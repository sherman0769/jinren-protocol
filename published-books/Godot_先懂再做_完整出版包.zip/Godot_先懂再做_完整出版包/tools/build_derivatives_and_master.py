from __future__ import annotations
from pathlib import Path
import re
from collections import OrderedDict

ROOT=Path('/mnt/data/Godot_先懂再做_完整出版包')
CHROOT=ROOT/'02_chapters'
MASTER=ROOT/'01_master'
MASTER.mkdir(parents=True, exist_ok=True)

meta=OrderedDict([
('chapter_00_preface', dict(
    num='00', label='序章',
    question='在 Codex 已經能寫程式的時代，為什麼人仍需要先理解遊戲引擎？',
    answer='因為 AI 能生產程式碼，卻不能替人決定作品意圖、系統邊界與驗收證據；學習的核心是建立可遷移的全局模型。',
    chain='玩家感受 → 遊戲規則 → Godot 結構 → Runtime 執行 → AI 協作與驗證',
    before='把學習 Godot 想成先背語法、找按鈕與照抄範例。',
    after='能以五層全局模型定位每個概念，知道本書該如何聽、如何用。',
    misconceptions='AI 能寫就不需要理解；只要能跑就算完成；學習必須從語法細節開始。',
    bridge='序章先建立共同地圖，第一章才把 Godot 放回整個遊戲開發系統中。',
    objectives=['說明本書為何採概念關聯與知識遷移路線','口述五層全局模型','區分 AI 產碼能力與人類規格／驗證責任'])),
('chapter_01_engine_position', dict(
    num='01', label='第一章',
    question='當我打開 Godot 時，我其實進入了哪一層系統？',
    answer='你在編輯器中使用遊戲引擎與程式語言，修改專案來源，最後產生玩家使用的作品。',
    chain='作品 ↔ 專案來源 ← 編輯器 ← 引擎能力 ← 程式語言；版本狀態決定風險基準',
    before='把 Godot、GDScript、編輯器與遊戲成品混成同一件事。',
    after='能分辨工具層次、版本狀態與 Godot 的適用定位。',
    misconceptions='Godot 就是 GDScript；最新版本一定最適合；Priorities 等於承諾 Roadmap。',
    bridge='知道引擎的位置後，第二章會先於工具細節重新定義遊戲本身。',
    objectives=['區分遊戲、引擎、編輯器、語言與專案','理解 Stable／RC／Beta／Dev 的風險差異','在有條件的前提下比較 Godot、Unity 與 Unreal'])),
('chapter_02_game_as_rules', dict(
    num='02', label='第二章',
    question='遊戲的本體是畫面，還是持續運轉的規則？',
    answer='遊戲是輸入經規則改變狀態，再由畫面、聲音與介面呈現結果的循環系統。',
    chain='輸入 → 規則判斷 → 狀態改變 → 輸出呈現 → 下一輪',
    before='從畫面效果或單一功能開始想遊戲。',
    after='能把互動描述成狀態、規則、時間與迴路。',
    misconceptions='畫面更新就是遊戲迴路；幀率越高遊戲就應越快；事件與持續更新互斥。',
    bridge='理解規則迴路後，第三章會把這些抽象規則對應到專案與檔案。',
    objectives=['用輸入—規則—狀態—輸出描述遊戲','區分編輯階段與 Runtime','解釋 delta、顯示更新與物理更新的基本角色'])),
('chapter_03_editor_and_files', dict(
    num='03', label='第三章',
    question='Godot 編輯器看見的內容，和硬碟裡的檔案如何對應？',
    answer='編輯器是專案來源的視覺入口；執行後的 Remote 場景樹則是來源被載入與實例化後的 Runtime 真相。',
    chain='專案根目錄 → project.godot／場景／腳本／資源／素材 → 編輯器視圖 → 匯入快取 → Runtime Remote 樹',
    before='把編輯器當黑盒，或認為文字檔可以任意由 AI 大量改寫。',
    after='能辨識主要檔案、工作區、res://、user://、Local 與 Remote。',
    misconceptions='.godot 是正式內容；Runtime 變更會自動寫回；所有產生檔都應進版本控制。',
    bridge='檔案邊界清楚後，第四章將建立 Godot 最核心的節點與場景模型。',
    objectives=['辨認 Godot 編輯器主要工作區','解釋 project.godot、.tscn、.gd、.tres、.godot 的角色','建立 Codex 修改專案的安全協議'])),
('chapter_04_nodes_scenes_tree', dict(
    num='04', label='第四章',
    question='節點、場景與場景樹到底是三個東西，還是同一條生命週期？',
    answer='節點是責任單元，節點樹保存為場景，場景被實例化後進入活動 SceneTree 並開始生命週期。',
    chain='Node → 父子樹 → Scene／PackedScene → Instance → Runtime SceneTree',
    before='把 Node 當成畫面物件，把 Scene 當成關卡檔。',
    after='能以組合、實例、所有權與對外介面設計可重用場景。',
    misconceptions='所有節點都會顯示；父子只有資料夾作用；場景越碎越模組化。',
    bridge='有了結構模型後，第五章要回答哪些內容應保存為可重用資料。',
    objectives=['解釋 Node、Scene、PackedScene、Instance、SceneTree','辨識父子關係的組織／生命週期／Transform 意義','為能量收集者畫出合理場景樹'])),
('chapter_05_resources_and_data', dict(
    num='05', label='第五章',
    question='這個東西應該成為節點、場景、Resource，還是變數？',
    answer='依是否需要進入 SceneTree、是否是可重用結構、是否是可保存共享資料，以及是否只是當下狀態來判斷。',
    chain='Asset 匯入 → Resource 保存設計資料 → Scene 保存結構 → Node 執行行為 → 變數保存實例狀態 → user:// 保存持久資料',
    before='把數值、素材、狀態與存檔全部塞進腳本。',
    after='能分清設定、內容、Runtime 狀態與持久存檔。',
    misconceptions='Resource 只是素材；同一資源每次載入都是獨立複本；Godot MIT 代表所有素材都自由使用。',
    bridge='資料和結構分清楚後，第六章才有穩定脈絡閱讀 GDScript。',
    objectives=['區分 Asset、Resource、Scene、Node 與變數','理解共享 Resource 的副作用','建立資料驅動與素材授權檢查習慣'])),
('chapter_06_reading_gdscript', dict(
    num='06', label='第六章',
    question='不先背完 GDScript，最低限度要看懂什麼？',
    answer='先辨認腳本屬於誰、擁有什麼資料、在哪個生命週期被呼叫、依賴誰，以及會改變什麼。',
    chain='extends／腳本責任 → 變數與型別 → 生命週期入口 → 方法與條件 → 外部引用／Signal → 副作用與風險',
    before='從第一行逐字翻譯，卻不知道腳本的整體責任。',
    after='能用七步順序閱讀 Codex 產生的 GDScript。',
    misconceptions='能跑就代表型別與責任合理；@onready 沒有耦合；await 只是停一下。',
    bridge='能閱讀行為後，第七章會處理行為之間如何傳遞輸入、事件與狀態。',
    objectives=['理解 extends、變數、型別、函式與生命週期','解釋 @export、@onready、Signal、await 的角色','用固定七步法審查 AI 產生腳本'])),
('chapter_07_input_signals_state', dict(
    num='07', label='第七章',
    question='遊戲物件如何互相溝通，又不彼此綁死？',
    answer='輸入先轉成語意動作；明確命令可直接呼叫；事件以 Signal 通知；資料由明確所有者保存；狀態限制當下可發生的行為。',
    chain='裝置輸入 → Input Map → 行為命令 → Signal 事件 → 狀態所有者更新資料 → UI／其他系統反應',
    before='讓 Pickup 直接找 HUD，或讓每個物件知道所有其他物件。',
    after='能分畫 Event Flow、Data Flow 與狀態轉換。',
    misconceptions='所有溝通都應使用 Signal；Group 是全域變數；狀態機一定要先做成大型框架。',
    bridge='溝通關係建立後，第八章將把這些事件放進真正的時間與物理流程。',
    objectives=['區分 Input Map、輪詢、事件與直接呼叫','設計低耦合 Signal 鏈','辨識資料所有者與最小狀態機'])),
('chapter_08_lifecycle_physics_animation', dict(
    num='08', label='第八章',
    question='角色為什麼會動，而且在不同幀率下仍應遵守同一規則？',
    answer='節點依生命週期進入更新；物理在固定節奏處理，速度以時間為基準，碰撞與動畫各有責任與狀態邊界。',
    chain='進入 SceneTree → ready → process／physics process → 碰撞／Timer／動畫 → 狀態更新 → 離開樹',
    before='把所有行為都塞進每幀更新，或用固定每幀位移。',
    after='能口述一幀的時間線，並檢查碰撞、delta、等待與重入。',
    misconceptions='_ready 與 _enter_tree 相同；delta 能修正所有時間問題；畫面輪廓就是碰撞形狀。',
    bridge='掌握時間後，第九章把相同結構遷移到 2D、3D 與 UI 三種空間。',
    objectives=['區分主要生命週期方法','理解 delta、Body、Area、Layer、Mask','驗證動畫、Timer 與非同步的狀態風險'])),
('chapter_09_2d_3d_ui', dict(
    num='09', label='第九章',
    question='2D、3D 與 UI 是三套世界，還是共享同一套結構？',
    answer='三者共享節點、場景、資源、腳本與訊號，但採不同 Transform、相機、渲染與版面規則。',
    chain='場景結構 → Local／Global Transform → 可視資源 → Camera／Viewport → 螢幕呈現；UI 另受 Anchor／Container 約束',
    before='把 UI 當作另一張 2D 貼圖，把 3D 當成只多一個座標。',
    after='能分辨空間、相機、顯示資源與響應式 UI 的責任。',
    misconceptions='固定座標能適應所有螢幕；Camera 移動會改變世界物件；某個 Renderer 永遠最好。',
    bridge='空間模型完成後，第十章會處理規模增加時如何保持可維護。',
    objectives=['理解 2D／3D／UI 的共同核心與差異','解釋 Local／Global、Camera、Sprite／Mesh／Material','用 Anchor 與 Container 設計多解析度 UI'])),
('chapter_10_project_architecture', dict(
    num='10', label='第十章',
    question='專案從「能跑」走向「能維護」，真正要改變什麼？',
    answer='用責任、所有權、低耦合、資料分層、版本化存檔與可回退重構，使變更可定位、可驗收。',
    chain='單一責任 → 場景／腳本邊界 → 事件與資料所有權 → 少量跨場景服務 → 版本控制 → 小步重構',
    before='用巨大 GameManager、長 NodePath 與全域狀態把功能接在一起。',
    after='能依規模設計邊界，並以受控重構改善結構。',
    misconceptions='檔案越多越模組化；Autoload 是共享資料垃圾桶；重構就是重寫。',
    bridge='架構邊界建立後，第十一章才能把 Codex 放進受控工程迴路。',
    objectives=['辨識耦合、責任與所有權','正確使用 Autoload、GameManager 與存檔版本','規劃可驗收、可回退的重構步驟'])),
('chapter_11_codex_collaboration', dict(
    num='11', label='第十一章',
    question='如何讓 Codex 成為受控協作者，而不是自由發揮的程式產生器？',
    answer='先讓它讀取事實，再以八格規格單限制唯一目標，要求小步修改、真實檢查、差異回報與回退點。',
    chain='讀取專案 → 釐清事實／未知 → 八格規格 → 計畫 → 最小修改 → Godot／測試檢查 → 人工驗收 → 回報與 checkpoint',
    before='用一句模糊願望要求 AI 一次完成整個功能。',
    after='能建立版本、權限、驗收與回退都清楚的代理協作迴路。',
    misconceptions='計畫等於完成；Codex 說測過就必然測過；權限越高效率越好。',
    bridge='有了協作方法，第十二章要把結果推進到除錯、平台匯出、交付與教學。',
    objectives=['使用八格規格單撰寫任務','要求 Codex 區分事實、推論、建議與未測項','建立 Git checkpoint、權限與 API 幻覺防線'])),
('chapter_12_delivery_and_teaching', dict(
    num='12', label='第十二章',
    question='什麼時候作品才算完成，而且這套能力已經能被教出去？',
    answer='完成需要可重現的除錯、測試、匯出、授權與文件證據；能教需要把概念拆成目標、示範、練習、驗收與回教。',
    chain='錯誤證據 → Remote／Profiler → Git → Export Preset／Templates → 目標平台實測 → 交付矩陣 → 教學轉譯',
    before='把本機能跑或 Export 成功視為完整交付。',
    after='能建立平台驗收矩陣與六段教學閉環。',
    misconceptions='無錯誤訊息就沒有 Bug；效能靠直覺；AI 產生講義就等於學員會了。',
    bridge='完成交付後，結語會把 Godot 的心智模型遷移回更廣泛的系統與 AI 架構。',
    objectives=['使用 Debugger、Remote 樹與 Profiler 蒐集證據','理解 Windows／Web／Android 匯出的不同風險','把專案轉成可示範、可練習、可回教的課程'])),
('chapter_13_conclusion', dict(
    num='13', label='結語',
    question='學完 Godot，真正能帶走的可遷移能力是什麼？',
    answer='把複雜系統看成能力單元、可重用模組、資料、事件、狀態、Runtime 與人類監督所形成的閉環。',
    chain='Node 能力 → Scene 模組 → Resource 資料 → Signal 事件 → State 記憶 → Runtime 迴路 → 人類意圖與驗證',
    before='把完成一本書當成記住一組工具術語。',
    after='能將 Godot 模型遷移到 AI Agent、工作流、教學與其他軟體架構。',
    misconceptions='人在迴路之上就不需接觸實作；下一步一定要做更大的作品。',
    bridge='結語收束正式論證，附錄再把全書變成可查、可下指令、可教學的工作工具。',
    objectives=['口述各 Godot 核心概念的跨領域對應','重新走完五層全局模型','選擇一個最小可交付閉環作為下一步'])),
('chapter_14_appendices', dict(
    num='14', label='附錄',
    question='如何把理解轉成實作時能反覆使用的工具？',
    answer='以術語表、Codex 模板、閱讀清單、課程框架、學習路線與口語關係卡建立個人導航系統。',
    chain='遇到名詞查術語 → 開始任務用模板 → 接手專案按清單 → 備課用六堂課 → 進階選一路線 → 複習用關係卡',
    before='讀完後只留下模糊印象，實作時仍從零搜尋。',
    after='擁有可查、可複製、可教學、可隨版本更新的工作工具。',
    misconceptions='附錄只是參考資料；模板可以不經思考直接貼上；學習路線應同時進行。',
    bridge='附錄是出版包的工作層，可在未來實作與再版時持續更新。',
    objectives=['使用術語表定位概念關係','套用並改寫 Codex 指令模板','依用途選擇專案閱讀、課程與後續路線'])),
])

# find main files mapping
main_files={p.parent.name:p for p in CHROOT.glob('chapter_*/chapter_*_main.md')}

def sections(text:str):
    out=[]; current=None; buf=[]
    for line in text.splitlines():
        if line.startswith('## '):
            if current is not None: out.append((current,'\n'.join(buf).strip()))
            current=line[3:].strip(); buf=[]
        elif current is not None:
            buf.append(line)
    if current is not None: out.append((current,'\n'.join(buf).strip()))
    return out

def h2s(text:str):
    return [line[3:].strip() for line in text.splitlines() if line.startswith('## ')]

def extract_quotes(text:str):
    ss=sections(text)
    candidates=[]
    for head,body in ss:
        if '金句' in head:
            for line in body.splitlines():
                s=line.strip()
                if s.startswith('- '): candidates.append(s[2:].strip())
                elif s.startswith('> '): candidates.append(s[2:].strip())
                elif s and not s.startswith('#') and len(s)>8: candidates.append(s)
    # fallback blockquotes outside prompts, or curated sentences
    if not candidates:
        for line in text.splitlines():
            s=line.strip()
            if s.startswith('> ') and len(s)>20:
                candidates.append(s[2:].strip())
    seen=[]
    for q in candidates:
        q=re.sub(r'\*\*|`','',q).strip()
        if q not in seen: seen.append(q)
    return seen[:10]

def extract_prompts(text:str):
    prompts=[]
    lines=text.splitlines()
    in_codex=False; title=''
    cur=[]
    for line in lines:
        if line.startswith('## '):
            if in_codex and cur:
                prompts.append((title or '任務', '\n'.join(cur).strip()))
            in_codex=('交給 Codex' in line or '直接使用的' in line or 'Codex 的' in line and '任務' in line)
            title=''; cur=[]
        elif in_codex and line.startswith('### '):
            if cur:
                prompts.append((title or '任務', '\n'.join(cur).strip()))
            title=line[4:].strip(); cur=[]
        elif in_codex:
            if line.startswith('> '): cur.append(line[2:])
            elif cur and line.strip(): cur.append(line.strip())
    if in_codex and cur: prompts.append((title or '任務', '\n'.join(cur).strip()))
    # keep content that looks like prompt and remove validation paragraphs accidentally captured
    clean=[]
    for title,body in prompts:
        body=re.split(r'\n\*\*驗收',body)[0].strip()
        body=re.split(r'\n驗收',body)[0].strip()
        if len(body)>20: clean.append((title,body))
    return clean[:8]

def intro_paragraph(text:str):
    lines=[]
    for line in text.splitlines()[1:]:
        s=line.strip()
        if s.startswith('## '): break
        if s and not s.startswith('#'): lines.append(re.sub(r'\*\*|`','',s))
    return ' '.join(lines[:3])

for folder,m in meta.items():
    p=main_files[folder]
    text=p.read_text(encoding='utf-8')
    title=text.splitlines()[0].lstrip('# ').strip()
    hs=h2s(text)
    q=extract_quotes(text)
    prompts=extract_prompts(text)
    intro=intro_paragraph(text)
    # speech notes
    main_flow=[h for h in hs if '資料索引' not in h and '金句' not in h and '自我檢查' not in h][:10]
    time_slots=[]
    if main_flow:
        chunk=max(1, len(main_flow)//4)
        groups=[main_flow[i:i+chunk] for i in range(0,len(main_flow),chunk)]
        groups=groups[:5]
        mins=[('0–4 分鐘','問題與全貌'),('4–10 分鐘','核心概念一'),('10–18 分鐘','核心概念二'),('18–26 分鐘','案例與 Codex'),('26–32 分鐘','驗證、回教與收束')]
        for i,g in enumerate(groups):
            a,b=mins[min(i,len(mins)-1)]
            time_slots.append(f'- **{a}｜{b}**：'+'；'.join(g))
    speech=f'''# {title}｜Podcast／演講筆記\n\n## 本單元唯一任務\n\n{m['answer']}\n\n## 章首問題\n\n> {m['question']}\n\n## 適合聆聽的開場\n\n{intro}\n\n## 建議口述節奏\n\n'''+ '\n'.join(time_slots)+f'''\n\n## 必須說清楚的關係鏈\n\n> {m['chain']}\n\n口述時不要只念箭頭。先講每一個角色，再說前一個角色把什麼交給下一個角色；最後再倒著問，若某一層出錯，應往哪一層查證。\n\n## 三個轉場句\n\n1. 「現在我們先不要急著看程式碼，先把這個概念放回整個系統。」\n2. 「到這裡，我們已經知道它是什麼；下一步要問的是，它和誰發生關係。」\n3. 「Codex 可以替我們執行這一步，但驗收責任仍要回到人身上。」\n\n## 教學重點\n\n- 閱讀前：{m['before']}\n- 閱讀後：{m['after']}\n- 常見誤解：{m['misconceptions']}\n\n## 學習目標\n\n'''+''.join(f'- {x}\n' for x in m['objectives'])+f'''\n## Podcast 製作提醒\n\n- 英文術語第一次出現時先說中文，再補英文；之後以較自然的稱呼為主。\n- 程式碼只描述目的、入口與關鍵行，不逐字朗讀符號。\n- 每八到十分鐘重述一次目前位於「規則、結構、執行、協作驗證」中的哪一層。\n- 結尾用關係鏈與一個自我檢查問題形成認知閉環。\n\n## 與下一單元的橋接\n\n{m['bridge']}\n'''
    (p.parent/f"chapter_{m['num']}_speech_notes.md").write_text(speech,encoding='utf-8')

    # slides
    slide_topics=[]
    slide_topics.append(('本章問題',m['question']))
    slide_topics.append(('閱讀前後',f"從「{m['before']}」走向「{m['after']}」"))
    slide_topics.append(('全局位置',m['chain']))
    for h in [x for x in hs if '資料索引' not in x and '金句' not in x and '自我檢查' not in x][:6]:
        slide_topics.append((h,f'用一個關係、一個例子與一個驗收問題說明「{h}」。'))
    slide_topics.append(('能量收集者', '以共同樣板專案定位本章概念，不換案例。'))
    slide_topics.append(('Codex 協作', '只交付本章範圍內的小任務，要求版本、差異、檢查與未測項。'))
    slide_topics.append(('常見錯誤',m['misconceptions']))
    slide_topics.append(('回教與收束',m['answer']))
    slides='# '+title+'｜簡報大綱\n\n'
    for i,(st,sm) in enumerate(slide_topics,1):
        slides+=f'## 投影片 {i}｜{st}\n\n- **畫面主訊息**：{sm}\n- **口述任務**：不要把投影片念完；用本章關係鏈補足因果與例子。\n- **視覺建議**：以箭頭、樹狀關係、流程或前後對照呈現，避免密集程式碼。\n\n'
    (p.parent/f"chapter_{m['num']}_slide_outline.md").write_text(slides,encoding='utf-8')

    # quotes
    if not q:
        q=[m['answer'], '能產生結果，不等於能解釋、驗證與回退結果。', '先把關係說清楚，再讓工具替你加速。']
    quotes=f'# {title}｜章末金句\n\n'+''.join(f'{i}. {x}\n' for i,x in enumerate(q,1))
    (p.parent/f"chapter_{m['num']}_quotes.md").write_text(quotes,encoding='utf-8')

    # canvas
    canvas=f'''# {title}｜概念模型畫布\n\n| 欄位 | 內容 |\n|---|---|\n| 單元定位 | {m['label']} |\n| 唯一任務 | {m['answer']} |\n| 核心問題 | {m['question']} |\n| 核心答案 | {m['answer']} |\n| 閱讀前狀態 | {m['before']} |\n| 閱讀後狀態 | {m['after']} |\n| 關係鏈 | {m['chain']} |\n| 常見誤解 | {m['misconceptions']} |\n| 貫穿案例 | 能量收集者；只使用與本章直接相關的角色、資料與流程。 |\n| Codex 的角色 | 讀取現況、提出有限方案、修改最小單元、執行可用檢查並回報差異。 |\n| 人的驗收責任 | 確認意圖、版本、邊界、Runtime 行為、未測項與回退方式。 |\n| 與下一單元關係 | {m['bridge']} |\n\n## 學習目標\n\n'''+''.join(f'- {x}\n' for x in m['objectives'])+'''\n## 本單元不得取代的內容\n\n- 不把官方事實與本書工作模型混為一談。\n- 不以更多術語或更多檔案假裝結構成熟。\n- 不替作者虛構已完成的 Godot 專案或教學成果。\n- 不讓 Codex 的回答取代 Godot Runtime 與目標平台的實際驗證。\n'''
    (p.parent/f"chapter_{m['num']}_model_canvas.md").write_text(canvas,encoding='utf-8')

    # codex prompts
    cp=f'''# {title}｜Codex 指令表\n\n## 使用原則\n\n下列指令都必須依實際專案調整。開始前建立 Git checkpoint，先讓 Codex 讀取現況；結束時要求列出修改檔案、執行命令、檢查結果、未測項與回退方式。\n\n## 本章八格規格提示\n\n1. **版本**：Godot 4.7 Stable；標準版／.NET 版與 GDScript／C# 必須依專案填寫。\n2. **現況**：說明目前場景、腳本、錯誤與已完成行為。\n3. **唯一目標**：只處理「{m['question']}」對應的一個可驗收任務。\n4. **不可破壞事項**：保留現有可玩流程、檔名、公共介面與資料格式。\n5. **預期結構**：先提出節點、場景、資源、腳本或文件的變更圖。\n6. **預期行為**：用輸入、規則、狀態、輸出與例外描述。\n7. **驗收條件**：包含 Godot 啟動、錯誤面板、Runtime 行為與必要平台檢查。\n8. **修改回報**：列出事實、修改、命令、結果、未測項與風險。\n\n'''
    if prompts:
        for i,(pt,pb) in enumerate(prompts,1):
            cp+=f'## 指令 {i}｜{pt}\n\n> {pb.replace(chr(10), chr(10)+"> ")}\n\n'
    else:
        cp+=f'''## 指令 1｜請 Codex 只讀回教本章模型\n\n> 目前不要修改任何檔案。請閱讀專案與相關文件，依「{m['chain']}」說明每一層在本專案中的具體對應。請把已確認事實、合理推論、待查問題分開，並指出至少三個需要由 Godot Runtime 或人工驗收的項目。\n\n## 指令 2｜把本章概念轉成檢查清單\n\n> 以 Godot 4.7 Stable 為基準，根據「{m['question']}」建立一份不修改檔案的專案檢查清單。每一項包含：檢查位置、預期證據、常見失敗、可回退動作。不要把未執行的檢查標成通過。\n\n'''
    cp+='''## 回報格式\n\n- 已讀取的檔案與版本事實。\n- 建議與其理由。\n- 實際修改檔案及關鍵差異。\n- 實際執行的命令與退出狀態。\n- 已通過、失敗、未執行的驗收項目。\n- 剩餘風險與回退方式。\n'''
    (p.parent/f"chapter_{m['num']}_codex_prompts.md").write_text(cp,encoding='utf-8')

    readme=f'''# {title}\n\n本資料夾是本單元的單一交付包。正式內容來源為 `chapter_{m['num']}_main.md`；DOCX 與衍生內容都必須由該 Markdown 同步生成。\n\n## 檔案用途\n\n- `chapter_{m['num']}_main.md`：正式書稿來源。\n- `chapter_{m['num']}_main.docx`：閱讀與編輯版。\n- `chapter_{m['num']}_speech_notes.md`：NotebookLM、Podcast、演講與口語複習。\n- `chapter_{m['num']}_slide_outline.md`：簡報架構。\n- `chapter_{m['num']}_quotes.md`：章末金句。\n- `chapter_{m['num']}_model_canvas.md`：唯一任務、關係鏈與教學目標。\n- `chapter_{m['num']}_codex_prompts.md`：章內可調整的 Codex 任務指令。\n\n## 本單元驗收句\n\n> {m['question']}\n\n能以自己的話回答這個問題，並說出「{m['chain']}」，才算完成本單元的概念閉環。\n'''
    (p.parent/'README.md').write_text(readme,encoding='utf-8')

# Build master Markdown from formal sources only
front='''# 先懂再做：用 Godot 建立遊戲開發的全局觀\n\n## 從場景、節點、訊號與遊戲迴路，到指揮 Codex 完成作品\n\n**作者：李詩民**  \n**版本：V1.0**  \n**技術基準：Godot 4.7 Stable**  \n**研究查閱基準日：2026 年 7 月 12 日**\n\n---\n\n## 出版與版本說明\n\n本書以概念關聯、系統理解與知識遷移為主，不取代 Godot 官方文件。介面位置、匯出工具鏈、平台規範與開發中功能會隨版本改變；實作時應回到與專案版本相符的官方文件重新確認。\n\n全書的「五層全局模型」「五問導航法」「八格規格單」是本書提出的工作概念，用來協助讀者理解與教學，不是 Godot 官方標準。書中不宣稱作者已完成未經證實的遊戲專案、企業導入或教學成果；共同案例「能量收集者」為概念樣板。\n\n© 2026 李詩民。本出版包為 V1.0 書稿與教學衍生版本。\n\n## 目錄\n\n- 序章｜我不想先成為工程師，我只想先看懂遊戲怎麼運作\n- 第一章｜Godot 到底是什麼：先看懂遊戲引擎的位置\n- 第二章｜遊戲不是畫面，而是一套持續運轉的規則\n- 第三章｜打開 Godot 之後：專案、編輯器與檔案正在做什麼\n- 第四章｜場景、節點與樹：Godot 最重要的語法\n- 第五章｜資源、素材與資料：哪些東西應該被保存與重複使用\n- 第六章｜GDScript 不必先背，但必須看懂它在表達什麼\n- 第七章｜輸入、訊號、事件與狀態：遊戲物件如何互相溝通\n- 第八章｜每一幀發生什麼：生命週期、時間、物理與動畫\n- 第九章｜2D、3D 與 UI：三個看似不同、其實相通的空間\n- 第十章｜從能跑到能維護：Godot 專案的架構思維\n- 第十一章｜如何指揮 Codex 開發 Godot，而不是讓它自由發揮\n- 第十二章｜完成、匯出與教學：把一次開發變成可複製的方法\n- 結語｜真正要學會的不是 Godot，而是如何理解一個系統\n- 附錄｜術語、Codex 指令、專案閱讀、課程與學習路線\n\n---\n\n'''
parts=[front]
for folder,m in meta.items():
    parts.append(main_files[folder].read_text(encoding='utf-8').strip())
    parts.append('\n\n---\n\n')
full=''.join(parts).rstrip('-\n ')+'''\n\n## 全書研究說明\n\n完整來源、版本日期、支持章節、限制與再版更新提醒，收錄於 `03_research/research_registry.md` 與 `03_research/fact_check_notes.md`。正式再版時，應先更新版本敏感項目，再同步修改各章 Markdown、完整合併稿與衍生內容。\n'''
(MASTER/'full_book.md').write_text(full,encoding='utf-8')

# root readme
root_readme='''# 《先懂再做：用 Godot 建立遊戲開發的全局觀》完整出版包\n\n作者：李詩民  \n技術基準：Godot 4.7 Stable  \n研究查閱基準日：2026-07-12  \n版本：V1.0\n\n## 閱讀入口\n\n1. `01_master/full_book.docx`：完整閱讀版。\n2. `01_master/full_book.md`：全書唯一合併內容來源。\n3. `02_chapters/`：逐章正文、Podcast／演講筆記、簡報、金句、模型畫布、Codex 指令與 DOCX。\n4. `03_research/`：官方來源與事實查核。\n5. `04_quality/`：字數、重複、品質與驗證報告。\n6. `05_delivery/chapter_zips/`：各單元獨立 ZIP。\n7. `05_delivery/delivery_manifest.txt`：交付檔案、大小與 SHA-256。\n\n## 內容維護原則\n\n每章 `chapter_XX_main.md` 是正式來源；修改後先更新 Markdown，再重新生成 DOCX、全書合併稿與受影響衍生內容。版本敏感的介面、平台匯出與 Codex 功能必須重新查證。\n'''
(ROOT/'README.md').write_text(root_readme,encoding='utf-8')
print('generated derivatives and master')
