from pathlib import Path

ROOT = Path('/mnt/data/Godot_先懂再做_完整出版包')
OUT = ROOT / '02_chapters/chapter_14_appendices/chapter_14_main.md'
TERMS_OUT = ROOT / '00_project/terminology_registry.md'

terms = [
("Godot Engine", "Godot 遊戲引擎", "自由、開源、社群驅動的 2D 與 3D 遊戲引擎與工具集。", "編輯器、專案、Runtime、場景與節點。", "用來建立、測試並匯出互動作品。", "它不是一款遊戲，也不等於 GDScript。"),
("Editor", "編輯器", "開發者用來建立場景、設定屬性、編輯腳本、執行與除錯的工作環境。", "Scene Dock、Viewport、Inspector、FileSystem。", "安排專案來源並觀察 Runtime。", "編輯器畫面不是玩家最後執行的成品。"),
("Project", "專案", "以含有 project.godot 的根目錄為邊界，集合場景、腳本、資源、素材與設定。", "res://、版本控制、主場景。", "作為 Codex 與 Godot 共同工作的檔案範圍。", "專案不是單一場景，也不是匯出的執行檔。"),
("Runtime", "執行時期", "按下執行後，場景被實例化、節點進入 SceneTree 並依規則運轉的階段。", "生命週期、遊戲迴路、狀態。", "觀察動態節點、輸入、物理與事件。", "Runtime 中的變化通常不會自動寫回原始場景。"),
("Stable", "穩定版", "完成正式發布流程、適合作為一般專案基準的版本狀態。", "RC、Beta、版本遷移。", "本書以 Godot 4.7 Stable 為基準。", "穩定版不代表完全沒有錯誤。"),
("Release Candidate", "候選版", "接近正式發布、用於發現最後回歸問題的預發布版本，常縮寫為 RC。", "Stable、回歸測試。", "可用來驗證相容性，不宜無備份取代正式基準。", "RC 並不等於已經正式發布。"),
("Beta", "測試版", "功能大致成形但仍可能改動或包含較多問題的預發布階段。", "Dev Snapshot、RC。", "適合提前測試、回報問題。", "不應把 Beta 行為寫成長期穩定承諾。"),
("Dev Snapshot", "開發快照", "較早期的開發版本，用於讓社群試驗尚未穩定的功能。", "Beta、版本控制、備份。", "觀察未來方向與測試特定變更。", "最新的 dev 數字不代表最適合正式專案。"),
("MIT License", "MIT 授權", "Godot 引擎採用的寬鬆開源授權，允許個人、教育與商業使用並要求保留授權文字。", "第三方素材、外掛授權。", "發布 Godot 作品時處理引擎授權聲明。", "Godot 採 MIT 不代表專案內所有素材都自動採 MIT。"),
("Standard Build", "標準版", "以 GDScript 與 GDExtension 等為主要使用方式、不包含 .NET/C# 支援的 Godot 發行版本。", ".NET Build、GDScript。", "本書以標準版與 GDScript 為主要基準。", "標準版不是功能不足版，只是語言工具鏈不同。"),
(".NET Build", ".NET 版", "加入 C#/.NET 支援的 Godot 發行版本，需要相符 .NET 工具鏈。", "C#、Export Templates、平台支援。", "既有 C# 團隊或需要 .NET 生態時使用。", "不能假設它在所有平台與標準版的匯出能力完全相同。"),
("Renderer", "渲染器", "把場景中的幾何、材質、光線與畫面資料轉成螢幕影像的系統。", "Rendering Method、GPU、Shader。", "決定畫面功能與效能路徑。", "渲染器不是一個單純的畫質高低按鈕。"),
("Rendering Method", "渲染方法", "Godot 專案依平台與功能選擇的渲染路徑，例如 Forward+、Mobile 或 Compatibility。", "Renderer、目標平台、驅動。", "建立專案時依硬體範圍與功能做取捨。", "不能脫離平台條件宣稱某一種永遠最好。"),
("Export Template", "匯出範本", "Godot 用來為各目標平台建立成品所需的引擎範本。", "Export Preset、Godot 版本。", "匯出 Windows、Web、Android 等平台。", "版本不相符的範本可能造成匯出失敗。"),
("Export Preset", "匯出設定檔", "針對某一平台保存架構、資源、圖示、簽章等匯出選項的設定。", "export_presets.cfg、Export Template。", "讓同一專案可重複產生平台成品。", "成功建立 preset 不等於已在目標裝置驗收。"),
("Debug Build", "除錯建置", "保留較多診斷資訊、方便開發與追蹤錯誤的成品模式。", "Release Build、Debugger。", "開發測試與錯誤定位。", "Debug 表現不能直接代表正式版效能。"),
("Release Build", "發行建置", "偏向正式散布與效能的建置模式，通常較少除錯資訊。", "Debug Build、平台驗收。", "建立實際交付成品並在目標裝置測試。", "Release 檔生成成功不代表所有功能與授權都完成。"),
("Node", "節點", "Godot 的基本構成單位，每種 Node 類型代表一組責任與引擎能力。", "Scene、SceneTree、父子關係。", "組合顯示、物理、聲音、計時與 UI。", "Node 不一定可見，也不等於一張圖片。"),
("Scene", "場景", "一棵具有意義、可保存與可重複實例化的節點樹。", "Node、PackedScene、Instance。", "表示角色、物件、UI、關卡或主流程。", "Scene 不只代表完整關卡。"),
("SceneTree", "場景樹管理器", "管理 Runtime 中活動節點樹與主迴路的 Godot 類別。", "Node、生命週期、Group、暫停。", "存取當前場景、群組與全域暫停狀態。", "它不是硬碟上的單一 .tscn 檔。"),
("Main Scene", "主場景", "專案執行時最先載入的場景入口。", "project.godot、GameFlow。", "啟動主選單、遊戲流程或最上層組合。", "主場景不一定要包含所有遊戲內容。"),
("Root Node", "根節點", "一個場景最上層的節點，代表該場景對外的主要身分。", "Scene、公開介面。", "Player 可用 CharacterBody2D 作根，UI 可用 Control。", "根節點不應只依第一個方便加入的類型決定。"),
("Parent Node", "父節點", "在樹狀結構中直接擁有子節點的上層節點。", "Child Node、Transform、生命週期。", "組織子能力並影響其加入、移除與局部變換。", "父節點不必承擔所有子節點的業務邏輯。"),
("Child Node", "子節點", "隸屬於某個父節點的節點，會參與同一子樹的生命週期。", "Parent Node、local transform。", "把角色外觀、碰撞、動畫與計時組合在根節點下。", "子節點的 local position 不是世界座標。"),
("NodePath", "節點路徑", "用名稱與階層描述 SceneTree 中節點位置的路徑資料。", "get_node、$、封裝。", "取得場景內部或已知節點引用。", "長而跨場景的硬編碼路徑容易因重構失效。"),
("Instance", "實例", "依場景或類別定義建立出的具體 Runtime 個體。", "PackedScene、instantiate、狀態。", "同一 Pickup 場景可建立多個各自有位置與狀態的物件。", "修改一個實例不一定會改原始場景或其他實例。"),
("PackedScene", "封裝場景資源", "保存場景節點結構並可在程式中 instantiate 的 Resource 類型。", "Scene、Resource、Instance。", "預載子彈、敵人或關卡場景後動態建立。", "它是場景資料，不是已加入 SceneTree 的活動節點。"),
("Owner", "場景擁有者", "Node 的保存所有權資訊，決定節點是否隨某個 PackedScene 一起保存。", "Parent、PackedScene、工具腳本。", "程式化建立要永久保存的場景內容時處理。", "成為 child 不一定就自動成為場景保存內容。"),
("Composition", "組合", "以多個具有清楚責任的節點或元件共同構成更複雜角色。", "Node、Scene、元件。", "Player 由外觀、碰撞、生命與動畫組成。", "組合不是把每個變數都拆成一個節點。"),
("Inheritance", "繼承", "讓腳本或類別在既有類型能力上擴充行為的機制。", "extends、基底類別、組合。", "GDScript 腳本 extends CharacterBody2D。", "繼承不是所有重用問題的唯一解法。"),
("Encapsulation", "封裝", "透過公開方法、屬性與訊號隱藏可替換的內部細節。", "場景邊界、耦合。", "外部呼叫 Player.take_damage，而不深入修改 Timer 與動畫。", "封裝不是禁止所有互動，而是控制互動入口。"),
("Autoload", "自動載入／全域單例", "專案啟動時自動加入並可跨場景持續存在的節點或腳本。", "SceneTree、全域狀態、服務。", "管理使用者設定、音訊或遊戲流程等長生命週期責任。", "不應把所有方便取得的變數都塞進一個 Global。"),
("Group", "群組", "附加在節點上的標籤，SceneTree 可用它查找或批次呼叫一群節點。", "SceneTree、共同身分。", "標記 enemies、pickups 或 damageable。", "加入群組不會自動保證所有成員都有同一方法。"),
("Signal", "訊號", "物件在事件發生時發出的訊息，連接者可據此呼叫回應函式。", "Event、Callable、低耦合。", "Player 發出 died，HUD 或 GameFlow 各自反應。", "Signal 適合宣告事件，不是把所有直接方法呼叫全部替換。"),
("Callable", "可呼叫物件", "封裝某個可被呼叫方法及其目標的 Godot 資料型別。", "Signal、method。", "連接訊號、延遲或動態呼叫。", "Callable 有效不代表目標物件永遠仍存在。"),
("Local Scene", "本地場景視圖", "編輯器中保存與編輯的場景來源結構。", "Remote SceneTree、.tscn。", "設計節點與初始屬性。", "它不會顯示所有 Runtime 動態生成的節點。"),
("Remote SceneTree", "遠端場景樹", "遊戲執行時，編輯器顯示的實際活動節點樹。", "Runtime、除錯、Instance。", "檢查動態生成、移除、重複節點與實際屬性。", "停止遊戲後 Remote 變化不會自動保存回場景來源。"),
("Asset", "素材／資產", "從外部進入專案的圖片、音訊、字型、模型、外掛等內容與來源。", "Resource、授權、Import。", "建立作品的視覺、聲音與內容。", "素材能被 Godot 匯入，不代表使用權已經確認。"),
("Resource", "資源", "可保存、載入、共享並由 Inspector 編輯的資料容器。", "Node、Custom Resource、.tres。", "保存 Texture、AudioStream、Material 與角色設定。", "Resource 通常不需要成為 SceneTree 節點。"),
("Custom Resource", "自訂資源", "由腳本 extends Resource 所建立、具有專案語意的資料類型。", "Resource、@export、資料驅動。", "保存 CharacterStats、PickupData 或關卡設定。", "不應把每個實例的即時狀態無差別放進共用資源。"),
("Texture2D", "二維紋理資源", "保存可供 2D 顯示與 UI 使用的圖像資料。", "Sprite2D、TextureRect、Import。", "由 Sprite2D 或 Control 節點顯示圖片。", "Texture2D 是資料，不具有自己的世界位置。"),
("AudioStream", "音訊串流資源", "表示可由音訊播放節點載入與播放的聲音資料。", "AudioStreamPlayer、Import。", "播放音效、音樂與環境聲。", "它不是播放節點，單獨 Resource 不會自己發聲。"),
("Material", "材質", "描述表面如何被渲染的資源，可引用 Shader 與紋理。", "Mesh、Shader、共享 Resource。", "控制 2D 或 3D 物件顏色、光照與特效。", "修改共用 Material 可能讓所有引用實例一起變化。"),
("Shader", "著色器", "在圖形管線中運算像素、頂點或其他視覺效果的程式。", "Material、Renderer、GPU。", "建立溶解、描邊、水波或自訂光影。", "Shader 能做特效，不代表所有遊戲規則都應放進 GPU。"),
("Theme", "介面主題資源", "集中定義 Control 節點的字型、顏色、樣式盒與其他 UI 外觀。", "Control、Font、StyleBox。", "讓多個按鈕與面板維持一致設計。", "修改共用 Theme 會影響所有使用者，單一例外要另行覆寫。"),
(".tres", "文字資源檔", "Godot 可讀、較適合版本控制的文字格式 Resource 檔。", "Resource、Custom Resource、Git。", "保存角色資料、Theme、材質與其他資源。", "文字可讀不代表適合無限制整檔重寫。"),
(".res", "二進位資源檔", "Godot 的二進位 Resource 格式，通常較不適合人工差異審查。", "Resource、.tres。", "保存或匯出時使用二進位資源。", "它不是一般文字檔，不能期待 Codex 直接安全編輯。"),
(".tscn", "文字場景檔", "以文字形式保存場景節點、屬性與資源引用的檔案。", "Scene、PackedScene、Git。", "作為可版本控制的正式場景來源。", "複雜 .tscn 含 ID 與引用，整份重寫可能遺失關係。"),
("project.godot", "專案設定檔", "Godot 專案根目錄的入口與專案層級設定檔。", "Project Settings、Input Map、Main Scene。", "保存應用名稱、主場景、輸入與渲染等設定。", "它不是整個遊戲，也不應為加一項設定而整份覆寫。"),
("res://", "專案資源根路徑", "指向目前 Godot 專案根目錄的虛擬路徑前綴。", "Project、ResourceLoader、檔案引用。", "以可攜相對路徑引用場景、腳本與素材。", "它不是電腦上固定的絕對磁碟路徑。"),
("user://", "使用者資料路徑", "指向應用在目前平台可寫入之使用者資料位置的虛擬路徑。", "Save Data、偏好設定。", "保存存檔、設定與執行後產生資料。", "它在各作業系統的實際路徑不同。"),
(".godot/", "Godot 快取目錄", "保存匯入快取與編輯器產生中間資料的可重建目錄。", "Import、Git ignore。", "加速資源匯入與編輯工作。", "通常不應當成正式來源提交或讓 Codex 直接維護。"),
("Import", "匯入", "Godot 將外部素材轉成引擎可使用資料與快取的流程。", "Asset、Resource、.godot。", "設定圖片篩選、音訊循環、模型選項。", "原始素材、匯入設定與 Runtime 資源是不同層次。"),
("GDScript", "Godot 腳本語言", "與 Godot 深度整合、支援物件導向與逐步型別的高階腳本語言。", "Node、Resource、Signal。", "撰寫遊戲規則、工具與場景行為。", "學 Godot 不等於只背 GDScript 語法。"),
("C#", "C# 語言", "Godot .NET 版正式支援的程式語言與工具鏈選項。", ".NET Build、平台匯出。", "既有 .NET 團隊或需要 C# 生態時使用。", "不能把 GDScript API 寫法直接逐字換成 C#。"),
("GDExtension", "原生擴充介面", "讓原生程式庫與 Godot 互動而不必自行維護完整引擎分支的擴充機制。", "C、C++、效能、外掛。", "整合原生功能或高效能模組。", "它不是初學者每個功能都需要的最佳化捷徑。"),
("extends", "繼承宣告", "GDScript 指定目前腳本建立在哪個基底類別能力上的語法。", "Node、Resource、Inheritance。", "`extends CharacterBody2D` 讓腳本取得角色物理能力。", "extends 的類型與腳本掛載節點不相容會造成問題。"),
("class_name", "全域類別名稱", "讓 GDScript 類別以專案可識別名稱出現在型別與編輯器中的宣告。", "Type Hint、Custom Resource。", "建立 CharacterStats 或 HealthComponent 等明確類型。", "不是每個小腳本都必須宣告全域名稱。"),
("@export", "匯出屬性註記", "讓腳本欄位可在 Inspector 設定與序列化的 GDScript 註記。", "Inspector、設計參數。", "暴露速度、Resource 引用或可調範圍。", "不應把所有內部變數都公開給 Inspector。"),
("@onready", "準備時初始化註記", "讓變數在節點接近 ready 階段時初始化，常用於取得子節點引用。", "_ready、NodePath。", "`@onready var sprite = $Sprite`。", "方便取得節點不代表長路徑耦合自動消失。"),
("Variable", "變數", "保存會依實例或執行狀態改變資料的具名位置。", "State、Type Hint、Resource。", "保存目前生命、分數或節點引用。", "同一個數值也要區分設計設定與 Runtime 狀態。"),
("Constant", "常數", "在腳本中用來表達不應於 Runtime 任意改變的具名值或引用。", "Variable、預載資源。", "保存固定比例、鍵名或預載場景。", "宣告為常數不代表其引用的 Resource 內容絕對不可變。"),
("Function", "函式", "具有名稱、輸入、輸出與可能副作用的一段可呼叫行為。", "Method、Callable、公開介面。", "封裝 take_damage、add_score 或 change_phase。", "函式名稱若無法說明副作用，結構可能過度混雜。"),
("Type Hint", "型別提示", "明確指出變數、參數與回傳值預期資料類型的註記。", "GDScript、靜態檢查。", "讓編輯器、Codex 與讀者更早發現誤用。", "型別不只為效能，也是一份合約。"),
("_enter_tree()", "進入樹回呼", "節點加入 SceneTree 時由引擎呼叫的生命週期方法。", "_ready、父子順序。", "處理需要在子節點 ready 前發生的樹狀註冊。", "不等同所有初始化都應放在這裡。"),
("_ready()", "準備完成回呼", "節點與必要子樹準備完成後由引擎呼叫的方法。", "@onready、初始化。", "取得子節點、套用資料與發出初始狀態。", "同一實例移出再加入樹時不應假設一定自動再次呼叫。"),
("_process()", "閒置幀處理", "依顯示幀率反覆呼叫、接收 delta 的更新方法。", "delta、_physics_process。", "處理非物理的每幀視覺或一般更新。", "不應把只在事件發生時需要的工作全部每幀重做。"),
("_physics_process()", "物理幀處理", "以固定物理節奏反覆呼叫、適合物理與角色移動的更新方法。", "CharacterBody2D、delta。", "設定 velocity、執行 move_and_slide。", "實際頻率可設定，不必硬記永遠六十次。"),
("delta", "幀間時間差", "距離上一次處理經過的秒數，用來把每幀變化轉成時間相關變化。", "速度、計時、process。", "自己積分位置、旋轉或倒數時使用。", "不是所有 API 都要再乘 delta；有些方法已處理時間。"),
("_input()", "輸入事件回呼", "節點接收輸入事件時由引擎呼叫的回呼之一。", "Input Event、Input Map。", "處理需要事件細節的鍵盤、滑鼠或手把輸入。", "持續移動不一定只靠單次 _input 事件。"),
("await", "等待", "暫停目前函式流程，直到訊號或可等待結果完成後再繼續。", "Signal、Timer、Animation。", "等待動畫結束或計時完成。", "等待期間世界仍會改變，節點可能被移除或流程重入。"),
("queue_free()", "排程釋放節點", "把節點安排在安全時機從場景樹移除並釋放。", "生命週期、Instance。", "收集物消失、敵人死亡後清理。", "呼叫後不要假設節點與所有引用仍可長期使用。"),
("Process Mode", "處理模式", "決定節點在一般、暫停或特定條件下是否繼續處理的設定。", "Pause、SceneTree。", "讓暫停選單仍接收輸入，而世界停止。", "只設定 get_tree().paused 不代表所有節點都符合需求。"),
("Input Map", "輸入映射", "把實體按鍵、按鈕或軸轉成遊戲抽象動作的設定系統。", "Action、Input Event、project.godot。", "用 move_left 或 pause 取代硬編碼鍵碼。", "動作字串拼錯時，程式可能只表現成沒有反應。"),
("Input Event", "輸入事件", "描述鍵盤、滑鼠、手把、觸控等一次輸入資訊的事件物件。", "_input、Input Map。", "處理剛按下、位置、按鍵與裝置細節。", "原始事件不應直接滲透所有遊戲規則。"),
("Action Strength", "動作強度", "Input Map 動作目前的數值強度，可表達數位按鍵或類比軸。", "Input Map、Vector2。", "計算手把搖桿方向與幅度。", "它不一定只有零或一。"),
("Vector2", "二維向量", "含 X、Y 兩個分量的資料型別，可表達位置、方向、速度或尺寸。", "Node2D、Velocity。", "計算玩家移動方向與距離。", "同一 Vector2 值需辨認它是位置、方向還是速度。"),
("Velocity", "速度向量", "描述物體每單位時間移動方向與速率的向量。", "CharacterBody2D、delta。", "設定角色移動。", "速度與本次位移不是同一個量。"),
("CharacterBody2D", "二維角色物理節點", "適合由程式控制並與世界碰撞的 2D 角色 Body。", "velocity、move_and_slide、CollisionShape2D。", "玩家與具明確控制邏輯的敵人。", "不要把一般 position 積分公式無條件套到其所有移動 API。"),
("RigidBody2D", "二維剛體", "主要由物理模擬、力與碰撞反應控制的 2D Body。", "Force、Impulse、Physics。", "箱子、彈跳物件、受力道具。", "每幀硬改 transform 可能與物理模擬對抗。"),
("StaticBody2D", "二維靜態物體", "通常代表不移動的物理碰撞環境。", "牆、地面、CollisionShape2D。", "建立關卡邊界與固定障礙。", "不適合直接拿來做持續移動的角色。"),
("AnimatableBody2D", "二維可動畫物體", "由程式或動畫移動、同時希望正確影響其他物理物件的 Body。", "移動平台、Physics。", "製作移動地板或升降台。", "它與由力控制的 RigidBody2D 角色不同。"),
("Area2D", "二維偵測區域", "偵測 Body 或其他 Area 進入、離開與重疊的 2D 節點。", "Signal、Layer、Mask。", "收集物、傷害區、觸發區與感知範圍。", "Area2D 通常不是用來像牆一樣阻擋角色。"),
("CollisionShape2D", "二維碰撞形狀節點", "為父 Body 或 Area 提供實際碰撞邊界的節點。", "Shape2D Resource、Physics。", "使用矩形、圓形或膠囊近似角色邊界。", "只建立節點而沒有指定 Shape Resource 不會得到有效碰撞。"),
("Collision Layer", "碰撞層", "表示物理物件屬於哪些分類的位元設定，可口語理解為「我是誰」。", "Collision Mask、Project Settings。", "標記 player、enemy、world、pickup。", "Layer 本身不等於它會偵測誰。"),
("Collision Mask", "碰撞遮罩", "表示物理物件關心或偵測哪些碰撞層，可理解為「我要看誰」。", "Collision Layer、Area2D。", "讓 Pickup 只偵測 player。", "Layer 與 Mask 未匹配時，形狀重疊也可能沒有事件。"),
("Timer", "計時器節點", "在指定時間後發出 timeout，或週期性觸發的時間工具。", "Signal、無敵時間、生成。", "處理冷卻、倒數、延遲與週期。", "暫停政策與 process mode 會影響是否繼續計時。"),
("Tween", "補間動畫", "以程式建立，把數值從起點平滑過渡到終點的時間流程。", "UI、視覺回饋、AnimationPlayer。", "淡入淡出、縮放、相機晃動。", "Tween 適合插值，不應取代所有狀態與遊戲規則。"),
("AnimationPlayer", "動畫播放器", "保存並播放可編輯的多軌屬性動畫。", "Animation、Signal、await。", "角色死亡、UI 面板、場景效果。", "每幀重播同一動畫可能讓它永遠停在開頭。"),
("AnimationTree", "動畫樹", "用節點圖混合與控制複雜動畫狀態的系統。", "AnimationPlayer、State Machine。", "角色移動混合、狀態切換與 BlendSpace。", "小型單一動畫不一定需要先建立 AnimationTree。"),
("Control", "介面控制節點", "Godot UI 系統的基礎節點，使用錨點、尺寸與容器版面。", "Container、Anchor、Theme。", "建立 Label、Button、Panel 與 HUD。", "不應只把 Control 當成可自由擺放的 Sprite2D。"),
("Container", "介面容器", "依規則自動排列與調整子 Control 節點的 UI 節點。", "HBox、VBox、Grid、size flags。", "建立能適應內容與解析度的版面。", "容器擁有子項版面，手動位置常會被重新計算。"),
("Anchor", "錨點", "Control 相對父節點尺寸的比例參考位置。", "Offset、Responsive UI。", "讓面板貼齊右下或隨視窗伸展。", "Anchor 不是直接以像素表示位置。"),
("Offset", "位移邊界", "Control 在 Anchor 參考位置上增加的像素邊界差。", "Anchor、Control。", "設定與父邊緣的具體距離。", "只調 Offset 而不理解 Anchor，視窗變化時容易跑版。"),
("CanvasLayer", "畫布層", "讓 2D 子節點在獨立畫布層中繪製，不受一般世界 Camera2D 變換的節點。", "HUD、Camera2D。", "讓分數與生命固定在螢幕。", "CanvasLayer 不是遊戲狀態管理器。"),
("Camera2D", "二維攝影機", "決定 2D 世界哪一區域與如何映射到視窗的節點。", "World coordinates、CanvasLayer。", "跟隨玩家、限制關卡邊界、縮放與晃動。", "玩家世界位置與螢幕位置不是同一座標。"),
("Node3D", "三維節點", "具有 3D 位置、旋轉與縮放的空間節點基礎。", "Transform3D、Camera3D、Mesh。", "組成 3D 角色、世界與物件。", "從 2D 遷移時仍需重新學三維方向與旋轉。"),
("Transform", "變換", "描述物件位置、旋轉與縮放，以及它如何從局部空間映射到父空間。", "Local、Global、父子階層。", "移動角色、放置模型、安排 UI。", "Transform 不是只有 position 一個值。"),
("Local Coordinates", "局部座標", "相對父節點所表示的位置或方向。", "Global Coordinates、Transform。", "設定 Sprite 相對 Player 根節點的偏移。", "同一 local position 在不同父節點下會對應不同世界位置。"),
("Global Coordinates", "全域座標", "經父節點變換鏈組合後，在整個世界或畫布中的位置。", "Local Coordinates、Camera。", "比較不同分支物件的位置或在世界生成。", "滑鼠 viewport 座標不能不轉換就當世界 global position。"),
("State", "狀態", "系統此刻記住的資料或模式，會影響下一步允許的行為。", "Game Loop、State Machine。", "生命、分數、Playing、Paused、GameOver。", "畫面看起來暫停不代表內部狀態與所有系統都已暫停。"),
("State Machine", "狀態機", "集中管理有限狀態、轉換條件、進入與退出行為的模型。", "State、AnimationTree、流程。", "管理角色 Idle／Moving／Hurt／Dead。", "狀態少時不一定要先建立大型通用框架。"),
("Coupling", "耦合", "模組彼此依賴的程度與方式。", "Encapsulation、Signal、NodePath。", "評估修改一個場景會影響多少其他模組。", "目標不是零耦合，而是必要、清楚且方向合理的依賴。"),
("Single Source of Truth", "單一真相來源", "同一核心狀態由一個明確擁有者保存與修改，其他對象只讀取或接收事件。", "Data Flow、HUD、GameState。", "讓分數只由 ScoreModel 擁有。", "不是說整個遊戲只能有一個全域物件。"),
("Save Data", "存檔資料", "從 Runtime 狀態中挑選、序列化並跨啟動保存的版本化資料。", "user://、Resource、版本遷移。", "保存最高分、解鎖、偏好與進度。", "不應直接把整棵 SceneTree 當成可靠存檔。"),
("Debugger", "除錯器", "提供錯誤、堆疊、變數與 Runtime 診斷資訊的工具。", "Output、Remote SceneTree、Profiler。", "定位解析、Runtime 與邏輯問題。", "只把錯誤訊息隱藏不等於完成除錯。"),
("Profiler", "效能分析器", "量測腳本、物理、渲染與其他系統耗時或資源使用的工具。", "Optimization、目標裝置。", "先找真正瓶頸，再做最小優化。", "它不會替你自動決定所有效能目標。"),
("Git Checkpoint", "Git 檢查點", "在 AI 任務前後建立可比較、可提交與可回退的版本狀態。", "Diff、Codex、版本控制。", "隔離單一功能修改與保護人的未提交工作。", "Git 不只是最後備份，checkpoint 應在變更前建立。"),
("Headless Mode", "無頭模式", "在沒有圖形編輯器視窗的環境執行 Godot 指令、檢查或匯出的方式。", "CLI、CI、自動驗證。", "做專案載入、測試與建置流程。", "無頭啟動通過不代表畫面、音訊與手感已人工驗收。"),
("WebAssembly", "WebAssembly", "讓 Godot Web 成品在瀏覽器中執行核心程式的二進位指令格式。", "Web Export、WebGL、伺服器。", "建立瀏覽器可執行遊戲。", "Web 匯出仍受瀏覽器音訊、檔案、執行緒與安全政策限制。"),
("Android App Bundle", "Android 應用程式套件", "Google Play 常用的 Android 發布封裝格式，副檔名通常為 AAB。", "Android Export、簽章、版本碼。", "上架商店並由平台產生裝置適用 APK。", "AAB 產生成功不代表觸控、背景切換與商店規則已驗收。"),
("Codex", "Codex 程式代理", "OpenAI 的 coding agent，可在授權環境中閱讀、修改、執行與審查程式碼。", "Git、AGENTS.md、八格規格單。", "接手 Godot 專案、實作小步功能、除錯與建立文件。", "它能產生與執行，不代表需求、API 與結果自動正確。"),
("AGENTS.md", "專案代理指示檔", "可放在程式庫中的代理工作指示與導覽文件，實際支援方式依 Codex 最新文件。", "Codex、專案規則、README。", "記錄版本、命名、測試、禁止事項與完成回報。", "不應塞入所有背景造成冗長矛盾，也不能取代每次任務目標。"),
("Acceptance Criteria", "驗收條件", "用可觀察結果定義一項工作何時算完成的條件。", "八格規格單、測試、交付。", "指定行為、錯誤、平台與不變事項。", "「程式碼已產生」或「看起來可以」不是充分驗收。"),
]

assert 80 <= len(terms) <= 120, len(terms)

parts = []
parts.append("# 附錄｜把概念變成可查、可下指令、可教學的工作工具\n")
parts.append("這一組附錄不是另一套正文，而是把全書的概念壓縮成可在實作時反覆使用的查詢工具。術語表用來定位名詞；Codex 模板用來把需求變成可驗收工作；專案閱讀清單用來接手陌生程式庫；六堂課框架用來轉成教學；學習路線則協助你在完成第一個閉環後選擇下一步。\n")
parts.append("## 附錄一｜Godot 核心術語表\n")
parts.append("術語的目標不是提供百科式定義，而是回答五件事：它是什麼、和誰有關、何時使用、常見誤解，以及它在全書地圖中的位置。\n")
for i, (en, zh, definition, related, usage, misconception) in enumerate(terms, 1):
    parts.append(f"### {i}. {en}｜{zh}\n")
    parts.append(f"- **白話定義**：{definition}\n")
    parts.append(f"- **關聯概念**：{related}\n")
    parts.append(f"- **使用時機**：{usage}\n")
    parts.append(f"- **常見誤解**：{misconception}\n")

parts.append("## 附錄二｜十二組 Codex 指令模板\n")
parts.append("以下模板都以 Godot 4.7 Stable 與 GDScript 為默認示例。使用前要把方括號內容替換成真實專案資訊。模板不是魔法句型；真正有效的是版本、現況、唯一目標、不變條件、結構、行為、驗收與回報都被說清楚。\n")

templates = [
("建立新專案基準", """> **版本**：Godot 4.7 Stable，[標準版／.NET 版]，[GDScript／C#]，目標平台為 [Windows／Web／Android]。  
> **現況**：目前只有空資料夾，尚無 project.godot。  
> **唯一目標**：建立可被 Godot 開啟的最小 [2D／3D] 專案與主場景。  
> **不可破壞**：不要加入第三方外掛、Autoload、存檔、UI 或示範素材；不要使用預發布 API。  
> **預期結構**：先提出根目錄、main scene、資料夾與 renderer 選擇理由，再建立最小檔案。  
> **預期行為**：專案可被相符版本開啟，執行後顯示空主場景並可正常退出。  
> **驗收**：Godot 載入無解析錯誤；Git 忽略 .godot/；README 記錄版本與啟動方式。  
> **回報**：列出實際檔案、執行命令、結果與仍需人工確認的設定。"""),
("陌生專案只讀接手", """> 先尋找包含 project.godot 的專案根目錄。這一輪只讀取，不修改、不安裝、不刪除。請依序回報：精確 Godot 版本線、主場景、Autoload、Input Map、renderer、核心場景與根節點、腳本語言、Resource、外掛、匯出 preset、測試／啟動命令、Git 狀態。接著畫出 [指定功能] 的場景關係、事件流與資料流，指出單一真相來源與三個最高風險。任何無法由檔案證明的資訊都標示「待確認」。"""),
("設計場景樹", """> **唯一目標**：為 [功能或角色] 設計場景樹，不先建立檔案。請列根節點類型、主要子節點、每個節點唯一責任、需要引用的 Resource、公開方法、signals、外部依賴與獨立測試方式。限制樹深度與節點數要有理由，不要加入與當前需求無關的 Manager。最後用口語說明資料從哪裡來、事件如何離開此場景。"""),
("新增玩家角色", """> **版本**：Godot 4.7 Stable，GDScript，2D。  
> **現況**：[列目前 Main 與輸入設定]。  
> **唯一目標**：建立 Player 場景，支援四方向移動與世界碰撞。  
> **不可破壞**：不建立 HUD、生命、動畫狀態機或存檔；不改現有 Main 其他節點。  
> **預期結構**：CharacterBody2D 根、可見節點、有效 CollisionShape2D；速度為可調設計參數。  
> **預期行為**：依 Input Map 持續移動，斜向速度正規化，碰牆不穿透，暫停政策先說明。  
> **驗收**：不同幀率下十秒距離大致一致；Godot 無錯誤；Remote 樹只有一個 Player。"""),
("建立 Input Map", """> 只處理輸入抽象。新增或檢查 [動作清單]，為鍵盤、手把與必要觸控提出映射。區分持續狀態、just pressed 與原始事件。不可直接把實體鍵碼寫入遊戲規則腳本，不得覆蓋既有未相關動作。修改 project.godot 前先列最小差異；完成後回報每個動作、裝置映射與人工重新綁定測試。"""),
("建立 Signal 與資料流", """> **唯一目標**：讓 [發送者] 在 [事件] 發生時通知 [協調者／接收者]，並由 [資料擁有者] 修改 [狀態]。先畫事件流與資料流。Signal 名稱使用已發生事件語氣，參數只帶最低必要資料；HUD 不得成為狀態第二份真相；不要把所有直接呼叫改成 Signal。驗收包含重複進入、場景重開與 Signal 是否被重複連接。"""),
("加入響應式 UI", """> **版本**：Godot 4.7 Stable。  
> **唯一目標**：建立 [HUD／選單]，顯示 [資料] 並發出 [使用者意圖]。  
> **結構**：使用 Control、CanvasLayer、適當 Container、Anchor 與 size flags；避免對每個元素寫死絕對位置。  
> **資料邊界**：UI 只顯示狀態或提出意圖，不直接修改核心規則。  
> **驗收**：在 16:9、16:10、4:3、狹長視窗與長文字下不重疊；Camera 移動時 HUD 固定；鍵盤與手把焦點可用。"""),
("除錯與根因分析", """> 不要先修改。環境為 [版本／平台]；重現步驟為 [步驟]；預期 [結果]，實際 [結果]；完整錯誤與堆疊如下：[內容]；最近 diff 為 [摘要]。請列最多三個原因，每個原因附支持證據、最小無破壞檢查與預期觀察。依風險最低順序執行。確認根因後只做最小修正，再重跑原步驟與相鄰回歸情境。禁止以吞掉錯誤或大量 null 檢查掩蓋根因。"""),
("受控重構", """> **唯一目標**：把 [責任] 從 [原模組] 移到 [新模組]。  
> **不變條件**：[公開方法、signals、節點名稱、存檔格式、玩家行為] 全部保持。  
> **步驟**：先列現況依賴與測試；一次遷移一個呼叫端；每步可回退。不要同時格式化全專案、升級版本或加入新功能。  
> **驗收**：原情境與邊界情境均通過；Git diff 只含必要檔；舊入口移除前無未處理引用。"""),
("存檔與讀取", """> 先設計 SaveData v[版本] 合約。區分設計資料、Runtime 狀態與持久資料；列欄位、型別、預設與驗證。存到 user://，處理檔案不存在、損毀、未知欄位、舊版本與寫入失敗。不要序列化整棵 SceneTree，也不要把秘密資料放入明文。實作後建立新檔、舊檔、損毀檔與跨版本四組驗收。"""),
("匯出前檢查", """> 以審查者角色，不新增功能。目標平台為 [Windows／Web／Android]。核對 Godot 與 Export Templates 版本、export preset、主場景、資源包含、renderer、架構、圖示、存檔、輸入、音訊、簽章與秘密。區分能自動執行的命令與必須在真實裝置人工驗收的項目。只有有證據的項目可標通過，未測一律標待驗證。"""),
("建立教學與 README 版本", """> 根據實際專案建立教學交付，不改遊戲行為。README 必須含精確版本、開啟、執行、測試、匯出、資料夾責任、主要場景樹、事件／資料流、已知限制與授權來源。再把專案拆成 [課數] 個 Git checkpoint；每堂只有一個認知任務，包含示範、學員實作、Codex 使用邊界、驗收、變化挑戰與口語回教。不得把無法證明的素材來源或測試結果寫成已完成。"""),
]

for i, (name, body) in enumerate(templates, 1):
    parts.append(f"### 模板 {i}｜{name}\n")
    parts.append(body + "\n")
    parts.append("**使用提醒**：送出前先刪除不適用欄位、補齊實際路徑與錯誤，不要把方括號留給 Codex 猜。\n")

parts.append("## 附錄三｜拿到陌生 Godot 專案後的閱讀清單\n")
parts.append("接手專案的目標不是立刻懂完每一行，而是建立一條從入口、結構、資料、事件到 Runtime 的導航。以下順序可以交給自己，也可以交給 Codex 做只讀盤點。\n")
reading_steps = [
("保護現況", "確認 Git 狀態、未提交變更、目前分支與可回退點。不要在不知道工作樹內容時執行清理或重置。"),
("找到專案根", "尋找 project.godot，確認 Codex 與命令都在正確目錄。"),
("確認版本", "從文件、CI、下載記錄與專案設定判斷 Godot 版本、標準／.NET 版與必要外掛。"),
("讀主場景", "確認 run/main_scene 指向哪裡，主場景是選單、GameFlow 還是直接關卡。"),
("讀 Autoload", "列出每個全域服務、資料與公開介面，辨認是否有巨大 Global。"),
("讀 Project Settings", "查看 Input Map、顯示、renderer、物理層、語言與平台設定。"),
("掃描檔案結構", "辨認 scenes、scripts、resources、assets、addons、tests 與 docs 的命名規則。"),
("畫核心場景樹", "從 Main、Player、Enemy、HUD 等根節點開始，只畫主要責任，不先展開所有裝飾。"),
("找公開介面", "記錄每個核心場景的公開方法、signals、export 欄位與 Resource 依賴。"),
("找資料真相", "生命、分數、遊戲狀態、設定與存檔各由誰擁有，是否有重複維護。"),
("畫事件流", "選一條關鍵流程，例如受傷或收集，追蹤觸發、Signal、狀態與顯示。"),
("畫時間線", "確認初始化、process、physics、Timer、await、場景切換與清理。"),
("查動態建立", "搜尋 instantiate、add_child、queue_free，確認生成容器與生命週期。"),
("查長路徑與群組", "找硬編碼 NodePath、get_nodes_in_group 與跨場景內部存取。"),
("查 Resource 共享", "找 Runtime 修改 Material、Theme、自訂 Resource 等可能影響多實例的地方。"),
("讀存檔", "確認 user://、格式版本、錯誤處理、設計資料與持久資料的界線。"),
("讀外掛與原生擴充", "確認 addons、GDExtension、SDK 與第三方套件版本、授權與啟動要求。"),
("找到啟動與測試命令", "閱讀 README、CI、腳本與 Godot CLI，先執行最小不破壞檢查。"),
("看 Runtime", "以編輯器執行，觀察 Output、Debugger、Remote SceneTree 與主要玩家流程。"),
("建立風險清單", "依阻擋啟動、資料損失、版本混用、結構風險、平台未測排序，不急著一次修完。"),
]
for i, (name, detail) in enumerate(reading_steps, 1):
    parts.append(f"### {i}. {name}\n{detail}\n")
parts.append("完成這二十步後，你不一定已理解所有細節，但應能回答：入口在哪裡、主要模組是誰、資料由誰擁有、事件怎麼走、每一幀做什麼、如何啟動與回退。這已足以讓下一個修改不再盲目。\n")

parts.append("## 附錄四｜六堂 Godot＋Codex 入門課\n")
parts.append("這六堂課以每堂二到三小時的工作坊為設計基準，可依學員背景拆成更多次。課程目標不是一次完成華麗遊戲，而是讓每堂建立一個可回教、可驗收的認知閉環。\n")
lessons = [
("第一堂｜遊戲不是畫面：引擎、規則與迴路", "能區分作品、引擎、編輯器、語言與 Runtime，並用輸入、規則、狀態、輸出描述移動。", "建立空專案與 Main；定義 Input Map；讓一個簡單角色在平面移動。", "先要求 Codex 只讀說明專案層次，再用八格規格單建立最小移動。", "改變幀率與輸入裝置，口述為什麼速度仍應一致。"),
("第二堂｜節點與場景：把角色組成可重用模組", "理解 Node、Scene、Instance、SceneTree 與父子 Transform。", "建立 Player 與 EnergyPickup 場景，在 Main 中實例化多個 Pickup。", "Codex 先提出場景樹與每個節點責任，學員審查後才建立。", "增加第二種外觀但保留同一收集結構，說明哪些是 Scene、哪些是 Resource。"),
("第三堂｜事件與資料：收集、分數與 HUD", "區分直接呼叫、Signal、事件流、資料流與單一真相來源。", "Pickup 發出 collected，GameState 改分數，HUD 顯示 score_changed。", "要求 Codex 畫兩條流，禁止 HUD 直接擁有遊戲分數。", "同時收集兩個物件，確認事件只處理一次；把 HUD 換版面而不改 Pickup。"),
("第四堂｜時間與物理：敵人、受傷、無敵與動畫", "理解 physics process、Body／Area、Layer／Mask、Timer、動畫與等待。", "加入 Enemy 接觸傷害、Player 一秒無敵、受傷回饋與死亡。", "Codex 必須先標出時間單位、碰撞角色與死亡防重入。", "在不同 FPS、暫停與連續碰撞下驗收；讓學員口述完整時間線。"),
("第五堂｜從能跑到能維護：Resource、狀態與存檔", "區分設計資料、Runtime 狀態、Autoload 與持久存檔。", "建立 PickupData／PlayerStats，加入遊戲階段與最小 SaveData v1。", "以受控重構模板執行，先固定行為與 Git checkpoint。", "新增金色能量只改資料；用損毀存檔測試錯誤處理。"),
("第六堂｜除錯、交付與教回", "能使用 Debugger、Remote 樹、Profiler、Git 與 export matrix，並把專案教給別人。", "完成暫停、失敗、重來；匯出 Windows 或 Web；建立 README 與成果說明。", "Codex 只做交付前審查與文件，不能把未測項目標成通過。", "每位學員展示一條事件／資料流、一個 Bug 根因與一份八格規格單。"),
]
for i, (title, objective, practice, codex, assessment) in enumerate(lessons, 1):
    parts.append(f"### {title}\n")
    parts.append(f"- **學習目標**：{objective}\n")
    parts.append(f"- **實作主線**：{practice}\n")
    parts.append(f"- **Codex 使用邊界**：{codex}\n")
    parts.append(f"- **驗收與挑戰**：{assessment}\n")
    parts.append("- **教學節奏**：問題開場 → 口語概念地圖 → 講師示範 → 學員規格 → Codex 小步執行 → Godot 驗證 → 變化題 → 口語回教。\n")

parts.append("## 附錄五｜完成本書後的九條學習路線\n")
parts.append("完成能量收集者閉環後，不要同時追九條路。先選一條與實際用途最接近的方向，保留全書五層模型，再補上該領域新增的空間、工具與交付知識。\n")
routes = [
("2D 遊戲", "深化 TileMapLayer、2D 導航、燈光、粒子、關卡資料、存檔與手把。", "先完成一款十五分鐘可通關的小遊戲，而不是無限擴張世界。", "關卡內容增加後，場景與 Resource 邊界是否仍清楚？"),
("3D 遊戲", "補上三維向量、旋轉、Camera3D、光照、材質、模型、骨架動畫、導航與 3D 物理。", "先把能量收集者改成單一小房間 3D 版本，保留事件與資料流。", "哪些結構直接遷移，哪些是 3D 新知識？"),
("手機遊戲", "學習觸控、不同長寬比、安全區、背景／前景、耗電、效能、商店簽章與 AAB。", "把現有遊戲改成單手操作並在兩種實體 Android 裝置測試。", "桌面輸入與 UI 假設有哪些失效？"),
("Web 遊戲", "掌握 WebAssembly、WebGL、伺服器 MIME、下載大小、瀏覽器音訊、儲存與跨來源限制。", "建立可由 HTTPS 網站載入的短體驗，測桌面與行動瀏覽器。", "無頭匯出成功之外，瀏覽器真實限制是否有證據？"),
("教育遊戲", "把學習目標、回饋、難度、記錄與教師觀察納入規則設計。", "選一個明確知識點，建立五分鐘可完成、能解釋錯誤的互動。", "遊戲回饋是否真的支持學習，而不是只加分數？"),
("互動展示與工具型應用", "深化 UI、資料匯入、檔案對話、視覺化、外部裝置與桌面發布。", "做一個能讀取本地資料並以互動方式呈現的小工具。", "Godot 的遊戲迴路與場景模型如何服務非遊戲需求？"),
("XR", "學習 OpenXR、頭戴裝置輸入、空間尺度、舒適度、效能與裝置發布。", "先做一個單一空間的抓取或指向互動，再增加內容。", "在 2D 螢幕合理的介面，進入沉浸空間後是否仍合理？"),
("多人與網路", "補上權威模型、同步、延遲、預測、序列化、安全與伺服器部署。", "先做兩人最小同步狀態，不從大型 MMO 開始。", "哪一份狀態由伺服器擁有，哪些只是客戶端呈現？"),
("AI 驅動遊戲", "把模型呼叫、工具、上下文、延遲、成本、安全、快取與失敗回退接進遊戲 Runtime。", "先讓 AI 只產生非關鍵對話或建議，保留可預測的核心規則。", "模型輸出不穩定時，遊戲狀態與玩家體驗如何保持可驗證？"),
]
for i, (name, learn, project, question) in enumerate(routes, 1):
    parts.append(f"### {i}. {name}\n")
    parts.append(f"- **新增知識**：{learn}\n")
    parts.append(f"- **第一個作品**：{project}\n")
    parts.append(f"- **核心檢查問題**：{question}\n")

parts.append("## 附錄收束｜把工具變成自己的導航系統\n")
parts.append("術語表讓你在遇到陌生字時回到角色與關係；指令模板讓你在交給 Codex 前先完成自己的思考；閱讀清單避免接手專案時從隨機檔案開始；六堂課把知識轉成可教的認知推進；九條路線則提醒你，下一步不是無限增加功能，而是選一個新領域，再次走完意圖、規則、結構、執行與協作驗證五層。\n")
parts.append("真正成熟的學習工具，不是替你記住所有答案，而是在答案改變時，仍然知道該問什麼。\n")

OUT.write_text("\n".join(parts), encoding='utf-8')

registry = [
"# Terminology Registry｜術語一致性登錄\n",
"本檔與附錄一使用同一份正式術語資料。正文第一次出現時採中文解釋加英文，後續依語境使用英文類別名或台灣常用中文。\n",
"| 英文／程式名稱 | 本書中文 | 一句定義 | 首要關聯 | 禁止混淆 |",
"|---|---|---|---|---|",
]
for en, zh, definition, related, usage, misconception in terms:
    registry.append(f"| {en} | {zh} | {definition} | {related} | {misconception} |")
TERMS_OUT.write_text("\n".join(registry) + "\n", encoding='utf-8')
print(f"wrote {OUT} with {len(terms)} terms and {len(templates)} templates")
