from __future__ import annotations

import hashlib
import json
import shutil
import tempfile
import zipfile
from pathlib import Path

ROOT = Path('/mnt/data/Godot_先懂再做_完整出版包')
ZIP_PATH = Path('/mnt/data/Godot_先懂再做_完整出版包.zip')


def sha256(path: Path) -> str:
    h = hashlib.sha256()
    with path.open('rb') as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b''):
            h.update(chunk)
    return h.hexdigest()


def tree_meta(base: Path) -> dict[str, tuple[int, str]]:
    return {
        p.relative_to(base).as_posix(): (p.stat().st_size, sha256(p))
        for p in sorted(base.rglob('*')) if p.is_file()
    }

if ZIP_PATH.exists():
    ZIP_PATH.unlink()

with zipfile.ZipFile(ZIP_PATH, 'w', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as zf:
    for p in sorted(ROOT.rglob('*')):
        if p.is_file():
            arcname = Path(ROOT.name) / p.relative_to(ROOT)
            zf.write(p, arcname.as_posix())

with zipfile.ZipFile(ZIP_PATH, 'r') as zf:
    bad = zf.testzip()
    if bad is not None:
        raise RuntimeError(f'CRC failure: {bad}')
    names = zf.namelist()
    unsafe = [name for name in names if name.startswith('/') or '..' in Path(name).parts]
    if unsafe:
        raise RuntimeError(f'Unsafe archive paths: {unsafe[:5]}')
    with tempfile.TemporaryDirectory(prefix='godot_full_zip_') as tmp:
        tmp_path = Path(tmp)
        zf.extractall(tmp_path)
        extracted = tmp_path / ROOT.name
        source_meta = tree_meta(ROOT)
        extracted_meta = tree_meta(extracted)
        if source_meta != extracted_meta:
            missing = sorted(set(source_meta) - set(extracted_meta))
            extra = sorted(set(extracted_meta) - set(source_meta))
            changed = sorted(k for k in set(source_meta) & set(extracted_meta) if source_meta[k] != extracted_meta[k])
            raise RuntimeError(json.dumps({'missing': missing[:20], 'extra': extra[:20], 'changed': changed[:20]}, ensure_ascii=False))

result = {
    'zip_path': str(ZIP_PATH),
    'zip_bytes': ZIP_PATH.stat().st_size,
    'zip_sha256': sha256(ZIP_PATH),
    'file_count': len(tree_meta(ROOT)),
    'crc_test': 'passed',
    'path_safety': 'passed',
    'extraction_hash_match': True,
}
print(json.dumps(result, ensure_ascii=False, indent=2))
