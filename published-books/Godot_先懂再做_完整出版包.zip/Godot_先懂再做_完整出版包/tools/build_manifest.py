from __future__ import annotations

import hashlib
from pathlib import Path

ROOT = Path('/mnt/data/Godot_先懂再做_完整出版包')
MANIFEST = ROOT / '05_delivery' / 'delivery_manifest.txt'
EXCLUDED = {MANIFEST.resolve()}


def sha256(path: Path) -> str:
    h = hashlib.sha256()
    with path.open('rb') as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b''):
            h.update(chunk)
    return h.hexdigest()

files = [p for p in sorted(ROOT.rglob('*')) if p.is_file() and p.resolve() not in EXCLUDED]
total_bytes = sum(p.stat().st_size for p in files)
lines = [
    'DELIVERY MANIFEST｜《先懂再做：用 Godot 建立遊戲開發的全局觀》V1.0',
    'Generated: 2026-07-12',
    'Root: Godot_先懂再做_完整出版包/',
    'Note: 本清單不列入 delivery_manifest.txt 自身；總 ZIP 位於交付資料夾外，亦不列入。',
    f'File count (excluding manifest): {len(files)}',
    f'Total bytes (excluding manifest): {total_bytes}',
    '',
    'SHA256  BYTES  RELATIVE_PATH',
]
for p in files:
    rel = p.relative_to(ROOT).as_posix()
    lines.append(f'{sha256(p)}  {p.stat().st_size}  {rel}')
MANIFEST.write_text('\n'.join(lines) + '\n', encoding='utf-8')
print(f'wrote {MANIFEST} with {len(files)} entries')
