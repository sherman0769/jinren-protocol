from __future__ import annotations

import hashlib
import json
import shutil
import tempfile
import zipfile
from datetime import datetime, timezone
from pathlib import Path

ROOT = Path('/mnt/data/Godot_先懂再做_完整出版包')
CHAPTERS = ROOT / '02_chapters'
DELIVERY = ROOT / '05_delivery'
ZIP_DIR = DELIVERY / 'chapter_zips'

REQUIRED_SUFFIXES = [
    '_main.md', '_main.docx', '_speech_notes.md', '_slide_outline.md',
    '_quotes.md', '_model_canvas.md', '_codex_prompts.md'
]


def sha256(path: Path) -> str:
    h = hashlib.sha256()
    with path.open('rb') as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b''):
            h.update(chunk)
    return h.hexdigest()


def tree_hashes(base: Path) -> dict[str, str]:
    return {
        p.relative_to(base).as_posix(): sha256(p)
        for p in sorted(base.rglob('*')) if p.is_file()
    }


def main() -> None:
    ZIP_DIR.mkdir(parents=True, exist_ok=True)
    for old in ZIP_DIR.glob('*.zip'):
        old.unlink()

    results = []
    unit_dirs = sorted(p for p in CHAPTERS.iterdir() if p.is_dir())
    if len(unit_dirs) != 15:
        raise RuntimeError(f'Expected 15 unit directories, got {len(unit_dirs)}')

    for unit in unit_dirs:
        prefix = unit.name.split('_', 2)
        chapter_num = '_'.join(prefix[:2])  # chapter_00
        expected = [unit / 'README.md'] + [unit / f'{chapter_num}{suffix}' for suffix in REQUIRED_SUFFIXES]
        missing = [str(p) for p in expected if not p.is_file() or p.stat().st_size == 0]
        if missing:
            raise RuntimeError(f'Missing or empty files in {unit.name}: {missing}')

        zip_path = ZIP_DIR / f'{unit.name}.zip'
        with zipfile.ZipFile(zip_path, 'w', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as zf:
            for file_path in sorted(unit.rglob('*')):
                if file_path.is_file():
                    arcname = Path(unit.name) / file_path.relative_to(unit)
                    zf.write(file_path, arcname.as_posix())

        with zipfile.ZipFile(zip_path, 'r') as zf:
            bad = zf.testzip()
            names = zf.namelist()
            if bad is not None:
                raise RuntimeError(f'CRC test failed in {zip_path.name}: {bad}')
            if any(name.startswith('/') or '..' in Path(name).parts for name in names):
                raise RuntimeError(f'Unsafe path found in {zip_path.name}')

            with tempfile.TemporaryDirectory(prefix='godot_chapter_zip_') as tmp:
                tmp_path = Path(tmp)
                zf.extractall(tmp_path)
                extracted_unit = tmp_path / unit.name
                original_hashes = tree_hashes(unit)
                extracted_hashes = tree_hashes(extracted_unit)
                if original_hashes != extracted_hashes:
                    raise RuntimeError(f'Extracted content mismatch: {zip_path.name}')

        results.append({
            'unit': unit.name,
            'zip': zip_path.relative_to(ROOT).as_posix(),
            'zip_bytes': zip_path.stat().st_size,
            'zip_sha256': sha256(zip_path),
            'file_count': len(tree_hashes(unit)),
            'crc_test': 'passed',
            'extraction_hash_match': True,
        })

    out = {
        'generated_at_utc': datetime.now(timezone.utc).isoformat(),
        'chapter_zip_count': len(results),
        'all_passed': True,
        'results': results,
    }
    (DELIVERY / 'chapter_zip_verification.json').write_text(
        json.dumps(out, ensure_ascii=False, indent=2) + '\n', encoding='utf-8'
    )
    print(json.dumps(out, ensure_ascii=False, indent=2))


if __name__ == '__main__':
    main()
