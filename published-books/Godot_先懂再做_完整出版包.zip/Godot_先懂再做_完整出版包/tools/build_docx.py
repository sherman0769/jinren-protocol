from __future__ import annotations
from pathlib import Path
import re
from typing import Iterable

from docx import Document
from docx.shared import Cm, Pt, RGBColor
from docx.enum.text import WD_ALIGN_PARAGRAPH, WD_LINE_SPACING
from docx.enum.section import WD_SECTION
from docx.enum.style import WD_STYLE_TYPE
from docx.enum.table import WD_TABLE_ALIGNMENT, WD_CELL_VERTICAL_ALIGNMENT
from docx.oxml import OxmlElement
from docx.oxml.ns import qn

ROOT=Path('/mnt/data/Godot_先懂再做_完整出版包')
CHROOT=ROOT/'02_chapters'
MASTER=ROOT/'01_master'

SERIF='Noto Serif CJK TC'
SANS='Noto Sans CJK TC'
MONO='Noto Sans Mono CJK TC'
DARK='203040'
ACCENT='285A7A'
LIGHT='EEF4F7'
QUOTE='F3F6F8'
CODE='F4F4F4'
GRAY='666666'


def set_run_font(run, name, size=None, bold=None, italic=None, color=None):
    run.font.name=name
    rpr=run._element.get_or_add_rPr()
    rfonts=rpr.rFonts
    if rfonts is None:
        rfonts=OxmlElement('w:rFonts'); rpr.append(rfonts)
    for attr in ('ascii','hAnsi','eastAsia','cs'):
        rfonts.set(qn('w:'+attr), name)
    if size is not None: run.font.size=Pt(size)
    if bold is not None: run.bold=bold
    if italic is not None: run.italic=italic
    if color: run.font.color.rgb=RGBColor.from_string(color)


def set_cell_shading(cell, fill):
    tcPr=cell._tc.get_or_add_tcPr()
    shd=tcPr.find(qn('w:shd'))
    if shd is None:
        shd=OxmlElement('w:shd'); tcPr.append(shd)
    shd.set(qn('w:fill'), fill)


def set_paragraph_shading(p, fill):
    pPr=p._p.get_or_add_pPr()
    shd=pPr.find(qn('w:shd'))
    if shd is None:
        shd=OxmlElement('w:shd'); pPr.append(shd)
    shd.set(qn('w:fill'), fill)


def set_paragraph_border_left(p, color='7A9BAE', size='18', space='8'):
    pPr=p._p.get_or_add_pPr()
    pbdr=pPr.find(qn('w:pBdr'))
    if pbdr is None:
        pbdr=OxmlElement('w:pBdr'); pPr.append(pbdr)
    left=pbdr.find(qn('w:left'))
    if left is None:
        left=OxmlElement('w:left'); pbdr.append(left)
    left.set(qn('w:val'),'single'); left.set(qn('w:sz'),size); left.set(qn('w:space'),space); left.set(qn('w:color'),color)


def add_page_number(paragraph):
    paragraph.alignment=WD_ALIGN_PARAGRAPH.RIGHT
    run=paragraph.add_run('第 ')
    set_run_font(run,SANS,8,color=GRAY)
    fldChar1=OxmlElement('w:fldChar'); fldChar1.set(qn('w:fldCharType'),'begin')
    instrText=OxmlElement('w:instrText'); instrText.set(qn('xml:space'),'preserve'); instrText.text=' PAGE '
    fldChar2=OxmlElement('w:fldChar'); fldChar2.set(qn('w:fldCharType'),'end')
    run._r.append(fldChar1); run._r.append(instrText); run._r.append(fldChar2)
    r2=paragraph.add_run(' 頁')
    set_run_font(r2,SANS,8,color=GRAY)


def add_bottom_border(paragraph, color='AAB7C1'):
    pPr=paragraph._p.get_or_add_pPr()
    pbdr=OxmlElement('w:pBdr')
    bottom=OxmlElement('w:bottom')
    bottom.set(qn('w:val'),'single'); bottom.set(qn('w:sz'),'4'); bottom.set(qn('w:space'),'2'); bottom.set(qn('w:color'),color)
    pbdr.append(bottom); pPr.append(pbdr)


def setup_document(doc:Document, header_text:str='', title_page=False):
    sec=doc.sections[0]
    sec.page_width=Cm(21.0); sec.page_height=Cm(29.7)
    sec.top_margin=Cm(1.9); sec.bottom_margin=Cm(1.75); sec.left_margin=Cm(2.15); sec.right_margin=Cm(2.15)
    sec.header_distance=Cm(0.75); sec.footer_distance=Cm(0.7)
    sec.different_first_page_header_footer=title_page
    # metadata
    props=doc.core_properties
    props.author='李詩民'; props.title='先懂再做：用 Godot 建立遊戲開發的全局觀'; props.subject='Godot 4.7 Stable 概念型學習書'; props.keywords='Godot, Codex, 遊戲開發, 系統思維, AI 協作'
    # Base styles
    styles=doc.styles
    normal=styles['Normal']; normal.font.name=SERIF; normal.font.size=Pt(10.3)
    normal._element.rPr.rFonts.set(qn('w:eastAsia'),SERIF)
    pf=normal.paragraph_format; pf.line_spacing=1.28; pf.space_after=Pt(5.2); pf.first_line_indent=Cm(0.74); pf.widow_control=True
    for name,size,color,space_before,space_after in [('Title',26,DARK,0,12),('Subtitle',14,ACCENT,0,10),('Heading 1',19,DARK,16,10),('Heading 2',14,ACCENT,11,6),('Heading 3',11.5,DARK,8,4)]:
        if name not in styles:
            st=styles.add_style(name,WD_STYLE_TYPE.PARAGRAPH)
        st=styles[name]; st.font.name=SANS; st.font.size=Pt(size); st.font.bold=True; st.font.color.rgb=RGBColor.from_string(color)
        st._element.rPr.rFonts.set(qn('w:eastAsia'),SANS)
        st.paragraph_format.space_before=Pt(space_before); st.paragraph_format.space_after=Pt(space_after); st.paragraph_format.keep_with_next=True; st.paragraph_format.widow_control=True
        if name=='Heading 1': st.paragraph_format.page_break_before=False
    # list styles
    for lname in ('List Bullet','List Number'):
        st=styles[lname]; st.font.name=SERIF; st.font.size=Pt(10.0); st._element.rPr.rFonts.set(qn('w:eastAsia'),SERIF)
        st.paragraph_format.space_after=Pt(2.8); st.paragraph_format.first_line_indent=None; st.paragraph_format.left_indent=Cm(0.75)
    # custom styles
    def add_style(name, base, font, size, color=None, bold=False, italic=False):
        if name in styles: st=styles[name]
        else: st=styles.add_style(name,WD_STYLE_TYPE.PARAGRAPH)
        st.base_style=styles[base]
        st.font.name=font; st.font.size=Pt(size); st.font.bold=bold; st.font.italic=italic
        st._element.rPr.rFonts.set(qn('w:eastAsia'),font)
        if color: st.font.color.rgb=RGBColor.from_string(color)
        return st
    quote=add_style('Book Quote','Normal',SERIF,10.3,DARK,False,False)
    quote.paragraph_format.left_indent=Cm(0.75); quote.paragraph_format.right_indent=Cm(0.45); quote.paragraph_format.first_line_indent=Cm(0); quote.paragraph_format.space_before=Pt(5); quote.paragraph_format.space_after=Pt(6); quote.paragraph_format.line_spacing=1.25
    code=add_style('Code Block','Normal',MONO,8.5,DARK,False,False)
    code.paragraph_format.left_indent=Cm(0.45); code.paragraph_format.right_indent=Cm(0.25); code.paragraph_format.first_line_indent=Cm(0); code.paragraph_format.space_before=Pt(3); code.paragraph_format.space_after=Pt(4); code.paragraph_format.line_spacing=1.03; code.paragraph_format.keep_together=True
    source=add_style('Source Note','Normal',SANS,8.0,GRAY,False,False)
    source.paragraph_format.left_indent=Cm(0.4); source.paragraph_format.first_line_indent=Cm(0); source.paragraph_format.space_after=Pt(1.5); source.paragraph_format.line_spacing=1.05
    caption=add_style('Book Caption','Normal',SANS,8.5,GRAY,False,False)
    caption.paragraph_format.first_line_indent=Cm(0); caption.paragraph_format.alignment=WD_ALIGN_PARAGRAPH.CENTER
    # header/footer
    header=sec.header.paragraphs[0]
    header.text=''
    if header_text:
        r=header.add_run(header_text); set_run_font(r,SANS,8,color=GRAY)
        header.alignment=WD_ALIGN_PARAGRAPH.LEFT; add_bottom_border(header)
    footer=sec.footer.paragraphs[0]; footer.text=''; add_page_number(footer)


def soften_url(text):
    # add zero width spaces after safe URL separators to avoid overflow
    if 'http://' not in text and 'https://' not in text: return text
    return re.sub(r'([/_?&=\-])', lambda m: m.group(1)+'\u200b', text)


def add_inline(p, text, default_font=SERIF, default_size=None):
    # support **bold**, *italic*, `code`; preserve plain text
    text=soften_url(text)
    pattern=re.compile(r'(\*\*.+?\*\*|`.+?`|(?<!\*)\*[^*]+?\*(?!\*))')
    pos=0
    for m in pattern.finditer(text):
        if m.start()>pos:
            r=p.add_run(text[pos:m.start()]); set_run_font(r,default_font,default_size)
        token=m.group(0)
        if token.startswith('**'):
            r=p.add_run(token[2:-2]); set_run_font(r,default_font,default_size,bold=True)
        elif token.startswith('`'):
            r=p.add_run(token[1:-1]); set_run_font(r,MONO,8.7,color=DARK)
        else:
            r=p.add_run(token[1:-1]); set_run_font(r,default_font,default_size,italic=True)
        pos=m.end()
    if pos<len(text):
        r=p.add_run(text[pos:]); set_run_font(r,default_font,default_size)


def is_table_sep(line):
    cells=[x.strip() for x in line.strip().strip('|').split('|')]
    return bool(cells) and all(re.fullmatch(r':?-{3,}:?',c or '') for c in cells)


def split_table_row(line):
    return [x.strip() for x in line.strip().strip('|').split('|')]


def render_markdown(doc:Document, markdown:str, full_book=False, skip_first_title=False):
    lines=markdown.splitlines()
    i=0; code=False; code_lines=[]; first_h1=True; first_line_title_skipped=False
    while i<len(lines):
        line=lines[i]
        stripped=line.strip()
        # code fences
        if stripped.startswith('```'):
            if not code:
                code=True; code_lines=[]
            else:
                p=doc.add_paragraph(style='Code Block')
                set_paragraph_shading(p,CODE)
                r=p.add_run('\n'.join(code_lines) if code_lines else ' '); set_run_font(r,MONO,8.5,color=DARK)
                code=False; code_lines=[]
            i+=1; continue
        if code:
            code_lines.append(line); i+=1; continue
        if not stripped:
            i+=1; continue
        # table
        if stripped.startswith('|') and i+1<len(lines) and is_table_sep(lines[i+1].strip()):
            headers=split_table_row(line); rows=[]; i+=2
            while i<len(lines) and lines[i].strip().startswith('|'):
                rows.append(split_table_row(lines[i])); i+=1
            table=doc.add_table(rows=1+len(rows), cols=len(headers))
            table.alignment=WD_TABLE_ALIGNMENT.CENTER; table.autofit=True
            table.style='Table Grid'
            for j,h in enumerate(headers):
                cell=table.rows[0].cells[j]; set_cell_shading(cell,ACCENT); cell.vertical_alignment=WD_CELL_VERTICAL_ALIGNMENT.CENTER
                p=cell.paragraphs[0]; p.alignment=WD_ALIGN_PARAGRAPH.CENTER; p.paragraph_format.first_line_indent=Cm(0)
                add_inline(p,h,SANS,8.5)
                for r in p.runs: r.bold=True; r.font.color.rgb=RGBColor(255,255,255)
            for ri,row in enumerate(rows,1):
                for j in range(len(headers)):
                    cell=table.rows[ri].cells[j]; cell.vertical_alignment=WD_CELL_VERTICAL_ALIGNMENT.TOP
                    if ri%2==0: set_cell_shading(cell,'F5F7F8')
                    p=cell.paragraphs[0]; p.paragraph_format.first_line_indent=Cm(0); p.paragraph_format.space_after=Pt(1); p.paragraph_format.line_spacing=1.05
                    add_inline(p,row[j] if j<len(row) else '',SERIF,8.4)
            doc.add_paragraph().paragraph_format.space_after=Pt(1)
            continue
        # headings
        hm=re.match(r'^(#{1,4})\s+(.+)$',stripped)
        if hm:
            level=len(hm.group(1)); txt=hm.group(2).strip()
            if skip_first_title and not first_line_title_skipped and level==1:
                first_line_title_skipped=True; i+=1; continue
            style='Heading 1' if level==1 else 'Heading 2' if level==2 else 'Heading 3'
            p=doc.add_paragraph(style=style); p.paragraph_format.first_line_indent=Cm(0)
            if full_book and level==1:
                p.paragraph_format.page_break_before=True
                first_h1=False
            add_inline(p,txt,SANS,19 if level==1 else 14 if level==2 else 11.5)
            i+=1; continue
        if re.fullmatch(r'-{3,}',stripped):
            if not full_book:
                p=doc.add_paragraph(); p.paragraph_format.space_before=Pt(4); p.paragraph_format.space_after=Pt(6)
                add_bottom_border(p,'C8D2D8')
            i+=1; continue
        if stripped.startswith('> '):
            p=doc.add_paragraph(style='Book Quote'); set_paragraph_shading(p,QUOTE); set_paragraph_border_left(p)
            add_inline(p,stripped[2:].strip(),SERIF,10.2); i+=1; continue
        # bullet/numbered
        m=re.match(r'^[-*]\s+(.+)$',stripped)
        if m:
            style='Source Note' if ('http://' in m.group(1) or 'https://' in m.group(1)) else 'List Bullet'
            p=doc.add_paragraph(style=style); p.paragraph_format.first_line_indent=Cm(0)
            if style=='Source Note':
                r=p.add_run('• '); set_run_font(r,SANS,8,color=GRAY)
                add_inline(p,m.group(1),SANS,8)
            else: add_inline(p,m.group(1),SERIF,10.0)
            i+=1; continue
        m=re.match(r'^(\d+)\.\s+(.+)$',stripped)
        if m:
            # preserve explicit number to prevent numbering reset surprises across renderers
            p=doc.add_paragraph(); p.paragraph_format.left_indent=Cm(0.75); p.paragraph_format.first_line_indent=Cm(-0.55); p.paragraph_format.space_after=Pt(2.8)
            r=p.add_run(m.group(1)+'. '); set_run_font(r,SANS,9.8,bold=True,color=ACCENT)
            add_inline(p,m.group(2),SERIF,10.0); i+=1; continue
        # plain paragraph; source URLs use smaller style
        style='Source Note' if ('http://' in stripped or 'https://' in stripped) else 'Normal'
        p=doc.add_paragraph(style=style)
        if style=='Source Note': p.paragraph_format.first_line_indent=Cm(0)
        add_inline(p,stripped,SANS if style=='Source Note' else SERIF,8 if style=='Source Note' else 10.3)
        i+=1
    if code_lines:
        p=doc.add_paragraph(style='Code Block'); set_paragraph_shading(p,CODE)
        r=p.add_run('\n'.join(code_lines)); set_run_font(r,MONO,8.5)


def add_title_page(doc:Document):
    p=doc.add_paragraph(); p.paragraph_format.space_before=Pt(86); p.alignment=WD_ALIGN_PARAGRAPH.CENTER
    r=p.add_run('先懂再做'); set_run_font(r,SANS,30,bold=True,color=DARK)
    p=doc.add_paragraph(); p.alignment=WD_ALIGN_PARAGRAPH.CENTER; p.paragraph_format.space_before=Pt(7)
    r=p.add_run('用 Godot 建立遊戲開發的全局觀'); set_run_font(r,SANS,22,bold=True,color=ACCENT)
    p=doc.add_paragraph(); p.alignment=WD_ALIGN_PARAGRAPH.CENTER; p.paragraph_format.space_before=Pt(18)
    r=p.add_run('從場景、節點、訊號與遊戲迴路，\n到指揮 Codex 完成作品'); set_run_font(r,SERIF,13,color=DARK)
    p=doc.add_paragraph(); p.alignment=WD_ALIGN_PARAGRAPH.CENTER; p.paragraph_format.space_before=Pt(54)
    r=p.add_run('李詩民　著'); set_run_font(r,SANS,14,bold=True,color=DARK)
    p=doc.add_paragraph(); p.alignment=WD_ALIGN_PARAGRAPH.CENTER; p.paragraph_format.space_before=Pt(72)
    r=p.add_run('V1.0｜Godot 4.7 Stable｜2026'); set_run_font(r,SANS,9,color=GRAY)
    doc.add_page_break()


def build_full():
    md=(MASTER/'full_book.md').read_text(encoding='utf-8')
    # remove top title block before publishing note; rendered with dedicated cover
    idx=md.find('## 出版與版本說明')
    body=md[idx:] if idx>=0 else md
    doc=Document(); setup_document(doc,'先懂再做｜Godot 全局觀',title_page=True); add_title_page(doc)
    render_markdown(doc,body,full_book=True)
    path=MASTER/'full_book.docx'; doc.save(path); return path


def build_chapters():
    paths=[]
    for p in sorted(CHROOT.glob('chapter_*/chapter_*_main.md')):
        title=p.read_text(encoding='utf-8').splitlines()[0].lstrip('# ').strip()
        doc=Document(); setup_document(doc,title[:38],title_page=False)
        render_markdown(doc,p.read_text(encoding='utf-8'),full_book=False)
        out=p.with_suffix('.docx'); doc.save(out); paths.append(out)
    return paths

if __name__=='__main__':
    chapters=build_chapters(); full=build_full()
    print('created',len(chapters),'chapter docx and',full)
