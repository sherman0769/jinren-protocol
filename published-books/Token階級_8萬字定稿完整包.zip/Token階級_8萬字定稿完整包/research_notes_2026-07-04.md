# 《Token階級》8萬字定稿版｜資料校準筆記

查詢與整理日期：2026-07-04

本書不是研究報告，資料來源用於校準趨勢與技術現況。正式書稿主體仍以白話觀點、教學模型、演講轉化與方法論整理為主。

## OpenAI API - Rate limits
- 連結：https://developers.openai.com/api/docs/guides/rate-limits
- 用途：模型與API的rate limit、使用層級、RPM/TPM等限制概念校準。

## Google AI for Developers - Gemini API Rate limits
- 連結：https://ai.google.dev/gemini-api/docs/rate-limits
- 用途：Gemini API以RPM、TPM、RPD與專案使用層級管理額度的概念校準。

## Anthropic Claude Platform Docs - Rate limits
- 連結：https://platform.claude.com/docs/en/api/rate-limits
- 用途：Claude API以RPM、ITPM、OTPM與快取影響吞吐量的概念校準。

## Stanford HAI - The 2026 AI Index Report
- 連結：https://hai.stanford.edu/ai-index/2026-ai-index-report
- 用途：AI能力、組織採用率、學生使用率、資料中心與硬體集中現象校準。

## Stanford HAI - AI Index 2025: State of AI in 10 Charts
- 連結：https://hai.stanford.edu/news/ai-index-2025-state-of-ai-in-10-charts
- 用途：2024年企業AI使用率、生成式AI商業採用、類GPT-3.5推理成本下降等趨勢校準。

## World Bank Data360 - Inequalities in Use of and Exposure to Artificial Intelligence
- 連結：https://data360.worldbank.org/en/atlas/artificial-intelligence
- 用途：資料中心容量、低收入國家基礎設施落差與AI暴露不均之校準。

## UNCTAD - Technology and Innovation Report 2025: Inclusive Artificial Intelligence for Development
- 連結：https://digitallibrary.un.org/record/4084950?ln=en
- 用途：以基礎設施、資料、技能與治理思考包容式AI發展。

## UNESCO - AI Competency Framework for Teachers
- 連結：https://www.unesco.org/en/articles/ai-competency-framework-teachers
- 用途：教師AI能力框架、以人為本、倫理、AI基礎、教學與專業學習。

## UNESCO - AI Competency Framework for Students
- 連結：https://www.unesco.org/en/articles/ai-competency-framework-students
- 用途：學生AI能力框架、以人為本、倫理、技術應用與系統設計。


## 核心校準結論
1. AI服務的使用權限確實會被模型、專案、組織、使用層級、RPM、TPM、RPD、ITPM、OTPM、快取與月費/用量制度管理。
2. AI採用正在快速普及，但普及不代表平等；模型、算力、資料中心、語言資源、數位技能與企業治理仍會形成差距。
3. 教育端需要從工具操作走向AI素養、倫理判斷、系統設計與權限意識。
4. 企業端需要從買帳號走向任務分類、模型配置、資料治理、工作流設計與評估機制。
5. 普通人的突圍路徑不是等待資源完全平等，而是先提升提問品質、上下文整理、工作流設計、知識庫沉澱與人機協作判斷。
