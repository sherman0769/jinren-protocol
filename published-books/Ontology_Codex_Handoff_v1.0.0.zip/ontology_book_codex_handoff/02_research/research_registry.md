# 研究來源登錄表

版本：1.0.0。查閱日：2026-09-28。首輪登錄 26 筆，包含方法論、標準、論文、官方產品文件與架構評論；其中 R20 只供 Codex 操作使用。

這不是全書研究已完成的宣告。`RELEVANT_SECTIONS_READ` 表示本輪已讀相關段落，不表示逐字讀完全文；`ABSTRACT_AND_METADATA_READ`、`AUTHOR_ABSTRACT_READ` 只表示已核對摘要與書目；`TOOL_DESCRIPTION_READ` 只表示讀過工具介紹。正文若需要尚未讀取的內容，必須再精讀。

本包只提供書目、連結、短評與限制，不附未授權的第三方全文。發布日期未核定就留空，不拿爬取日期當發布日期。arXiv DOI 不等於已通過同儕審查。論文若改版，作者表與結果也可能改變。

來源編號 `R01` 等要和章稿的主張、段落定位一起使用。單有篇末書目而找不到哪個主張引用哪裡，不算完成查核。


## R01

**可攜式本體規格的轉譯方法**  
原文：A Translation Approach to Portable Ontology Specifications  
作者／機構：Thomas R. Gruber  
類型：期刊論文之作者頁與摘要  
日期：1993  
版本／狀態：Knowledge Acquisition 5(2), 199–220；本輪未讀全文  
查閱日：2026-09-28  
讀取深度：`AUTHOR_ABSTRACT_READ`  
支持章節：第1章、第2章  
來源：https://tomgruber.org/writing/ontolingua-kaj-1993/

可支持：將本體放回知識共享與可重用詞彙的問題脈絡。

限制：作者頁與摘要不能替代本文論證精讀；不取用網頁自述的引用排名。

定位：作者頁 Abstract / Full Abstract。正式使用時補出精確小節／頁碼／表號與主張對應。

更新要求：基礎概念可作穩定參考；新增細節仍須回到指定版本查證。


## R02

**本體開發入門：建立第一個本體的指南**  
原文：Ontology Development 101: A Guide to Creating Your First Ontology  
作者／機構：Natalya F. Noy、Deborah L. McGuinness  
類型：大學技術報告／方法指南  
日期：2001  
版本／狀態：Stanford 技術報告 KSL-01-05；HTML 版本  
查閱日：2026-09-28  
讀取深度：`RELEVANT_SECTIONS_READ`  
支持章節：第2章、第3章、第5章、第6章、第15章、第16章  
來源：https://protege.stanford.edu/publications/ontology_development/ontology101-noy-mcguinness.html

備用／全文入口：https://protegewiki.stanford.edu/wiki/Ontology101

可支持：用能力問題限定建模範圍，並採迭代與重用方法。

限制：老方法指南不提供當代 Agent 產品成效；部分格式互通描述需以現代實作再驗。

定位：Step 1 / Competency questions / Step 2。正式使用時補出精確小節／頁碼／表號與主張對應。

更新要求：基礎概念可作穩定參考；新增細節仍須回到指定版本查證。


## R03

**RDF 1.1 入門**  
原文：RDF 1.1 Primer  
作者／機構：W3C  
類型：標準組織入門文件  
日期：2014-06-24  
版本／狀態：W3C Working Group Note；本書基礎例用 RDF 1.1  
查閱日：2026-09-28  
讀取深度：`RELEVANT_SECTIONS_READ`  
支持章節：第4章、第6章、第8章  
來源：https://www.w3.org/TR/rdf11-primer/

可支持：用主詞、述詞、受詞介紹圖式陳述。

限制：入門文件非所有 RDF 功能的規範全文；RDF 不等同完整業務本體或唯一可選圖模型。

定位：Sections 3–5：資料模型與語法。正式使用時補出精確小節／頁碼／表號與主張對應。

更新要求：基礎概念可作穩定參考；新增細節仍須回到指定版本查證。


## R04

**OWL 2 本體語言入門，第二版**  
原文：OWL 2 Web Ontology Language Primer (Second Edition)  
作者／機構：W3C  
類型：標準組織文件  
日期：2012-12-11  
版本／狀態：W3C Recommendation；入門說明為 informative  
查閱日：2026-09-28  
讀取深度：`RELEVANT_SECTIONS_READ`  
支持章節：第3章、第8章  
來源：https://www.w3.org/TR/owl2-primer/

可支持：區分邏輯表達、個體事實、開放世界與資料格式驗證。

限制：本體不必用 OWL；形式一致不代表現實事實正確。

定位：Sections 2–4；Section 5.3 基數限制需進一步精讀。正式使用時補出精確小節／頁碼／表號與主張對應。

更新要求：基礎概念可作穩定參考；新增細節仍須回到指定版本查證。


## R05

**形狀約束語言**  
原文：Shapes Constraint Language (SHACL)  
作者／機構：W3C  
類型：標準規範  
日期：2017-07-20  
版本／狀態：W3C Recommendation  
查閱日：2026-09-28  
讀取深度：`RELEVANT_SECTIONS_READ`  
支持章節：第8章  
來源：https://www.w3.org/TR/shacl/

可支持：用指定形狀驗證 RDF 資料是否符合要求。

限制：驗證的是形狀要求，不直接保證付款真實或替代服務端授權。

定位：Abstract；Validation；Core Constraint Components。正式使用時補出精確小節／頁碼／表號與主張對應。

更新要求：基礎概念可作穩定參考；新增細節仍須回到指定版本查證。


## R06

**簡易知識組織系統參考**  
原文：SKOS Simple Knowledge Organization System Reference  
作者／機構：W3C  
類型：標準規範  
日期：2009-08-18  
版本／狀態：W3C Recommendation  
查閱日：2026-09-28  
讀取深度：`RELEVANT_SECTIONS_READ`  
支持章節：第4章  
來源：https://www.w3.org/TR/skos-reference/

可支持：支援受控詞彙、概念階層與標籤的對照教學。

限制：SKOS 的 broader 關係不能直接當成 OWL 子類公理；不宣稱分類表已足夠所有任務。

定位：Introduction；Concepts；Semantic Relations。正式使用時補出精確小節／頁碼／表號與主張對應。

更新要求：基礎概念可作穩定參考；新增細節仍須回到指定版本查證。


## R07

**PROV-O 來源追溯本體**  
原文：PROV-O: The PROV Ontology  
作者／機構：W3C  
類型：標準規範  
日期：2013-04-30  
版本／狀態：W3C Recommendation  
查閱日：2026-09-28  
讀取深度：`RELEVANT_SECTIONS_READ`  
支持章節：第7章  
來源：https://www.w3.org/TR/prov-o/

可支持：為事物、處理活動與責任主體的來源關係提供詞彙。

限制：PROV 的 Agent 可指人或組織等責任主體，不是專指 LLM 智能體；來源可查不等於可信。

定位：Starting Point Terms；Expanded Terms。正式使用時補出精確小節／頁碼／表號與主張對應。

更新要求：基礎概念可作穩定參考；新增細節仍須回到指定版本查證。


## R08

**知識圖譜**  
原文：Knowledge Graphs  
作者／機構：Aidan Hogan 等  
類型：已發表的綜述論文  
日期：2021-09-11  
版本／狀態：arXiv v6；ACM Computing Surveys 54(4), Article 71；DOI 10.1145/3447772  
查閱日：2026-09-28  
讀取深度：`RELEVANT_SECTIONS_READ`  
支持章節：第3章、第4章、第6章、第7章  
來源：https://arxiv.org/abs/2003.02320

備用／全文入口：https://arxiv.org/html/2003.02320v6

可支持：說明圖模型、身分、綱要與情境各自的責任。

限制：綜述涵蓋多種定義與系統，不能截成單一排他的知識圖譜定義。

定位：HTML 中 graph data models / schema / identity / context。正式使用時補出精確小節／頁碼／表號與主張對應。

更新要求：基礎概念可作穩定參考；新增細節仍須回到指定版本查證。


## R09

**知識密集語言任務的檢索增強生成**  
原文：Retrieval-Augmented Generation for Knowledge-Intensive NLP Tasks  
作者／機構：Patrick Lewis 等  
類型：已接受發表的原始研究  
日期：2021-04-12  
版本／狀態：arXiv v4；頁面註明 accepted at NeurIPS 2020  
查閱日：2026-09-28  
讀取深度：`ABSTRACT_AND_METADATA_READ`  
支持章節：第9章  
來源：https://arxiv.org/abs/2005.11401

可支持：提供 RAG 原始研究脈絡。

限制：原文特定訓練架構不等於現代 RAG 的所有用法；本輪未精讀實驗，不能取其數值。

定位：Abstract；Comments；Submission history。正式使用時補出精確小節／頁碼／表號與主張對應。

更新要求：基礎概念可作穩定參考；新增細節仍須回到指定版本查證。


## R10

**從局部到全局：用圖式 RAG 做提問導向摘要**  
原文：From Local to Global: A Graph RAG Approach to Query-Focused Summarization  
作者／機構：Darren Edge 等  
類型：研究預印本  
日期：2025-02-19  
版本／狀態：arXiv v2；初稿 2024-04-24  
查閱日：2026-09-28  
讀取深度：`RELEVANT_SECTIONS_READ`  
支持章節：第10章  
來源：https://arxiv.org/abs/2404.16130

備用／全文入口：https://arxiv.org/html/2404.16130v2

可支持：以文本抽取、圖與社群摘要組織全局問題的證據。

限制：特定任務結果不證明所有 GraphRAG 更好；產品與研究方法需分開。

定位：HTML Abstract；Introduction；Method。正式使用時補出精確小節／頁碼／表號與主張對應。

更新要求：基礎概念可作穩定參考；新增細節仍須回到指定版本查證。


## R11

**RAG 與 GraphRAG 的系統性比較與洞見**  
原文：RAG vs. GraphRAG: A Systematic Evaluation and Key Insights  
作者／機構：Haoyu Han、Li Ma 等（v3 作者表）  
類型：研究預印本／比較實驗  
日期：2026-03-04  
版本／狀態：arXiv v3；先查看 v1 後已改以 v3 為交接基準  
查閱日：2026-09-28  
讀取深度：`RELEVANT_SECTIONS_READ`  
支持章節：第10章、第15章、第16章  
來源：https://arxiv.org/abs/2502.11371

備用／全文入口：https://arxiv.org/html/2502.11371v3

可支持：比較方法的任務差異、效率取捨與評測偏差。

限制：不能把 v1 作者表與表格數字貼成 v3；正式引用成效前精讀所用版本的實驗設定。

定位：v3 HTML Abstract；evaluation / failure modes 對應章節。正式使用時補出精確小節／頁碼／表號與主張對應。

更新要求：正式寫作或出版前重新核對動態狀態及所用版本。


## R12

**使用大語言模型進行本體學習**  
原文：LLMs4OL: Large Language Models for Ontology Learning  
作者／機構：Hamed Babaei Giglou、Jennifer D’Souza、Sören Auer  
類型：已接受發表的原始研究  
日期：2023-08-02  
版本／狀態：arXiv v2；頁面註明 ISWC 2023 research track  
查閱日：2026-09-28  
讀取深度：`ABSTRACT_AND_METADATA_READ`  
支持章節：第13章  
來源：https://arxiv.org/abs/2307.16648

可支持：研究模型在詞項類型、分類結構與非分類關係抽取的子任務。

限制：子任務成功不等於可無人維護完整企業本體；本輪尚未精讀結果表。

定位：Abstract；Comments；Submission history。正式使用時補出精確小節／頁碼／表號與主張對應。

更新要求：基礎概念可作穩定參考；新增細節仍須回到指定版本查證。


## R13

**專家參與的能力問題擷取與協作本體工程**  
原文：IDEA2: Expert-in-the-loop competency question elicitation for collaborative ontology engineering  
作者／機構：Elliott Watkiss-Leek 等  
類型：研究預印本  
日期：2026-04-01  
版本／狀態：arXiv v1；不因年份新就視為主流共識  
查閱日：2026-09-28  
讀取深度：`RELEVANT_SECTIONS_READ`  
支持章節：第5章、第13章、第16章  
來源：https://arxiv.org/abs/2604.01344

備用／全文入口：https://arxiv.org/html/2604.01344v1

可支持：讓模型提出能力問題，再由領域專家審查與回饋修訂。

限制：驗證領域有限，回饋品質會影響流程；本包不把結果外推為所有產業的節省比例。

定位：HTML Introduction；Section 3；discussion / limitations。正式使用時補出精確小節／頁碼／表號與主張對應。

更新要求：正式寫作或出版前重新核對動態狀態及所用版本。


## R14

**Microsoft Fabric 本體預覽版概覽**  
原文：What is ontology (preview)?  
作者／機構：Microsoft  
類型：供應商官方文件  
日期：2026-07-21  
版本／狀態：Ontology / Fabric IQ 均標示 preview，依本次可讀頁面  
查閱日：2026-09-28  
讀取深度：`RELEVANT_SECTIONS_READ`  
支持章節：第2章、第7章  
來源：https://learn.microsoft.com/en-us/fabric/iq/ontology/overview

可支持：描述其企業語意、資料綁定與查詢功能。

限制：僅證實產品描述；頁面提醒上游更新需刷新，不能自動當作即時正確。

定位：Overview；Core concepts；Data binding；refresh notes。正式使用時補出精確小節／頁碼／表號與主張對應。

更新要求：正式寫作或出版前重新核對動態狀態及所用版本。


## R15

**本體與智能體的整合選項，預覽版**  
原文：Agent integration options for ontology (preview)  
作者／機構：Microsoft  
類型：供應商官方文件  
日期：2026-07-23  
版本／狀態：preview；平台支援範圍出版前重查  
查閱日：2026-09-28  
讀取深度：`RELEVANT_SECTIONS_READ`  
支持章節：第11章、第14章  
來源：https://learn.microsoft.com/en-us/fabric/iq/ontology/concepts-agent-integration

可支持：列出不同 Agent 取得本體情境的整合方式，包括 MCP。

限制：官方功能列表不是獨立效益研究；實際租戶、權限、支援工具需再查。

定位：Custom agents with ontology MCP server；supported agent descriptions。正式使用時補出精確小節／頁碼／表號與主張對應。

更新要求：正式寫作或出版前重新核對動態狀態及所用版本。


## R16

**為何建立 Palantir Ontology**  
原文：Why create an Ontology?  
作者／機構：Palantir  
類型：供應商官方架構說明  
日期：本輪未核定，不可補造  
版本／狀態：查閱日可讀的線上文件，頁面未核定統一發布日期  
查閱日：2026-09-28  
讀取深度：`RELEVANT_SECTIONS_READ`  
支持章節：第2章、第12章  
來源：https://www.palantir.com/docs/foundry/ontology/why-ontology

可支持：Palantir 將資料、邏輯、行動與安全整合為其產品營運模型。

限制：特定平台語境，不是整個本體領域的標準定義，也不是導入普遍有效的證據。

定位：Why create an Ontology；data / logic / action / security。正式使用時補出精確小節／頁碼／表號與主張對應。

更新要求：正式寫作或出版前重新核對動態狀態及所用版本。


## R17

**模型情境協定規格**  
原文：Model Context Protocol — Specification  
作者／機構：Model Context Protocol 維護團隊  
類型：協定官方規範  
日期：2026-07-28  
版本／狀態：本次 latest 轉向 2026-07-28；實作前重新確認  
查閱日：2026-09-28  
讀取深度：`RELEVANT_SECTIONS_READ`  
支持章節：第11章、第12章、第16章  
來源：https://modelcontextprotocol.io/specification/2026-07-28

備用／全文入口：https://modelcontextprotocol.io/specification/latest

可支持：規範應用程式與外部資料、工具的連接；安全需實作者處理。

限制：不能推論 MCP 會統一業務語意或自動執行全部安全原則。

定位：Overview；Security and Trust & Safety；Implementation Guidelines。正式使用時補出精確小節／頁碼／表號與主張對應。

更新要求：正式寫作或出版前重新核對動態狀態及所用版本。


## R18

**建構有效的智能體**  
原文：Building effective agents  
作者／機構：Anthropic  
類型：供應商第一手工程經驗文章  
日期：2024-12-19  
版本／狀態：頁面提醒部分工具資訊已改變；本書僅取架構取捨  
查閱日：2026-09-28  
讀取深度：`RELEVANT_SECTIONS_READ`  
支持章節：第1章、第9章、第12章、第15章  
來源：https://www.anthropic.com/engineering/building-effective-agents

可支持：以簡單可組合方案開始，必要才增加 Agent 複雜度。

限制：作者工程經驗不是隨機實驗或反本體論文；不要以舊工具名推定當前版本。

定位：When (and when not) to use agents；Combining and customizing these patterns。正式使用時補出精確小節／頁碼／表號與主張對應。

更新要求：正式寫作或出版前重新核對動態狀態及所用版本。


## R19

**智能體的有效情境工程**  
原文：Effective context engineering for AI agents  
作者／機構：Anthropic  
類型：供應商第一手工程文章  
日期：2025-09-29  
版本／狀態：線上工程文章；非標準組織規範  
查閱日：2026-09-28  
讀取深度：`RELEVANT_SECTIONS_READ`  
支持章節：第9章、第11章  
來源：https://www.anthropic.com/engineering/effective-context-engineering-for-ai-agents

可支持：按任務維護與選取推理時需要的情境，而非只優化單一提示詞。

限制：不把文中的廣泛模型推論當無條件定律；本體是可能情境來源，不等於情境工程全體。

定位：Context engineering vs. prompt engineering；Context retrieval and agentic search。正式使用時補出精確小節／頁碼／表號與主張對應。

更新要求：正式寫作或出版前重新核對動態狀態及所用版本。


## R20

**使用 AGENTS.md 提供專案指令**  
原文：Custom instructions with AGENTS.md  
作者／機構：OpenAI  
類型：工具官方文件  
日期：本輪未核定，不可補造  
版本／狀態：本次官方入口轉向 ChatGPT Learn 文件  
查閱日：2026-09-28  
讀取深度：`RELEVANT_SECTIONS_READ`  
支持章節：交接工具操作，非書稿論證  
來源：https://developers.openai.com/codex/guides/agents-md

備用／全文入口：https://learn.chatgpt.com/docs/agent-configuration/agents-md

可支持：把簡短專案規則放在根目錄 AGENTS.md，配合明確讀取順序。

限制：只支援本交接包操作，不作為本體技術論證；不要求關閉使用者的安全確認。

定位：Custom instructions with AGENTS.md；How Codex discovers guidance。正式使用時補出精確小節／頁碼／表號與主張對應。

更新要求：正式寫作或出版前重新核對動態狀態及所用版本。


## R21

**大語言模型生成學術本體：工程領域分析**  
原文：Large Language Models for Scholarly Ontology Generation: An Extensive Analysis in the Engineering Field  
作者／機構：Tanay Aggarwal、Angelo Salatino、Francesco Osborne、Enrico Motta  
類型：研究預印本  
日期：2025-06-11  
版本／狀態：arXiv v2；初稿 2024-12-11  
查閱日：2026-09-28  
讀取深度：`ABSTRACT_AND_METADATA_READ`  
支持章節：第13章  
來源：https://arxiv.org/abs/2412.08258

可支持：檢查模型對研究主題之語意關係的辨識能力。

限制：此任務不等於完整企業規則建模；本包不摘錄 F1 數值，使用前需精讀評測。

定位：Abstract；Submission history。正式使用時補出精確小節／頁碼／表號與主張對應。

更新要求：基礎概念可作穩定參考；新增細節仍須回到指定版本查證。


## R22

**Azure Digital Twins 的本體概念**  
原文：What is an ontology? — Azure Digital Twins  
作者／機構：Microsoft  
類型：供應商官方文件  
日期：本輪未核定，不可補造  
版本／狀態：線上文件；本次未紀錄頁面更新日期  
查閱日：2026-09-28  
讀取深度：`RELEVANT_SECTIONS_READ`  
支持章節：第14章  
來源：https://learn.microsoft.com/en-us/azure/digital-twins/concepts-ontologies

可支持：為數位分身中的共用領域模型與重用提供產品例子。

限制：不是企業本體具備因果或預測能力的證據；需要額外狀態及模擬假設。

定位：Overview；ontology reuse examples。正式使用時補出精確小節／頁碼／表號與主張對應。

更新要求：正式寫作或出版前重新核對動態狀態及所用版本。


## R23

**本體常見陷阱掃描工具**  
原文：OOPS! — OntOlogy Pitfall Scanner!  
作者／機構：Ontology Engineering Group  
類型：研究團隊工具頁  
日期：本輪未核定，不可補造  
版本／狀態：官方頁面與工具介紹；本包未上傳任何資料或執行遠端掃描  
查閱日：2026-09-28  
讀取深度：`TOOL_DESCRIPTION_READ`  
支持章節：第8章、第13章  
來源：https://oops.linkeddata.es/

可支持：作為檢查本體建模陷阱的工具與研究延伸入口。

限制：掃描通過不等於業務正確；正式研究需追讀工具所連原始論文與檢查範圍。

定位：工具介紹與相關出版連結。正式使用時補出精確小節／頁碼／表號與主張對應。

更新要求：正式寫作或出版前重新核對動態狀態及所用版本。


## R24

**結合圖結構的檢索增強生成綜述**  
原文：Retrieval-Augmented Generation with Graphs (GraphRAG)  
作者／機構：Haoyu Han 等  
類型：研究預印本／綜述  
日期：2025-01-08  
版本／狀態：arXiv v2；初稿日期為 2024-12-31，不能只從編號猜發布月份  
查閱日：2026-09-28  
讀取深度：`ABSTRACT_AND_METADATA_READ`  
支持章節：第10章  
來源：https://arxiv.org/abs/2501.00309

可支持：區分 GraphRAG 的組成、領域差異與設計挑戰。

限制：綜述不是每種方法均適用企業任務的證據；本輪尚未精讀全文。

定位：Abstract；Submission history。正式使用時補出精確小節／頁碼／表號與主張對應。

更新要求：基礎概念可作穩定參考；新增細節仍須回到指定版本查證。


## R25

**限界情境**  
原文：Bounded Context  
作者／機構：Martin Fowler  
類型：資深實務作者的架構說明  
日期：2014-01-15  
版本／狀態：第一手架構評論；非 ontology 成效實驗  
查閱日：2026-09-28  
讀取深度：`RELEVANT_SECTIONS_READ`  
支持章節：第14章、第15章  
來源：https://martinfowler.com/bliki/BoundedContext.html

可支持：大型領域可保留局部一致模型，再明確描述模型間關係。

限制：不能把這篇直接當所有本體方法失敗的證據；書中只是用來檢查強制全域統一的假設。

定位：Bounded Context 主文。正式使用時補出精確小節／頁碼／表號與主張對應。

更新要求：基礎概念可作穩定參考；新增細節仍須回到指定版本查證。


## R26

**dbt 分析語意層**  
原文：dbt Semantic Layer  
作者／機構：dbt Labs  
類型：供應商官方文件  
日期：2026-08-18  
版本／狀態：本次頁面顯示的更新日期；不據此推薦付費方案  
查閱日：2026-09-28  
讀取深度：`RELEVANT_SECTIONS_READ`  
支持章節：第1章、第4章、第15章  
來源：https://docs.getdbt.com/docs/use-dbt-semantic-layer/dbt-sl

可支持：可統一指標定義及處理資料連接，是分析需求的比較方案。

限制：產品語意層不等於所有 ontology 功能；不能只因都有統一詞意就宣稱兩者完全相同。

定位：dbt Semantic Layer introduction。正式使用時補出精確小節／頁碼／表號與主張對應。

更新要求：正式寫作或出版前重新核對動態狀態及所用版本。
