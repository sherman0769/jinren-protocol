# 從這裡開始

## 給李詩民

這個包要讓你從「本體幾乎零概念」，走到能解釋、建模、判斷是否需要、接入 AI、再教給別人。它是 Codex 接手工作的規格與材料，不是一本已完成的書。

完整資料夾最適合直接在 Codex 開啟。只傳一個 Markdown 時，使用 `CODEX_HANDOFF.md`；完整來源分項、JSON 案例、腳本和測試仍在 ZIP 裡。

## 給 Codex

第一輪讀取順序：`AGENTS.md` → `00_project/project_state.json` → `00_project/book_bible.md` → `01_plan/chapter_map.md` → `05_execution/task_board.md` → `02_research/research_tasks.md`。再讀 R-01 涉及的來源與第 1 章規格，不重做定位。

第一個實際產出：補足第 1–4 章所需基礎來源定位；建立第一章完整寫作包，列清可用主張、證據限制、案例與必須回答的問題。若當前環境已獲使用者啟動指令授權且能寫作，直接撰寫第一章完整可編輯稿；使用者指定 Pro 分工時則整理給 Pro 的寫作包再接稿，不假設跨產品控制。

先驗證本包：`python -B scripts/validate_handoff.py`。再執行單元測試。任何失敗要記錄原因而非刪掉檢查。研究缺口不以隨意填字解決。

## 狀態要分開

`handoff_status` 表示這個交接包是否驗證；`book_status` 表示全書進度。現在正式章稿 0／16、正式節目稿 0／16。不得把手上有 16 份章規格說成有 16 章正文。

完成每個單元後更新狀態、變更與下個未完成項目。使用者說「繼續」時讀這些紀錄，不重新開始。
